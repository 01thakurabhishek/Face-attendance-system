# AI Attendance System — Local MySQL Edition

This project runs locally in VS Code. The frontend is React + Vite + TanStack Start; the backend is a Node/Express API; MySQL stores accounts, profiles, institutes, lectures, attendance, tracking logs, exams, marks, submissions, face descriptors, and notes metadata. Cloud database dependencies, environment variables, and integration files have been removed; all runtime data access goes through the local API.

## Requirements
- Node.js 20+ (LTS recommended)
- MySQL 8+ and MySQL Workbench (or the MySQL command-line client)
- VS Code

## 1. Create the database
Open MySQL Workbench and run the complete file `mysql-local/schema.sql`. It creates the `visioroll` database and required tables.

## 2. Configure the API
Copy `mysql-local/.env.example` to `mysql-local/server/.env` and set your MySQL username/password. For example, if you use the root account, set `MYSQL_USER=root` and `MYSQL_PASSWORD=your actual password`.

In VS Code terminal 1:
```powershell
cd mysql-local/server
npm install
npm run dev
```
Check `http://localhost:4000/api/health`. It should return `ok: true`.

## 3. Configure and run the frontend
Open a second VS Code terminal at the project root (the folder containing this README and `package.json`):
```powershell
npm install
npm run dev
```
Open the exact `Local:` URL printed by Vite, usually `http://localhost:5173`. Keep both terminals running.

## Notes
- This is a local-development setup. Use strong passwords and do not expose the API to the public internet without a security review.
- Password reset cannot send email unless an email provider is configured; local API returns a development-only reset response.
- Data from a previous hosted database is not automatically imported. If you need existing records, export them separately and map them to the MySQL schema.
