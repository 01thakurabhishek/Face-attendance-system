import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { FileText, Loader2, Plus, Send, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/EmptyState";
import { RoleGate } from "@/components/RoleGate";
import { ClassScopeFilter } from "@/components/ClassScopeFilter";
import { emptyScope, matchesClass, matchesScope, type ClassScope } from "@/lib/classScope";
import { useAuth } from "@/lib/auth";
import { localDb } from "@/integrations/local/client";
import { profilesQuery, formatDate } from "@/lib/queries";
import {
  EXAM_TYPES,
  answerMap,
  canHavePaper,
  examMarksQuery,
  examQuestionsQuery,
  examSubmissionsQuery,
  examTypeLabel,
  examsQuery,
  type ExamType,
} from "@/lib/exams";
import { COURSES, DEPARTMENTS, SECTIONS, SEMESTERS } from "@/lib/types";

export const Route = createFileRoute("/app/exams")({
  head: () => ({
    meta: [
      { title: "Exams & Marks — AI Attendance System" },
      {
        name: "description",
        content:
          "Create class tests, share question papers with students and update exam marks for your class.",
      },
      { property: "og:title", content: "Exams & Marks — AI Attendance System" },
      { property: "og:description", content: "Build question papers and grade your students." },
    ],
  }),
  component: () => (
    <RoleGate allow={["teacher"]}>
      <ExamsPage />
    </RoleGate>
  ),
});

function ExamsPage() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const { data: allExams = [] } = useQuery(examsQuery());
  const { data: students = [] } = useQuery(profilesQuery("student"));
  const [scope, setScope] = useState<ClassScope>(emptyScope);
  const exams = allExams.filter((exam) => matchesScope(exam, scope));
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const selected = exams.find((exam) => exam.id === selectedId) ?? null;

  const [draft, setDraft] = useState({
    title: "",
    exam_type: "ct1" as ExamType,
    subject: "",
    course: COURSES[0] ?? "",
    department: DEPARTMENTS[0] ?? "",
    semester: SEMESTERS[0] ?? "",
    section: SECTIONS[0] ?? "",
    exam_date: new Date().toISOString().slice(0, 10),
    duration_minutes: "60",
    total_marks: "20",
    instructions: "",
  });

  const createExam = useMutation({
    mutationFn: async () => {
      if (!profile) throw new Error("Not signed in");
      const { error } = await localDb.from("exams").insert({
        teacher_profile_id: profile.id,
        institute_id: profile.institute_id,
        title: draft.title.trim(),
        exam_type: draft.exam_type,
        subject: draft.subject.trim(),
        course: draft.course,
        department: draft.department,
        semester: draft.semester,
        section: draft.section,
        exam_date: draft.exam_date,
        duration_minutes: Number(draft.duration_minutes) || null,
        total_marks: Number(draft.total_marks) || 20,
        instructions: draft.instructions.trim() || null,
      });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("Exam created");
      setShowForm(false);
      setDraft((prev) => ({ ...prev, title: "", subject: "", instructions: "" }));
      void queryClient.invalidateQueries({ queryKey: ["exams"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const togglePublish = useMutation({
    mutationFn: async ({ id, publish }: { id: string; publish: boolean }) => {
      const { error } = await localDb
        .from("exams")
        .update({ status: publish ? "published" : "draft" })
        .eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: (_data, variables) => {
      toast.success(variables.publish ? "Shared with students" : "Moved back to draft");
      void queryClient.invalidateQueries({ queryKey: ["exams"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const deleteExam = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await localDb.from("exams").delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      setSelectedId(null);
      toast.success("Exam deleted");
      void queryClient.invalidateQueries({ queryKey: ["exams"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <div className="space-y-8">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Exams &amp; marks</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Create class tests, share the question paper and record marks.
          </p>
        </div>
        <Button onClick={() => setShowForm((value) => !value)}>
          <Plus className="size-4" /> New exam
        </Button>
      </header>

      <ClassScopeFilter
        scope={scope}
        items={[...allExams, ...students]}
        onChange={(next) => { setScope(next); setSelectedId(null); }}
      />

      {showForm ? (
        <section className="surface-panel rounded-2xl border p-6">
          <h2 className="text-base font-semibold">New exam</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Title">
              <Input
                value={draft.title}
                onChange={(e) => setDraft({ ...draft, title: e.target.value })}
                placeholder="Class Test 1 — Data Structures"
              />
            </Field>
            <Field label="Exam type">
              <select
                className="h-10 w-full rounded-md border bg-background px-3 text-sm"
                value={draft.exam_type}
                onChange={(e) => setDraft({ ...draft, exam_type: e.target.value as ExamType })}
              >
                {EXAM_TYPES.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Subject">
              <Input
                value={draft.subject}
                onChange={(e) => setDraft({ ...draft, subject: e.target.value })}
              />
            </Field>
            <Field label="Course">
              <Picker
                value={draft.course}
                options={COURSES}
                onChange={(value) => setDraft({ ...draft, course: value })}
              />
            </Field>
            <Field label="Department">
              <Picker
                value={draft.department}
                options={DEPARTMENTS}
                onChange={(value) => setDraft({ ...draft, department: value })}
              />
            </Field>
            <Field label="Semester">
              <Picker
                value={draft.semester}
                options={SEMESTERS}
                onChange={(value) => setDraft({ ...draft, semester: value })}
              />
            </Field>
            <Field label="Section">
              <Picker
                value={draft.section}
                options={SECTIONS}
                onChange={(value) => setDraft({ ...draft, section: value })}
              />
            </Field>
            <Field label="Exam date">
              <Input
                type="date"
                value={draft.exam_date}
                onChange={(e) => setDraft({ ...draft, exam_date: e.target.value })}
              />
            </Field>
            <Field label="Duration (minutes)">
              <Input
                type="number"
                value={draft.duration_minutes}
                onChange={(e) => setDraft({ ...draft, duration_minutes: e.target.value })}
              />
            </Field>
            <Field label="Total marks">
              <Input
                type="number"
                value={draft.total_marks}
                onChange={(e) => setDraft({ ...draft, total_marks: e.target.value })}
              />
            </Field>
            <div className="sm:col-span-2 lg:col-span-3">
              <Field label="Instructions">
                <Textarea
                  rows={2}
                  value={draft.instructions}
                  onChange={(e) => setDraft({ ...draft, instructions: e.target.value })}
                />
              </Field>
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <Button
              onClick={() => createExam.mutate()}
              disabled={!draft.title.trim() || !draft.subject.trim() || createExam.isPending}
            >
              {createExam.isPending ? <Loader2 className="size-4 animate-spin" /> : null}
              Create exam
            </Button>
            <Button variant="outline" onClick={() => setShowForm(false)}>
              Cancel
            </Button>
          </div>
        </section>
      ) : null}

      <section className="surface-panel rounded-2xl border p-6">
        <h2 className="text-base font-semibold">All exams</h2>
        <div className="mt-4 grid gap-3 lg:grid-cols-2">
          {exams.length === 0 ? (
            <EmptyState
              icon={FileText}
              title="No exams yet"
              description="Create a class test to build a question paper and record marks."
            />
          ) : (
            exams.map((exam) => (
              <button
                key={exam.id}
                type="button"
                onClick={() => setSelectedId(exam.id === selectedId ? null : exam.id)}
                className={`rounded-xl border p-4 text-left transition-colors ${
                  exam.id === selectedId ? "border-primary bg-primary/5" : "hover:bg-secondary/50"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{exam.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {examTypeLabel(exam.exam_type)} · {exam.subject} · Sem {exam.semester} ·
                      Section {exam.section}
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {formatDate(exam.exam_date)} · {exam.total_marks} marks
                    </p>
                  </div>
                  <span
                    className={
                      exam.status === "published"
                        ? "rounded-full bg-success/15 px-2.5 py-1 text-xs font-medium text-success"
                        : "rounded-full bg-secondary px-2.5 py-1 text-xs text-muted-foreground"
                    }
                  >
                    {exam.status === "published" ? "Shared" : "Draft"}
                  </span>
                </div>
              </button>
            ))
          )}
        </div>
      </section>

      {selected ? (
        <>
          <section className="surface-panel rounded-2xl border p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-semibold">{selected.title}</h2>
                <p className="text-xs text-muted-foreground">
                  {examTypeLabel(selected.exam_type)} · {formatDate(selected.exam_date)}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant={selected.status === "published" ? "outline" : "default"}
                  onClick={() =>
                    togglePublish.mutate({
                      id: selected.id,
                      publish: selected.status !== "published",
                    })
                  }
                >
                  <Send className="size-4" />
                  {selected.status === "published" ? "Unshare" : "Share with students"}
                </Button>
                <Button variant="outline" onClick={() => deleteExam.mutate(selected.id)}>
                  <Trash2 className="size-4" />
                </Button>
              </div>
            </div>
            {selected.instructions ? (
              <p className="mt-3 rounded-xl border p-3 text-sm text-muted-foreground">
                {selected.instructions}
              </p>
            ) : null}
          </section>

          {canHavePaper(selected.exam_type) ? (
            <QuestionPaperEditor examId={selected.id} />
          ) : (
            <section className="surface-panel rounded-2xl border p-6 text-sm text-muted-foreground">
              Question papers can only be prepared for Class Test 1 and Class Test 2. For{" "}
              {examTypeLabel(selected.exam_type)} you can still record marks below.
            </section>
          )}

          <MarksPanel
            examId={selected.id}
            totalMarks={Number(selected.total_marks)}
            students={students.filter(
              (student) =>
                matchesClass(student, selected),
            )}
            graderProfileId={profile?.id ?? null}
          />
        </>
      ) : null}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function Picker({
  value,
  options,
  onChange,
}: {
  value: string;
  options: string[];
  onChange: (value: string) => void;
}) {
  return (
    <select
      className="h-10 w-full rounded-md border bg-background px-3 text-sm"
      value={value}
      onChange={(e) => onChange(e.target.value)}
    >
      {options.map((option) => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  );
}

function QuestionPaperEditor({ examId }: { examId: string }) {
  const queryClient = useQueryClient();
  const { data: questions = [] } = useQuery(examQuestionsQuery(examId));
  const [text, setText] = useState("");
  const [marks, setMarks] = useState("1");

  const addQuestion = useMutation({
    mutationFn: async () => {
      const nextNo = (questions.at(-1)?.question_no ?? 0) + 1;
      const { error } = await localDb.from("exam_questions").insert({
        exam_id: examId,
        question_no: nextNo,
        question_text: text.trim(),
        marks: Number(marks) || 1,
      });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      setText("");
      void queryClient.invalidateQueries({ queryKey: ["exam-questions", examId] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const removeQuestion = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await localDb.from("exam_questions").delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ["exam-questions", examId] }),
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <section className="surface-panel rounded-2xl border p-6">
      <h2 className="text-base font-semibold">Question paper</h2>
      <div className="mt-4 space-y-2">
        {questions.length === 0 ? (
          <p className="text-sm text-muted-foreground">No questions added yet.</p>
        ) : (
          questions.map((question) => (
            <div key={question.id} className="flex items-start gap-3 rounded-xl border p-4">
              <span className="text-sm font-semibold text-muted-foreground">
                Q{question.question_no}
              </span>
              <p className="min-w-0 flex-1 text-sm">{question.question_text}</p>
              <span className="text-xs text-muted-foreground">{question.marks} marks</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => removeQuestion.mutate(question.id)}
                aria-label="Remove question"
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          ))
        )}
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto_auto] sm:items-end">
        <Field label="Question">
          <Textarea rows={2} value={text} onChange={(e) => setText(e.target.value)} />
        </Field>
        <Field label="Marks">
          <Input
            type="number"
            className="sm:w-24"
            value={marks}
            onChange={(e) => setMarks(e.target.value)}
          />
        </Field>
        <Button onClick={() => addQuestion.mutate()} disabled={!text.trim() || addQuestion.isPending}>
          <Plus className="size-4" /> Add
        </Button>
      </div>
    </section>
  );
}

type StudentRow = { id: string; full_name: string; student_id: string | null };

function MarksPanel({
  examId,
  totalMarks,
  students,
  graderProfileId,
}: {
  examId: string;
  totalMarks: number;
  students: StudentRow[];
  graderProfileId: string | null;
}) {
  const queryClient = useQueryClient();
  const { data: marks = [] } = useQuery(examMarksQuery(examId));
  const { data: submissions = [] } = useQuery(examSubmissionsQuery(examId));
  const { data: questions = [] } = useQuery(examQuestionsQuery(examId));
  const [drafts, setDrafts] = useState<Record<string, { marks: string; remarks: string }>>({});
  const [openStudent, setOpenStudent] = useState<string | null>(null);

  const marksByStudent = useMemo(
    () => new Map(marks.map((row) => [row.student_profile_id, row])),
    [marks],
  );
  const submissionByStudent = useMemo(
    () => new Map(submissions.map((row) => [row.student_profile_id, row])),
    [submissions],
  );

  const saveMark = useMutation({
    mutationFn: async (studentId: string) => {
      const draft = drafts[studentId];
      const value = draft?.marks?.trim();
      const { error } = await localDb.from("exam_marks").upsert(
        {
          exam_id: examId,
          student_profile_id: studentId,
          marks_obtained: value === "" || value === undefined ? null : Number(value),
          remarks: draft?.remarks?.trim() || null,
          graded_by: graderProfileId,
        },
        { onConflict: "exam_id,student_profile_id" },
      );
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("Marks saved");
      void queryClient.invalidateQueries({ queryKey: ["exam-marks", examId] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <section className="surface-panel rounded-2xl border p-6">
      <h2 className="text-base font-semibold">Student marks &amp; answers</h2>
      <p className="text-xs text-muted-foreground">Out of {totalMarks} marks</p>
      <div className="mt-4 space-y-2">
        {students.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No students found for this semester and section.
          </p>
        ) : (
          students.map((student) => {
            const existing = marksByStudent.get(student.id);
            const submission = submissionByStudent.get(student.id);
            const draft = drafts[student.id] ?? {
              marks: existing?.marks_obtained != null ? String(existing.marks_obtained) : "",
              remarks: existing?.remarks ?? "",
            };
            const answers = answerMap(submission);
            const isOpen = openStudent === student.id;
            return (
              <div key={student.id} className="rounded-xl border p-4">
                <div className="flex flex-wrap items-end gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{student.full_name}</p>
                    <p className="text-xs text-muted-foreground">
                      {student.student_id ?? "—"} ·{" "}
                      {submission?.submitted_at ? "Answers submitted" : "Not submitted"}
                    </p>
                  </div>
                  <Input
                    type="number"
                    className="w-24"
                    placeholder="Marks"
                    value={draft.marks}
                    onChange={(e) =>
                      setDrafts({ ...drafts, [student.id]: { ...draft, marks: e.target.value } })
                    }
                  />
                  <Input
                    className="w-44"
                    placeholder="Remarks"
                    value={draft.remarks}
                    onChange={(e) =>
                      setDrafts({ ...drafts, [student.id]: { ...draft, remarks: e.target.value } })
                    }
                  />
                  <Button variant="outline" onClick={() => saveMark.mutate(student.id)}>
                    Save
                  </Button>
                  {submission ? (
                    <Button
                      variant="ghost"
                      onClick={() => setOpenStudent(isOpen ? null : student.id)}
                    >
                      {isOpen ? "Hide answers" : "View answers"}
                    </Button>
                  ) : null}
                </div>
                {isOpen ? (
                  <div className="mt-3 space-y-2 border-t pt-3">
                    {questions.map((question) => (
                      <div key={question.id} className="text-sm">
                        <p className="font-medium">
                          Q{question.question_no}. {question.question_text}
                        </p>
                        <p className="whitespace-pre-wrap text-muted-foreground">
                          {answers[question.id]?.trim() || "No answer"}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            );
          })
        )}
      </div>
    </section>
  );
}
