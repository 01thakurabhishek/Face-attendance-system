import { createFileRoute } from "@tanstack/react-router";
import { AttendanceHistory } from "@/components/AttendanceHistory";
import { FaceEnroll } from "@/components/FaceEnroll";
import { RoleGate } from "@/components/RoleGate";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/app/my-attendance")({
  head: () => ({
    meta: [
      { title: "My Attendance — AI Attendance System" },
      { name: "description", content: "Review your full attendance history subject by subject." },
      { property: "og:title", content: "My Attendance — AI Attendance System" },
      { property: "og:description", content: "Your attendance history." },
    ],
  }),
  component: MyAttendancePage,
});

function MyAttendancePage() {
  return (
    <RoleGate allow={["student"]}>
      <MyAttendanceContent />
    </RoleGate>
  );
}

function MyAttendanceContent() {
  const { profile, refreshProfile } = useAuth();
  if (!profile) return null;
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">My attendance</h1>
        <p className="text-sm text-muted-foreground">
          Every class you have been marked for, with your subject-wise percentage.
        </p>
      </div>
      <FaceEnroll
        profileId={profile.id}
        storageUserId={profile.user_id}
        personName={profile.full_name}
        enrolled={profile.face_enrolled}
        onEnrolled={() => void refreshProfile()}
      />
      <AttendanceHistory studentProfileId={profile.id} />
    </div>
  );
}
