import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2, Radio, ScanFace, ShieldAlert } from "lucide-react";
import { useCallback, useRef, useState } from "react";
import { toast } from "sonner";
import { EmptyState } from "@/components/EmptyState";
import { FaceScanner } from "@/components/FaceScanner";
import { PersonAvatar } from "@/components/PersonAvatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/lib/auth";
import { logTracking, markAttendance } from "@/lib/attendance";
import { evaluateFace, type DetectedFace, type KnownFace } from "@/lib/face";
import {
  attendanceQuery,
  faceEnrollmentsQuery,
  formatDate,
  formatTime,
  knownFacesFrom,
  lecturesQuery,
  profilesQuery,
} from "@/lib/queries";
import type { Profile } from "@/lib/types";

export const Route = createFileRoute("/app/live")({
  head: () => ({
    meta: [
      { title: "Live Attendance — AI Attendance System" },
      { name: "description", content: "Mark classroom attendance in real time with face recognition." },
      { property: "og:title", content: "Live Attendance — AI Attendance System" },
      { property: "og:description", content: "Real-time face recognition attendance." },
    ],
  }),
  component: LivePage,
});

function LivePage() {
  const { profile } = useAuth();
  return profile?.role === "teacher" ? <TeacherLive /> : <StudentLive />;
}

type Recognised = { profile: Profile; confidence: number; at: number; state: "marked" | "already" };
type Rejected = { reason: string; title: string; detail: string; at: number; count: number };

function TeacherLive() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const { data: lectures = [] } = useQuery(lecturesQuery());
  const { data: students = [] } = useQuery(profilesQuery("student"));
  const [lectureId, setLectureId] = useState<string>("");
  const [scanning, setScanning] = useState(false);
  const [recognised, setRecognised] = useState<Recognised[]>([]);
  const [rejected, setRejected] = useState<Rejected[]>([]);
  const inFlight = useRef(new Set<string>());

  const { data: marked = [] } = useQuery({
    ...attendanceQuery({ lectureId }),
    enabled: Boolean(lectureId),
  });

  const { data: enrollments = [] } = useQuery(faceEnrollmentsQuery());
  const known: KnownFace<Profile>[] = knownFacesFrom(students, enrollments);

  const labelFor = useCallback(
    (face: DetectedFace) => {
      const verdict = evaluateFace(face, known);
      if (verdict.ok) {
        return {
          text: `${verdict.match.person.full_name} · ${Math.round(verdict.match.confidence * 100)}%`,
          tone: "match" as const,
        };
      }
      return {
        text: verdict.title,
        tone: (verdict.reason === "too-small" || verdict.reason === "low-detection"
          ? "hint"
          : "unknown") as "hint" | "unknown",
      };
    },
    [known],
  );

  const noteRejection = useCallback((reason: string, title: string, detail: string) => {
    setRejected((prev) => {
      const existing = prev.find((r) => r.reason === reason);
      const next: Rejected = {
        reason,
        title,
        detail,
        at: Date.now(),
        count: (existing?.count ?? 0) + 1,
      };
      return [next, ...prev.filter((r) => r.reason !== reason)].slice(0, 5);
    });
  }, []);

  const handleDetections = useCallback(
    async (faces: DetectedFace[]) => {
      if (!lectureId || !profile) return;
      for (const face of faces) {
        const verdict = evaluateFace(face, known);
        if (!verdict.ok) {
          noteRejection(verdict.reason, verdict.title, verdict.detail);
          continue;
        }
        const match = verdict.match;
        const student = match.person;
        if (inFlight.current.has(student.id)) continue;
        inFlight.current.add(student.id);
        try {
          const result = await markAttendance({
            lectureId,
            studentProfileId: student.id,
            confidence: match.confidence,
            method: "face",
            markedBy: profile.id,
          });
          await logTracking({
            profileId: student.id,
            source: "live-camera",
            confidence: match.confidence,
            observedBy: profile.id,
          });
          setRecognised((prev) => [
            {
              profile: student,
              confidence: match.confidence,
              at: Date.now(),
              state: (result === "created" ? "marked" : "already") as Recognised["state"],
            },
            ...prev.filter((r) => r.profile.id !== student.id),
          ].slice(0, 25));
          if (result === "created") {
            toast.success(`${student.full_name} marked present`);
            await queryClient.invalidateQueries({ queryKey: ["attendance"] });
            await queryClient.invalidateQueries({ queryKey: ["tracking"] });
          }
        } catch (error) {
          toast.error(error instanceof Error ? error.message : "Could not mark attendance");
        } finally {
          window.setTimeout(() => inFlight.current.delete(student.id), 4000);
        }
      }
    },
    [known, lectureId, noteRejection, profile, queryClient],
  );


  const selected = lectures.find((l) => l.id === lectureId);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Live attendance</h1>
        <p className="text-sm text-muted-foreground">
          Point the camera at the class — recognised students are marked present automatically.
        </p>
      </div>

      {known.length === 0 ? (
        <EmptyState
          icon={ScanFace}
          title="No enrolled faces yet"
          description="Students need a registered face before the scanner can recognise them. Enroll faces from the Attendance page."
        />
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Session</CardTitle>
            <CardDescription>Choose the lecture attendance should be recorded against.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Select value={lectureId} onValueChange={setLectureId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a lecture" />
              </SelectTrigger>
              <SelectContent>
                {lectures.map((lecture) => (
                  <SelectItem key={lecture.id} value={lecture.id}>
                    {lecture.subject} · {formatDate(lecture.lecture_date)} · {formatTime(lecture.start_time)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <FaceScanner
              active={scanning && Boolean(lectureId)}
              onDetections={handleDetections}
              labelFor={labelFor}
            />


            <div className="flex flex-wrap items-center gap-2">
              <Button
                onClick={() => {
                  if (!lectureId) {
                    toast.error("Select a lecture first");
                    return;
                  }
                  setScanning((s) => !s);
                }}
                variant={scanning ? "secondary" : "default"}
              >
                <Radio className="size-4" /> {scanning ? "Stop scanning" : "Start scanning"}
              </Button>
              {selected ? (
                <Badge variant="outline" className="capitalize">
                  {selected.subject} · {selected.status}
                </Badge>
              ) : null}
              <span className="text-sm text-muted-foreground">{marked.length} marked</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recognised just now</CardTitle>
            <CardDescription>Live feed of matches from the camera.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {recognised.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nobody recognised yet.</p>
            ) : (
              recognised.map((entry) => (
                <div key={entry.profile.id} className="flex items-center gap-3 rounded-xl border p-3">
                  <PersonAvatar name={entry.profile.full_name} photoPath={entry.profile.photo_url} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{entry.profile.full_name}</p>
                    <p className="text-xs text-muted-foreground">
                      {entry.profile.student_id ?? "—"} · {Math.round(entry.confidence * 100)}% match
                    </p>
                  </div>
                  <Badge variant={entry.state === "marked" ? "default" : "secondary"}>
                    {entry.state === "marked" ? "Marked" : "Already"}
                  </Badge>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Rejected faces</CardTitle>
            <CardDescription>
              Faces seen by the camera that were refused before any attendance was submitted.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {rejected.length === 0 ? (
              <p className="text-sm text-muted-foreground">No rejections — every face in frame matched.</p>
            ) : (
              rejected.map((entry) => (
                <div
                  key={entry.reason}
                  className="flex items-start gap-3 rounded-xl border border-destructive/40 bg-destructive/5 p-3"
                >
                  <ShieldAlert className="mt-0.5 size-4 shrink-0 text-destructive" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">{entry.title}</p>
                    <p className="text-xs text-muted-foreground">{entry.detail}</p>
                  </div>
                  <Badge variant="outline">×{entry.count}</Badge>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StudentLive() {
  const { profile } = useAuth();
  const { data: lectures = [] } = useQuery(lecturesQuery());
  const { data: attendance = [] } = useQuery({
    ...attendanceQuery({ studentProfileId: profile?.id ?? "" }),
    enabled: Boolean(profile?.id),
  });

  const live = lectures.filter(
    (l) =>
      l.status === "live" &&
      (!profile?.semester || !l.semester || l.semester === profile.semester) &&
      (!profile?.section || !l.section || l.section === profile.section),
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Live sessions</h1>
        <p className="text-sm text-muted-foreground">
          Sessions running right now for your class. Your teacher's camera marks you present.
        </p>
      </div>

      {live.length === 0 ? (
        <EmptyState
          icon={Radio}
          title="No live session right now"
          description="When your teacher starts a session it will appear here."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {live.map((lecture) => {
            const mine = attendance.find((a) => a.lecture_id === lecture.id);
            return (
              <Card key={lecture.id}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">{lecture.subject}</CardTitle>
                  <CardDescription>
                    {formatTime(lecture.start_time)} – {formatTime(lecture.end_time)} · {lecture.room ?? "—"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex items-center gap-2 text-sm">
                  {mine ? (
                    <>
                      <CheckCircle2 className="size-4 text-primary" />
                      <span className="capitalize">You are marked {mine.status}</span>
                    </>
                  ) : (
                    <span className="text-muted-foreground">Not marked yet</span>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Button variant="outline" asChild>
        <Link to="/app/my-attendance">View my attendance</Link>
      </Button>
    </div>
  );
}
