import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarDays, Loader2, Pencil, Play, Plus, Square, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { EmptyState } from "@/components/EmptyState";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { localDb } from "@/integrations/local/client";
import { useAuth } from "@/lib/auth";
import { attendanceQuery, formatDate, formatTime, lecturesQuery } from "@/lib/queries";
import { COURSES, DEPARTMENTS, SECTIONS, SEMESTERS, type Lecture } from "@/lib/types";

export const Route = createFileRoute("/app/lectures")({
  head: () => ({
    meta: [
      { title: "Lectures — AI Attendance System" },
      { name: "description", content: "Schedule, start and manage lecture sessions for your classes." },
      { property: "og:title", content: "Lectures — AI Attendance System" },
      { property: "og:description", content: "Schedule and manage lecture sessions." },
    ],
  }),
  component: LecturesPage,
});

type FormState = {
  subject: string;
  course: string;
  department: string;
  semester: string;
  section: string;
  lecture_date: string;
  start_time: string;
  end_time: string;
  room: string;
};

const emptyForm: FormState = {
  subject: "",
  course: COURSES[0] ?? "B.Tech",
  department: DEPARTMENTS[0] ?? "",
  semester: SEMESTERS[0] ?? "1",
  section: SECTIONS[0] ?? "A",
  lecture_date: new Date().toISOString().slice(0, 10),
  start_time: "09:00",
  end_time: "10:00",
  room: "",
};

function LecturesPage() {
  const { profile } = useAuth();
  const isTeacher = profile?.role === "teacher";
  const queryClient = useQueryClient();
  const { data: lectures = [], isLoading } = useQuery(lecturesQuery());
  const { data: attendance = [] } = useQuery(attendanceQuery());
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Lecture | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);

  const countFor = (lectureId: string) => attendance.filter((r) => r.lecture_id === lectureId).length;

  const visible = isTeacher
    ? lectures
    : lectures.filter(
        (l) =>
          (!profile?.semester || !l.semester || l.semester === profile.semester) &&
          (!profile?.section || !l.section || l.section === profile.section),
      );

  const save = useMutation({
    mutationFn: async () => {
      if (!profile) throw new Error("Not signed in");
      const payload = { ...form, teacher_profile_id: profile.id };
      if (editing) {
        const { error } = await localDb.from("lectures").update(payload).eq("id", editing.id);
        if (error) throw new Error(error.message);
      } else {
        const { error } = await localDb.from("lectures").insert(payload);
        if (error) throw new Error(error.message);
      }
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["lectures"] });
      toast.success(editing ? "Lecture updated" : "Lecture scheduled");
      setOpen(false);
      setEditing(null);
      setForm(emptyForm);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: Lecture["status"] }) => {
      const { error } = await localDb.from("lectures").update({ status }).eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["lectures"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await localDb.from("lectures").delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["lectures"] });
      toast.success("Lecture deleted");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const startEdit = (lecture: Lecture) => {
    setEditing(lecture);
    setForm({
      subject: lecture.subject,
      course: lecture.course ?? "",
      department: lecture.department ?? "",
      semester: lecture.semester ?? "",
      section: lecture.section ?? "",
      lecture_date: lecture.lecture_date,
      start_time: lecture.start_time.slice(0, 5),
      end_time: lecture.end_time.slice(0, 5),
      room: lecture.room ?? "",
    });
    setOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold">Lectures</h1>
          <p className="text-sm text-muted-foreground">
            {isTeacher
              ? "Schedule sessions, start live attendance and review each class."
              : "Sessions scheduled for your semester and section."}
          </p>
        </div>
        {isTeacher ? (
          <Button
            onClick={() => {
              setEditing(null);
              setForm(emptyForm);
              setOpen(true);
            }}
          >
            <Plus className="size-4" /> New lecture
          </Button>
        ) : null}
      </div>

      {isLoading ? (
        <Loader2 className="size-5 animate-spin text-muted-foreground" />
      ) : visible.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="No lectures yet"
          description={
            isTeacher
              ? "Create your first lecture to start marking attendance."
              : "Your teachers haven't scheduled any classes for your section yet."
          }
        />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {visible.map((lecture) => (
            <Card key={lecture.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <CardTitle className="text-base">{lecture.subject}</CardTitle>
                    <CardDescription>
                      {formatDate(lecture.lecture_date)} · {formatTime(lecture.start_time)} –{" "}
                      {formatTime(lecture.end_time)}
                    </CardDescription>
                  </div>
                  <Badge
                    variant={
                      lecture.status === "live"
                        ? "default"
                        : lecture.status === "ended"
                          ? "secondary"
                          : "outline"
                    }
                    className="capitalize"
                  >
                    {lecture.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <dl className="grid grid-cols-2 gap-y-1 text-muted-foreground">
                  <div>
                    Course: <span className="text-foreground">{lecture.course ?? "—"}</span>
                  </div>
                  <div>
                    Room: <span className="text-foreground">{lecture.room ?? "—"}</span>
                  </div>
                  <div>
                    Semester: <span className="text-foreground">{lecture.semester ?? "—"}</span>
                  </div>
                  <div>
                    Section: <span className="text-foreground">{lecture.section ?? "—"}</span>
                  </div>
                  {isTeacher ? (
                    <div className="col-span-2">
                      Marked present:{" "}
                      <span className="text-foreground">{countFor(lecture.id)} students</span>
                    </div>
                  ) : null}
                </dl>

                {isTeacher ? (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {lecture.status !== "live" ? (
                      <Button
                        size="sm"
                        onClick={() => setStatus.mutate({ id: lecture.id, status: "live" })}
                      >
                        <Play className="size-4" /> Start session
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => setStatus.mutate({ id: lecture.id, status: "ended" })}
                      >
                        <Square className="size-4" /> End session
                      </Button>
                    )}
                    <Button size="sm" variant="outline" asChild>
                      <Link to="/app/live">Live attendance</Link>
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => startEdit(lecture)}>
                      <Pencil className="size-4" /> Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive"
                      onClick={() => remove.mutate(lecture.id)}
                    >
                      <Trash2 className="size-4" /> Delete
                    </Button>
                  </div>
                ) : null}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit lecture" : "Schedule a lecture"}</DialogTitle>
            <DialogDescription>Students in the matching semester and section will see it.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Label htmlFor="subject">Subject</Label>
              <Input
                id="subject"
                value={form.subject}
                onChange={(e) => setForm({ ...form, subject: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="course">Course</Label>
              <Input
                id="course"
                value={form.course}
                onChange={(e) => setForm({ ...form, course: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="department">Department</Label>
              <Input
                id="department"
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="semester">Semester</Label>
              <Input
                id="semester"
                value={form.semester}
                onChange={(e) => setForm({ ...form, semester: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="section">Section</Label>
              <Input
                id="section"
                value={form.section}
                onChange={(e) => setForm({ ...form, section: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="lecture_date">Date</Label>
              <Input
                id="lecture_date"
                type="date"
                value={form.lecture_date}
                onChange={(e) => setForm({ ...form, lecture_date: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="room">Room</Label>
              <Input id="room" value={form.room} onChange={(e) => setForm({ ...form, room: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="start_time">Start time</Label>
              <Input
                id="start_time"
                type="time"
                value={form.start_time}
                onChange={(e) => setForm({ ...form, start_time: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="end_time">End time</Label>
              <Input
                id="end_time"
                type="time"
                value={form.end_time}
                onChange={(e) => setForm({ ...form, end_time: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (!form.subject.trim()) {
                  toast.error("Subject is required");
                  return;
                }
                save.mutate();
              }}
              disabled={save.isPending}
            >
              {save.isPending ? <Loader2 className="size-4 animate-spin" /> : null}
              {editing ? "Save changes" : "Schedule"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
