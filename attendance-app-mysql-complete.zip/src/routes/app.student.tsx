import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  Clock,
  Percent,
  XCircle,
} from "lucide-react";
import { AttendancePieChart } from "@/components/AttendancePieChart";
import { StatCard } from "@/components/StatCard";
import { EmptyState } from "@/components/EmptyState";
import { useAuth } from "@/lib/auth";
import { matchesClass } from "@/lib/classScope";
import { attendanceQuery, attendanceRate, formatDate, formatTime, lecturesQuery } from "@/lib/queries";
import type { AttendanceRow } from "@/lib/queries";
import type { Lecture } from "@/lib/types";

export const Route = createFileRoute("/app/student")({
  head: () => ({
    meta: [
      { title: "Student Dashboard — AI Attendance System" },
      {
        name: "description",
        content: "See your attendance percentage, upcoming classes and recent check-ins.",
      },
      { property: "og:title", content: "Student Dashboard — AI Attendance System" },
      { property: "og:description", content: "Your attendance record at a glance." },
    ],
  }),
  component: StudentDashboard,
});

function StudentDashboard() {
  const { profile } = useAuth();
  const { data: attendance = [] } = useQuery({
    ...attendanceQuery({ studentProfileId: profile?.id ?? "" }),
    enabled: Boolean(profile?.id),
  });
  const { data: lectures = [] } = useQuery(lecturesQuery());

  const present = attendance.filter((row) => row.status === "present").length;
  const late = attendance.filter((row) => row.status === "late").length;
  const absent = attendance.filter((row) => row.status === "absent").length;
  const rate = attendanceRate(present + late, attendance.length);

  const today = new Date().toISOString().slice(0, 10);
  const upcoming = lectures
    .filter(
      (lecture) =>
        lecture.lecture_date >= today &&
        matchesClass(profile, lecture),
    )
    .sort((a, b) => (a.lecture_date + a.start_time).localeCompare(b.lecture_date + b.start_time));

  const byDay = new Map<string, typeof upcoming>();
  for (const lecture of upcoming) {
    const list = byDay.get(lecture.lecture_date) ?? [];
    list.push(lecture);
    byDay.set(lecture.lecture_date, list);
  }

  function dayLabel(dateStr: string) {
    if (dateStr === today) return "Today";
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    if (dateStr === tomorrow.toISOString().slice(0, 10)) return "Tomorrow";
    return new Date(`${dateStr}T00:00:00`).toLocaleDateString(undefined, {
      weekday: "long",
      day: "numeric",
      month: "short",
    });
  }

  const myLectures = lectures.filter(
    (lecture) =>
      matchesClass(profile, lecture),
  );

  const attendanceByLecture = new Map<string, AttendanceRow>();
  for (const row of attendance) {
    if (row.lecture_id) attendanceByLecture.set(row.lecture_id, row);
  }

  type DayLecture = Lecture & {
    attendanceStatus: AttendanceRow["status"] | "upcoming" | "not-marked";
  };
  const lecturesByDay = new Map<string, DayLecture[]>();
  for (const lecture of myLectures) {
    const recorded = attendanceByLecture.get(lecture.id);
    const attendanceStatus: DayLecture["attendanceStatus"] = recorded
      ? recorded.status
      : lecture.lecture_date >= today
        ? "upcoming"
        : "not-marked";
    const list = lecturesByDay.get(lecture.lecture_date) ?? [];
    list.push({ ...lecture, attendanceStatus });
    lecturesByDay.set(lecture.lecture_date, list);
  }

  const sortedDays = [...lecturesByDay.entries()].sort(([a], [b]) => a.localeCompare(b));

  function statusBadge(status: AttendanceRow["status"] | "upcoming" | "not-marked") {
    switch (status) {
      case "present":
        return "rounded-full bg-success/15 px-2.5 py-1 text-xs font-medium text-success";
      case "late":
        return "rounded-full bg-warning/20 px-2.5 py-1 text-xs font-medium text-warning";
      case "absent":
        return "rounded-full bg-destructive/10 px-2.5 py-1 text-xs font-medium text-destructive";
      case "upcoming":
        return "rounded-full bg-secondary px-2.5 py-1 text-xs text-muted-foreground";
      default:
        return "rounded-full border border-dashed px-2.5 py-1 text-xs text-muted-foreground";
    }
  }

  return (
    <div className="space-y-8">
      <header>
        <h1 className="font-display text-3xl font-semibold tracking-tight">
          Hi, {profile?.full_name?.split(" ")[0]}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {profile?.course} · Semester {profile?.semester} · Section {profile?.section}
        </p>
      </header>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Attendance"
          value={`${rate}%`}
          hint={rate >= 75 ? "You're above the 75% requirement" : "Below the 75% requirement"}
          icon={Percent}
          tone={rate >= 75 ? "success" : "destructive"}
        />
        <StatCard label="Present" value={present} icon={CheckCircle2} tone="success" delay={60} />
        <StatCard label="Late" value={late} icon={ClipboardList} tone="warning" delay={120} />
        <StatCard label="Absent" value={absent} icon={XCircle} tone="destructive" delay={180} />
      </section>

      <section>
        <AttendancePieChart
          title="Your attendance breakdown"
          counts={{ present, late, absent }}
        />
      </section>

      <section className="surface-panel rounded-2xl border p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold">Day-wise lectures</h2>
          <Link to="/app/schedule" className="text-sm text-primary hover:underline">
            Full schedule
          </Link>
        </div>
        <div className="mt-4 space-y-5">
          {sortedDays.length === 0 ? (
            <EmptyState
              icon={CalendarDays}
              title="No lectures found"
              description="Lectures scheduled for your section will appear here."
            />
          ) : (
            sortedDays.map(([date, dayLectures]) => (
              <div key={date}>
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  {dayLabel(date)} · {formatDate(date)}
                </h3>
                <div className="space-y-2">
                  {dayLectures
                    .sort((a, b) => a.start_time.localeCompare(b.start_time))
                    .map((lecture) => (
                      <div
                        key={lecture.id}
                        className="flex items-center justify-between rounded-xl border p-4"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="truncate font-medium">{lecture.subject}</p>
                          <p className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {formatTime(lecture.start_time)} – {formatTime(lecture.end_time)}
                            {lecture.room ? ` · ${lecture.room}` : ""}
                          </p>
                        </div>
                        <span className={statusBadge(lecture.attendanceStatus)}>
                          {lecture.attendanceStatus === "not-marked"
                            ? "Not marked"
                            : lecture.attendanceStatus === "upcoming"
                              ? "Upcoming"
                              : lecture.attendanceStatus}
                        </span>
                      </div>
                    ))}
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <div className="surface-panel rounded-2xl border p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold">Upcoming classes</h2>
            <Link to="/app/schedule" className="text-sm text-primary hover:underline">
              Full schedule
            </Link>
          </div>
          <div className="mt-4 space-y-5">
            {upcoming.length === 0 ? (
              <EmptyState
                icon={CalendarDays}
                title="No upcoming classes"
                description="Lectures scheduled by your teachers will appear here."
              />
            ) : (
              [...byDay.entries()].map(([date, dayLectures]) => (
                <div key={date}>
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    {dayLabel(date)}
                  </h3>
                  <div className="space-y-2">
                    {dayLectures.map((lecture) => (
                      <div
                        key={lecture.id}
                        className="flex items-center justify-between rounded-xl border p-4"
                      >
                        <div>
                          <p className="font-medium">{lecture.subject}</p>
                          <p className="text-xs text-muted-foreground">
                            {formatTime(lecture.start_time)} – {formatTime(lecture.end_time)}
                            {lecture.room ? ` · ${lecture.room}` : ""}
                          </p>
                        </div>
                        <span className="rounded-full bg-secondary px-2.5 py-1 text-xs capitalize">
                          {lecture.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="surface-panel rounded-2xl border p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold">Recent attendance</h2>
            <Link to="/app/my-attendance" className="text-sm text-primary hover:underline">
              View all
            </Link>
          </div>
          <div className="mt-4 space-y-3">
            {attendance.length === 0 ? (
              <EmptyState
                icon={ClipboardList}
                title="No records yet"
                description="Your attendance appears here after your first recognised class."
              />
            ) : (
              attendance.slice(0, 6).map((row) => (
                <div key={row.id} className="flex items-center justify-between rounded-xl border p-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{row.lectures?.subject}</p>
                    <p className="text-xs text-muted-foreground">
                      {row.lectures ? formatDate(row.lectures.lecture_date) : ""}
                    </p>
                  </div>
                  <span
                    className={
                      row.status === "present"
                        ? "rounded-full bg-success/15 px-2.5 py-1 text-xs font-medium text-success"
                        : row.status === "late"
                          ? "rounded-full bg-warning/20 px-2.5 py-1 text-xs font-medium text-warning"
                          : "rounded-full bg-destructive/10 px-2.5 py-1 text-xs font-medium text-destructive"
                    }
                  >
                    {row.status}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
