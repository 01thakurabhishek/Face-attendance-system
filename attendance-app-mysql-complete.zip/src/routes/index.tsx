import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BarChart3,
  CalendarDays,
  CheckCircle2,
  Radar,
  ScanFace,
  ShieldCheck,
  Users,
  Video,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AI Attendance System — Face Recognition Attendance for Colleges" },
      {
        name: "description",
        content:
          "Mark attendance in seconds with real face recognition, live camera and video scanning, lecture scheduling, student tracking and instant analytics.",
      },
      {
        property: "og:title",
        content: "AI Attendance System — Face Recognition Attendance for Colleges",
      },
      {
        property: "og:description",
        content:
          "Real face-recognition attendance with live camera scanning, lecture management and analytics for teachers and students.",
      },
    ],
  }),
  component: Landing,
});

const features = [
  {
    icon: ScanFace,
    title: "Live Face Attendance",
    text: "Open the camera, scan the classroom and mark present students automatically with on-device face recognition.",
  },
  {
    icon: Video,
    title: "Video Scanning",
    text: "Upload a classroom recording and the system extracts frames, matches every registered face and fills the register.",
  },
  {
    icon: CalendarDays,
    title: "Lecture Management",
    text: "Schedule lectures per subject, semester and section, then start or close sessions in a single click.",
  },
  {
    icon: Radar,
    title: "Live Tracking",
    text: "Follow who has been recognised during an active session in real time, with timestamps and confidence scores.",
  },
  {
    icon: BarChart3,
    title: "Reports & Analytics",
    text: "Attendance percentages, subject-wise trends and defaulter lists, exportable to CSV or PDF.",
  },
  {
    icon: ShieldCheck,
    title: "Secure by Design",
    text: "Hashed credentials, session tokens and strict role-based access. Students only ever see their own record.",
  },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <span className="gradient-hero grid size-9 place-items-center rounded-xl">
              <ScanFace className="size-5 text-white" />
            </span>
            <span className="font-display text-base font-semibold">AI Attendance System</span>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button asChild variant="ghost" className="hidden sm:inline-flex">
              <Link to="/auth" search={{ mode: "login" }}>
                Login
              </Link>
            </Button>
            <Button asChild>
              <Link to="/auth" search={{ mode: "register" }}>
                Get started
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-6xl gap-12 px-4 py-20 lg:grid-cols-2 lg:items-center lg:py-28">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full border bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
              <span className="size-2 rounded-full bg-success" /> Real face recognition, no manual roll call
            </span>
            <h1 className="mt-5 font-display text-4xl font-semibold leading-tight tracking-tight sm:text-5xl">
              Attendance that marks{" "}
              <span className="text-gradient-hero">itself</span>, the moment students walk in.
            </h1>
            <p className="mt-5 max-w-xl text-base text-muted-foreground">
              A complete AI attendance and tracking platform for colleges — face-recognition
              check-in, lecture scheduling, live session tracking, and analytics for teachers and
              students in one place.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/auth" search={{ mode: "register" }}>
                  Create your account
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/auth" search={{ mode: "login" }}>
                  I already have one
                </Link>
              </Button>
            </div>
            <ul className="mt-8 grid gap-2 text-sm text-muted-foreground sm:grid-cols-2">
              {[
                "Works on any laptop webcam",
                "Teacher and student portals",
                "CSV & PDF exports",
                "Light and dark themes",
              ].map((item) => (
                <li key={item} className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-success" /> {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="animate-fade-up surface-panel relative rounded-3xl border p-6 [animation-delay:120ms]">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">Live session · Data Structures</p>
              <span className="rounded-full bg-success/15 px-2.5 py-1 text-xs font-medium text-success">
                Scanning
              </span>
            </div>
            <div className="mt-5 grid gap-3">
              {[
                { name: "Recognised", value: "38", icon: Users, tone: "text-success" },
                { name: "Absent", value: "4", icon: Users, tone: "text-destructive" },
                { name: "Avg. confidence", value: "94%", icon: ScanFace, tone: "text-primary" },
              ].map((row) => (
                <div
                  key={row.name}
                  className="flex items-center justify-between rounded-xl border bg-background/60 px-4 py-3"
                >
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <row.icon className={`size-4 ${row.tone}`} /> {row.name}
                  </span>
                  <span className="font-display text-lg font-semibold">{row.value}</span>
                </div>
              ))}
            </div>
            <p className="mt-5 text-xs text-muted-foreground">
              Illustration of the live attendance panel. Your real data appears once you register
              students and start a lecture.
            </p>
          </div>
        </div>
      </section>

      <section className="border-t bg-secondary/40 py-20">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="font-display text-3xl font-semibold tracking-tight">
            Everything a department needs
          </h2>
          <p className="mt-2 max-w-2xl text-muted-foreground">
            Built around how classes actually run — from scheduling a lecture to exporting the
            semester attendance report.
          </p>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <article
                key={feature.title}
                className="surface-panel animate-fade-up rounded-2xl border p-6"
                style={{ animationDelay: `${index * 60}ms` }}
              >
                <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
                  <feature.icon className="size-5" />
                </span>
                <h3 className="mt-4 text-base font-semibold">{feature.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{feature.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <h2 className="font-display text-3xl font-semibold tracking-tight">
            Ready to retire the paper register?
          </h2>
          <p className="mt-3 text-muted-foreground">
            Register as a teacher to run lectures and attendance, or as a student to track your own
            record.
          </p>
          <Button asChild size="lg" className="mt-7">
            <Link to="/auth" search={{ mode: "register" }}>
              Get started free
            </Link>
          </Button>
        </div>
      </section>

      <footer className="border-t py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 text-sm text-muted-foreground sm:flex-row">
          <p>AI Attendance System</p>
          <p>Face recognition runs locally in your browser.</p>
        </div>
      </footer>
    </div>
  );
}
