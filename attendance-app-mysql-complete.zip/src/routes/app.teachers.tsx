import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BookOpen, GraduationCap, Mail, Phone, Search } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { PersonAvatar } from "@/components/PersonAvatar";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { profilesQuery } from "@/lib/queries";
import { DEPARTMENTS, type Profile } from "@/lib/types";

export const Route = createFileRoute("/app/teachers")({
  head: () => ({
    meta: [
      { title: "Teachers Directory — AI Attendance System" },
      {
        name: "description",
        content:
          "Browse every teacher at your institute with photo, designation, department, subjects and contact details.",
      },
      { property: "og:title", content: "Teachers Directory — AI Attendance System" },
      { property: "og:description", content: "Faculty profiles for your institute." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TeachersPage,
});

const ALL = "all";

function TeachersPage() {
  const { data: teachers = [], isLoading } = useQuery(profilesQuery("teacher"));
  const [search, setSearch] = useState("");
  const [branch, setBranch] = useState(ALL);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return teachers.filter((teacher) => {
      if (branch !== ALL && teacher.department !== branch) return false;
      if (!term) return true;
      return [teacher.full_name, teacher.teacher_id, teacher.email, teacher.designation]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(term));
    });
  }, [teachers, branch, search]);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-2xl font-semibold">Teachers</h1>
        <p className="text-sm text-muted-foreground">
          Faculty members registered under your institute.
        </p>
      </header>

      <Card>
        <CardContent className="grid gap-4 p-4 sm:grid-cols-[1fr_220px]">
          <div className="space-y-2">
            <Label htmlFor="search">Search</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Name, teacher ID or email"
                className="pl-9"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Department</Label>
            <Select value={branch} onValueChange={setBranch}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>All departments</SelectItem>
                {DEPARTMENTS.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading teachers…</p>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={GraduationCap}
          title="No teachers found"
          description="Try a different search term or department filter."
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((teacher) => (
            <TeacherCard key={teacher.id} teacher={teacher} />
          ))}
        </div>
      )}
    </div>
  );
}

function TeacherCard({ teacher }: { teacher: Profile }) {
  return (
    <Card>
      <CardContent className="space-y-4 p-5">
        <div className="flex items-center gap-3">
          <PersonAvatar
            name={teacher.full_name}
            photoPath={teacher.photo_url}
            className="size-14"
          />
          <div className="min-w-0">
            <p className="truncate font-medium">{teacher.full_name}</p>
            <p className="truncate text-xs text-muted-foreground">
              {teacher.designation ?? "Faculty"} · {teacher.teacher_id ?? "—"}
            </p>
          </div>
        </div>
        <div className="space-y-1.5 text-sm">
          <p className="text-muted-foreground">{teacher.department ?? "—"}</p>
          <p className="flex items-center gap-2 truncate">
            <Mail className="size-3.5 text-muted-foreground" /> {teacher.email}
          </p>
          {teacher.phone ? (
            <p className="flex items-center gap-2">
              <Phone className="size-3.5 text-muted-foreground" /> {teacher.phone}
            </p>
          ) : null}
          {teacher.subjects?.length ? (
            <p className="flex items-start gap-2">
              <BookOpen className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" />
              <span>{teacher.subjects.join(", ")}</span>
            </p>
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}
