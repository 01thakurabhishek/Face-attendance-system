import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Clock, Radar, Radio } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { EmptyState } from "@/components/EmptyState";
import { FaceScanner } from "@/components/FaceScanner";
import { PersonAvatar } from "@/components/PersonAvatar";
import { RoleGate } from "@/components/RoleGate";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { localDb } from "@/integrations/local/client";
import { logTracking } from "@/lib/attendance";
import { useAuth } from "@/lib/auth";
import { isUsableFace, matchFace, type DetectedFace, type KnownFace } from "@/lib/face";
import { faceEnrollmentsQuery, knownFacesFrom, profilesQuery, trackingQuery, type TrackingRow } from "@/lib/queries";
import type { Profile } from "@/lib/types";

export const Route = createFileRoute("/app/tracking")({
  head: () => ({
    meta: [
      { title: "Live Tracking — AI Attendance System" },
      { name: "description", content: "Watch face detections stream in live during a classroom session." },
      { property: "og:title", content: "Live Tracking — AI Attendance System" },
      { property: "og:description", content: "Live detection log." },
    ],
  }),
  component: TrackingPage,
});

function TrackingPage() {
  return (
    <RoleGate allow={["teacher"]}>
      <TrackingContent />
    </RoleGate>
  );
}

function TrackingContent() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const { data: logs = [] } = useQuery(trackingQuery());
  const { data: people = [] } = useQuery(profilesQuery());
  const [tracking, setTracking] = useState(false);
  const [sessionStart, setSessionStart] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const cooldown = useRef(new Map<string, number>());

  useEffect(() => {
    if (!tracking) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [tracking]);

  const sessionElapsed = sessionStart ? Math.max(0, now - sessionStart) : 0;

  // Detection intervals are estimates, not proof of continuous classroom presence.
  const timeInClass = useMemo(() => {
    const byStudent = new Map<string, { profile: NonNullable<TrackingRow["profiles"]>; first: number; last: number; hits: number }>();
    const dayStart = new Date();
    dayStart.setHours(0, 0, 0, 0);
    for (const log of logs) {
      if (!log.profile_id || !log.profiles || log.profiles.role !== "student") continue;
      const at = new Date(log.detected_at).getTime();
      if (at < (sessionStart ?? dayStart.getTime())) continue;
      const entry = byStudent.get(log.profile_id);
      if (!entry) {
        byStudent.set(log.profile_id, { profile: log.profiles, first: at, last: at, hits: 1 });
      } else {
        entry.first = Math.min(entry.first, at);
        entry.last = Math.max(entry.last, at);
        entry.hits += 1;
      }
    }
    return [...byStudent.values()].sort((a, b) => b.last - b.first - (a.last - a.first));
  }, [logs, sessionStart]);

  const formatClock = (ms: number) => new Date(ms).toLocaleTimeString();
  const formatDuration = (ms: number) => {
    const mins = Math.floor(ms / 60000);
    if (mins < 1) return "<1 min";
    const h = Math.floor(mins / 60);
    return h > 0 ? `${h}h ${mins % 60}m` : `${mins} min`;
  };

  useEffect(() => {
    const channel = localDb
      .channel("tracking-logs")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "tracking_logs" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["tracking"] });
      })
      .subscribe();
    return () => {
      void localDb.removeChannel(channel);
    };
  }, [queryClient]);

  const { data: enrollments = [] } = useQuery(faceEnrollmentsQuery());
  const known: KnownFace<Profile>[] = knownFacesFrom(people, enrollments);

  const labelFor = useCallback(
    (face: DetectedFace) => {
      if (!isUsableFace(face)) return { text: "Move closer", tone: "hint" as const };
      const match = matchFace(face.descriptor, known);
      if (!match) return { text: "Unknown face", tone: "unknown" as const };
      return {
        text: `${match.person.full_name} · ${Math.round(match.confidence * 100)}%`,
        tone: "match" as const,
      };
    },
    [known],
  );

  const onDetections = useCallback(
    async (faces: DetectedFace[]) => {
      const now = Date.now();
      for (const face of faces) {
        if (!isUsableFace(face)) continue;
        const match = matchFace(face.descriptor, known);
        const key = match?.person.id ?? "unknown";
        const last = cooldown.current.get(key) ?? 0;
        if (now - last < 8000) continue;
        cooldown.current.set(key, now);
        try {
          await logTracking({
            profileId: match?.person.id ?? null,
            source: "live-camera",
            confidence: match?.confidence ?? null,
            observedBy: profile?.id ?? null,
          });
        } catch {
          /* ignore transient insert errors while tracking */
        }
      }
    },
    [known, profile],
  );


  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Live tracking</h1>
        <p className="text-sm text-muted-foreground">
          Log everyone the camera sees — recognised or not — without marking attendance.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Camera</CardTitle>
            <CardDescription>Detections are recorded every few seconds per person.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <FaceScanner active={tracking} onDetections={onDetections} labelFor={labelFor} intervalMs={2000} />
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="size-4" /> Session: {formatDuration(sessionElapsed)}
            </div>
            <Button variant={tracking ? "secondary" : "default"} onClick={() => {
              const timestamp = Date.now();
              setNow(timestamp);
              if (!tracking) { setSessionStart(timestamp); cooldown.current.clear(); }
              setTracking(!tracking);
            }}>
              <Radio className="size-4" /> {tracking ? "Stop tracking" : "Start tracking"}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Detection log</CardTitle>
            <CardDescription>Updates live as new detections arrive.</CardDescription>
          </CardHeader>
          <CardContent className="max-h-[520px] space-y-3 overflow-y-auto">
            {logs.length === 0 ? (
              <EmptyState
                icon={Radar}
                title="Nothing tracked yet"
                description="Start the camera to begin logging detections."
              />
            ) : (
              logs.map((log) => (
                <div key={log.id} className="flex items-center gap-3 rounded-xl border p-3">
                  <PersonAvatar name={log.profiles?.full_name ?? "Unknown"} photoPath={log.profiles?.photo_url} className="size-8" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{log.profiles?.full_name ?? "Unrecognised face"}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(log.detected_at).toLocaleString()} · {log.source}
                    </p>
                  </div>
                  <Badge variant={log.profiles ? "default" : "secondary"}>
                    {log.confidence ? `${Math.round(log.confidence * 100)}%` : "—"}
                  </Badge>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      <section className="space-y-3">
        <h2 className="text-base font-semibold">Student detection times</h2>
        {timeInClass.length === 0 ? (
          <p className="text-sm text-muted-foreground">No students detected in this session.</p>
        ) : timeInClass.map((entry) => (
          <div key={entry.profile.id} className="flex flex-wrap items-center justify-between gap-3 border-b py-3">
            <div className="flex items-center gap-3">
              <PersonAvatar name={entry.profile.full_name} photoPath={entry.profile.photo_url} />
              <div>
                <p className="text-sm font-medium">{entry.profile.full_name}</p>
                <p className="text-xs text-muted-foreground">
                  First seen {formatClock(entry.first)} · Last seen {formatClock(entry.last)}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium">{formatDuration(entry.last - entry.first)} detected span</p>
              <p className="text-xs text-muted-foreground">{entry.hits} detections</p>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
