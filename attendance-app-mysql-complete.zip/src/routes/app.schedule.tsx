import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { CalendarDays } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/lib/auth";
import { matchesClass } from "@/lib/classScope";
import { formatDate, formatTime, lecturesQuery } from "@/lib/queries";

export const Route = createFileRoute("/app/schedule")({
  head: () => ({
    meta: [
      { title: "Schedule — AI Attendance System" },
      { name: "description", content: "Your upcoming classes with time, room and status." },
      { property: "og:title", content: "Schedule — AI Attendance System" },
      { property: "og:description", content: "Upcoming class schedule." },
    ],
  }),
  component: SchedulePage,
});

function SchedulePage() {
  const { profile } = useAuth();
  const { data: lectures = [] } = useQuery(lecturesQuery());
  const today = new Date().toISOString().slice(0, 10);

  const mine = lectures
    .filter((l) => l.lecture_date >= today)
    .filter((l) =>
      profile?.role === "teacher"
        ? l.teacher_profile_id === profile.id
        : matchesClass(profile, l),
    )
    .sort((a, b) => (a.lecture_date + a.start_time).localeCompare(b.lecture_date + b.start_time));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Schedule</h1>
        <p className="text-sm text-muted-foreground">Upcoming classes, soonest first.</p>
      </div>
      {mine.length === 0 ? (
        <EmptyState icon={CalendarDays} title="Nothing scheduled" description="Upcoming classes will appear here." />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {mine.map((lecture) => (
            <Card key={lecture.id}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-base">{lecture.subject}</CardTitle>
                  <Badge variant="outline" className="capitalize">
                    {lecture.status}
                  </Badge>
                </div>
                <CardDescription>{formatDate(lecture.lecture_date)}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-1 text-sm text-muted-foreground">
                <p>
                  {formatTime(lecture.start_time)} – {formatTime(lecture.end_time)}
                </p>
                <p>
                  {lecture.room ?? "Room TBA"} · Sem {lecture.semester ?? "—"} · Sec {lecture.section ?? "—"}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
