import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Download, FileText, Printer } from "lucide-react";
import { useMemo, useState } from "react";
import { EmptyState } from "@/components/EmptyState";
import { StatCard } from "@/components/StatCard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAuth } from "@/lib/auth";
import { downloadCsv, printReport, tableHtml } from "@/lib/export";
import { attendanceQuery, formatDate, lecturesQuery, profilesQuery } from "@/lib/queries";

export const Route = createFileRoute("/app/reports")({
  head: () => ({
    meta: [
      { title: "Reports — AI Attendance System" },
      { name: "description", content: "Generate, filter and export attendance reports as CSV or PDF." },
      { property: "og:title", content: "Reports — AI Attendance System" },
      { property: "og:description", content: "Attendance reporting and exports." },
    ],
  }),
  component: ReportsPage,
});

function ReportsPage() {
  const { profile } = useAuth();
  const isTeacher = profile?.role === "teacher";

  const { data: attendance = [] } = useQuery(
    isTeacher ? attendanceQuery() : { ...attendanceQuery({ studentProfileId: profile?.id ?? "" }) },
  );
  const { data: lectures = [] } = useQuery(lecturesQuery());
  const { data: students = [] } = useQuery({ ...profilesQuery("student"), enabled: isTeacher });

  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("all");

  const subjects = useMemo(
    () => [...new Set(lectures.map((l) => l.subject))].sort(),
    [lectures],
  );

  const rows = useMemo(
    () =>
      attendance.filter((row) => {
        const date = row.lectures?.lecture_date ?? "";
        if (from && date < from) return false;
        if (to && date > to) return false;
        if (subject !== "all" && row.lectures?.subject !== subject) return false;
        return true;
      }),
    [attendance, from, to, subject],
  );

  const relevantLectures = lectures.filter((l) => {
    if (from && l.lecture_date < from) return false;
    if (to && l.lecture_date > to) return false;
    if (subject !== "all" && l.subject !== subject) return false;
    return true;
  });

  const expected = isTeacher
    ? relevantLectures.length * Math.max(students.length, 1)
    : relevantLectures.length;
  const present = rows.filter((r) => r.status !== "absent").length;
  const rate = expected > 0 ? Math.round((present / expected) * 100) : 0;

  const exportRows = rows.map((row) => ({
    date: row.lectures?.lecture_date ?? "",
    subject: row.lectures?.subject ?? "",
    student: row.profiles?.full_name ?? profile?.full_name ?? "",
    student_id: row.profiles?.student_id ?? profile?.student_id ?? "",
    status: row.status,
    method: row.method,
    confidence: row.confidence ? `${Math.round(row.confidence * 100)}%` : "",
    marked_at: new Date(row.marked_at).toLocaleString(),
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Reports</h1>
        <p className="text-sm text-muted-foreground">
          {isTeacher
            ? "Filter attendance across your lectures and export it."
            : "Filter and export your own attendance record."}
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Records" value={rows.length} icon={FileText} />
        <StatCard label="Sessions" value={relevantLectures.length} icon={FileText} />
        <StatCard label="Attendance rate" value={`${rate}%`} icon={FileText} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Filters</CardTitle>
          <CardDescription>Narrow the report before exporting.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-4">
          <div className="space-y-1.5">
            <Label htmlFor="from">From</Label>
            <Input id="from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="to">To</Label>
            <Input id="to" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Subject</Label>
            <Select value={subject} onValueChange={setSubject}>
              <SelectTrigger>
                <SelectValue placeholder="All subjects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All subjects</SelectItem>
                {subjects.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-end gap-2">
            <Button
              variant="outline"
              disabled={rows.length === 0}
              onClick={() => downloadCsv("attendance-report", exportRows)}
            >
              <Download className="size-4" /> CSV
            </Button>
            <Button
              disabled={rows.length === 0}
              onClick={() => {
                const html = tableHtml(
                  "Attendance report",
                  `${from || "start"} → ${to || "today"} · ${subject === "all" ? "All subjects" : subject} · ${rate}% attendance`,
                  ["Date", "Subject", "Student", "ID", "Status", "Method"],
                  exportRows.map((r) => [r.date, r.subject, r.student, r.student_id, r.status, r.method]),
                );
                printReport("Attendance report", html);
              }}
            >
              <Printer className="size-4" /> PDF
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Preview</CardTitle>
          <CardDescription>{rows.length} records match the filters.</CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          {rows.length === 0 ? (
            <EmptyState icon={FileText} title="Nothing to report" description="Adjust the filters or record some attendance first." />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Subject</TableHead>
                  {isTeacher ? <TableHead>Student</TableHead> : null}
                  <TableHead>Method</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 100).map((row) => (
                  <TableRow key={row.id}>
                    <TableCell>{row.lectures ? formatDate(row.lectures.lecture_date) : "—"}</TableCell>
                    <TableCell>{row.lectures?.subject ?? "—"}</TableCell>
                    {isTeacher ? <TableCell>{row.profiles?.full_name ?? "—"}</TableCell> : null}
                    <TableCell className="capitalize">{row.method}</TableCell>
                    <TableCell>
                      <Badge className="capitalize">{row.status}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
