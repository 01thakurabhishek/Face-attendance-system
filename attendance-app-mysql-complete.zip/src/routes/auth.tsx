import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { GraduationCap, Loader2, ScanFace, Upload, UserCog } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PasswordInput } from "@/components/PasswordInput";
import { ThemeToggle } from "@/components/ThemeToggle";

import { localDb } from "@/integrations/local/client";
import { useAuth } from "@/lib/auth";
import { resolveLoginEmail } from "@/lib/login.functions";
import { descriptorFromImageFile } from "@/lib/face";
import { uploadProfilePhoto, validateImage } from "@/lib/photos";
import {
  COURSES,
  DEPARTMENTS,
  DESIGNATIONS,
  SECTIONS,
  SEMESTERS,
  type AppRole,
} from "@/lib/types";
import { cn } from "@/lib/utils";
import { Building2, KeyRound } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import {
  lookupInstitute,
  registerInstitute,
  type InstituteSummary,
} from "@/lib/institute.functions";
import { clearStoredInstitute, loadStoredInstitute, storeInstitute } from "@/lib/institute";

const searchSchema = z.object({
  mode: z.enum(["login", "register"]).catch("login"),
});

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Login or Register — AI Attendance System" },
      {
        name: "description",
        content:
          "Sign in as a teacher or student, or create a new account with your college details and profile photo.",
      },
      { property: "og:title", content: "Login or Register — AI Attendance System" },
      {
        property: "og:description",
        content: "Access your teacher or student attendance workspace.",
      },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { mode } = Route.useSearch();
  const navigate = useNavigate();
  const { session, profile, loading, refreshProfile } = useAuth();
  const [institute, setInstitute] = useState<InstituteSummary | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setInstitute(loadStoredInstitute());
    setReady(true);
  }, []);

  useEffect(() => {
    if (!loading && session && profile) {
      void navigate({ to: profile.role === "teacher" ? "/app/teacher" : "/app/student" });
    }
  }, [loading, session, profile, navigate]);

  const chooseInstitute = (next: InstituteSummary) => {
    storeInstitute(next);
    setInstitute(next);
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="gradient-hero relative hidden flex-col justify-between p-12 text-white lg:flex">
        <Link to="/" className="flex items-center gap-2">
          <span className="grid size-9 place-items-center rounded-xl bg-white/15">
            <ScanFace className="size-5" />
          </span>
          <span className="font-display text-base font-semibold">AI Attendance System</span>
        </Link>
        <div>
          <h2 className="font-display text-4xl font-semibold leading-tight">
            One platform, every institute — each with its own private workspace.
          </h2>
          <p className="mt-4 max-w-md text-white/80">
            Your institute gets a unique 6-digit code. Teachers and students join with that code,
            and all attendance data stays inside your college.
          </p>
        </div>
        <p className="text-sm text-white/60">Secure · Role based · Multi-institute</p>
      </div>

      <div className="flex flex-col">
        <div className="flex items-center justify-between p-4">
          <Link to="/" className="text-sm text-muted-foreground hover:text-foreground lg:invisible">
            ← Back home
          </Link>
          <ThemeToggle />
        </div>
        <div className="flex flex-1 items-center justify-center px-4 pb-12">
          <div className="w-full max-w-lg">
            {!ready ? (
              <div className="flex justify-center py-16">
                <Loader2 className="size-6 animate-spin text-muted-foreground" />
              </div>
            ) : !institute ? (
              <InstitutePanel onSelect={chooseInstitute} />
            ) : (
              <>
                <div className="mb-4 flex items-center gap-3 rounded-xl border bg-secondary/40 p-3">
                  <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
                    <Building2 className="size-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{institute.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Institute code · {institute.code}
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      clearStoredInstitute();
                      setInstitute(null);
                    }}
                  >
                    Change
                  </Button>
                </div>
                <div className="mb-6 flex rounded-xl border p-1">
                  {(["login", "register"] as const).map((tab) => (
                    <Link
                      key={tab}
                      to="/auth"
                      search={{ mode: tab }}
                      className={cn(
                        "flex-1 rounded-lg px-4 py-2 text-center text-sm font-medium transition-colors",
                        mode === tab
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground",
                      )}
                    >
                      {tab === "login" ? "Login" : "Register"}
                    </Link>
                  ))}
                </div>
                {mode === "register" ? (
                  <RegisterForm onDone={refreshProfile} institute={institute} />
                ) : (
                  <LoginForm onDone={refreshProfile} institute={institute} />
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function InstitutePanel({ onSelect }: { onSelect: (institute: InstituteSummary) => void }) {
  const [tab, setTab] = useState<"join" | "create">("join");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState<InstituteSummary | null>(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "" });

  const join = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      const institute = await lookupInstitute({ data: { code: code.trim() } });
      if (!institute) {
        toast.error("No institute found with that code.");
        return;
      }
      toast.success(`Welcome to ${institute.name}`);
      onSelect(institute);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not verify the code");
    } finally {
      setBusy(false);
    }
  };

  const create = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      const institute = await registerInstitute({ data: form });
      setCreated(institute);
      toast.success("Institute registered.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not register the institute");
    } finally {
      setBusy(false);
    }
  };

  if (created) {
    return (
      <div className="surface-panel animate-fade-up space-y-5 rounded-2xl border p-6 text-center">
        <span className="mx-auto grid size-12 place-items-center rounded-2xl bg-primary/10 text-primary">
          <KeyRound className="size-6" />
        </span>
        <div>
          <h1 className="font-display text-2xl font-semibold">{created.name} is ready</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Share this code with your teachers and students — they need it to register.
          </p>
        </div>
        <p className="font-display text-4xl font-semibold tracking-[0.4em]">{created.code}</p>
        <Button className="w-full" onClick={() => onSelect(created)}>
          Continue to teacher &amp; student panel
        </Button>
      </div>
    );
  }

  return (
    <div className="surface-panel animate-fade-up space-y-5 rounded-2xl border p-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Enter your institute</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Every institute has its own private panel, unlocked by a unique 6-digit code.
        </p>
      </div>

      <div className="flex rounded-xl border p-1">
        {(
          [
            { value: "join" as const, label: "I have a code" },
            { value: "create" as const, label: "Register institute" },
          ]
        ).map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => setTab(option.value)}
            className={cn(
              "flex-1 rounded-lg px-4 py-2 text-center text-sm font-medium transition-colors",
              tab === option.value
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            {option.label}
          </button>
        ))}
      </div>

      {tab === "join" ? (
        <form onSubmit={join} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="code">Institute code</Label>
            <Input
              id="code"
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              inputMode="numeric"
              placeholder="123456"
              className="text-center text-lg tracking-[0.4em]"
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={busy || code.length !== 6}>
            {busy ? <Loader2 className="size-4 animate-spin" /> : null}
            Open institute panel
          </Button>
        </form>
      ) : (
        <form onSubmit={create} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="instituteName">Institute name</Label>
            <Input
              id="instituteName"
              value={form.name}
              onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
              required
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="instituteEmail">Official email</Label>
              <Input
                id="instituteEmail"
                type="email"
                value={form.email}
                onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="institutePhone">Phone</Label>
              <Input
                id="institutePhone"
                value={form.phone}
                onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="instituteAddress">Address</Label>
            <Textarea
              id="instituteAddress"
              value={form.address}
              onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))}
              rows={2}
            />
          </div>
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? <Loader2 className="size-4 animate-spin" /> : null}
            Generate 6-digit code
          </Button>
        </form>
      )}
    </div>
  );
}

function RoleToggle({ role, setRole }: { role: AppRole; setRole: (role: AppRole) => void }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      {(
        [
          { value: "student" as AppRole, label: "Student", icon: GraduationCap },
          { value: "teacher" as AppRole, label: "Teacher", icon: UserCog },
        ]
      ).map((option) => (
        <button
          key={option.value}
          type="button"
          onClick={() => setRole(option.value)}
          className={cn(
            "flex items-center gap-3 rounded-xl border p-3 text-left transition-all",
            role === option.value
              ? "border-primary bg-primary/5 ring-2 ring-primary/30"
              : "hover:bg-secondary",
          )}
        >
          <option.icon className="size-5 text-primary" />
          <span className="text-sm font-medium">{option.label}</span>
        </button>
      ))}
    </div>
  );
}

function LoginForm({
  onDone,
  institute,
}: {
  onDone: () => Promise<void>;
  institute: InstituteSummary;
}) {
  const [role, setRole] = useState<AppRole>("student");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      const { email } = await resolveLoginEmail({
        data: { identifier, role, instituteId: institute.id },
      });
      if (!email) {
        toast.error("No account found with that ID for this role.");
        return;
      }
      const { error } = await localDb.auth.signInWithPassword({ email, password });
      if (error) {
        toast.error(error.message);
        return;
      }
      await onDone();
      toast.success("Welcome back!");
      void navigate({ to: role === "teacher" ? "/app/teacher" : "/app/student" });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Login failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="surface-panel animate-fade-up space-y-5 rounded-2xl border p-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Welcome back</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Sign in with your ID or email address.
        </p>
      </div>
      <RoleToggle role={role} setRole={setRole} />
      <div className="space-y-2">
        <Label htmlFor="identifier">
          {role === "student" ? "Student ID or email" : "Teacher ID or email"}
        </Label>
        <Input
          id="identifier"
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          placeholder={role === "student" ? "e.g. 21CS045" : "e.g. TCH1042"}
          required
          autoComplete="username"
        />
      </div>
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="password">Password</Label>
          <Link to="/forgot-password" className="text-xs text-primary hover:underline">
            Forgot password?
          </Link>
        </div>
        <PasswordInput
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          autoComplete="current-password"
        />

      </div>

      <Button type="submit" className="w-full" disabled={busy}>
        {busy ? <Loader2 className="size-4 animate-spin" /> : null}
        Login
      </Button>
    </form>
  );
}

function RegisterForm({
  onDone,
  institute,
}: {
  onDone: () => Promise<void>;
  institute: InstituteSummary;
}) {
  const [role, setRole] = useState<AppRole>("student");
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState("");
  const [photo, setPhoto] = useState<File | null>(null);
  const navigate = useNavigate();

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    password: "",
    confirm: "",
    phone: "",
    dateOfBirth: "",

    idNumber: "",
    department: DEPARTMENTS[0] as string,
    course: COURSES[0] as string,
    semester: "1",
    section: "A",
    designation: DESIGNATIONS[0] as string,
    subjects: "",
  });

  const set = (key: keyof typeof form, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const photoPreview = useMemo(() => (photo ? URL.createObjectURL(photo) : null), [photo]);
  useEffect(() => () => {
    if (photoPreview) URL.revokeObjectURL(photoPreview);
  }, [photoPreview]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (form.password !== form.confirm) {
      toast.error("Passwords do not match.");
      return;
    }
    if (form.password.length < 8) {
      toast.error("Password must be at least 8 characters.");
      return;
    }
    if (!photo) {
      toast.error("A clear face photo is required for recognition.");
      return;
    }
    const invalid = validateImage(photo);
    if (invalid) {
      toast.error(invalid);
      return;
    }

    setBusy(true);
    try {
      setStep("Analysing your face photo…");
      const descriptor = await descriptorFromImageFile(photo);
      if (!descriptor) {
        toast.error("No face detected. Use a well-lit, front-facing photo.");
        return;
      }

      setStep("Creating your account…");
      const { data: signUpData, error: signUpError } = await localDb.auth.signUp({
        email: form.email.trim(),
        password: form.password,
        options: { emailRedirectTo: `${window.location.origin}/auth` },
      });
      if (signUpError) {
        toast.error(signUpError.message);
        return;
      }
      const userId = signUpData.user?.id;
      if (!userId) {
        toast.error("Account created but no session returned. Try logging in.");
        return;
      }

      setStep("Uploading your photo…");
      const photoPath = await uploadProfilePhoto(userId, photo);

      setStep("Saving your profile…");
      const payload = {
        user_id: userId,
        institute_id: institute.id,
        role,
        full_name: form.fullName.trim(),
        email: form.email.trim(),
        phone: form.phone.trim() || null,
        date_of_birth: form.dateOfBirth || null,

        department: form.department,
        photo_url: photoPath,
        student_id: role === "student" ? form.idNumber.trim() : null,
        course: role === "student" ? form.course : null,
        semester: role === "student" ? form.semester : null,
        section: role === "student" ? form.section : null,
        teacher_id: role === "teacher" ? form.idNumber.trim() : null,
        designation: role === "teacher" ? form.designation : null,
        subjects:
          role === "teacher"
            ? form.subjects
                .split(",")
                .map((s) => s.trim())
                .filter(Boolean)
            : null,
      };

      const { data: createdProfile, error: profileError } = await localDb
        .from("profiles")
        .insert(payload)
        .select("id")
        .maybeSingle();
      if (profileError) {
        toast.error(profileError.message);
        return;
      }

      if (createdProfile?.id) {
        const { error: faceError } = await localDb.from("face_enrollments").upsert(
          { profile_id: createdProfile.id, descriptor: Array.from(descriptor) },
          { onConflict: "profile_id" },
        );
        if (faceError) {
          toast.error(faceError.message);
          return;
        }
      }

      await onDone();
      toast.success("Account created. Welcome aboard!");
      void navigate({ to: role === "teacher" ? "/app/teacher" : "/app/student" });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Registration failed");
    } finally {
      setBusy(false);
      setStep("");
    }
  };

  return (
    <form onSubmit={submit} className="surface-panel animate-fade-up space-y-5 rounded-2xl border p-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Create your account</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Your photo is used to recognise you in class — make sure your face is clearly visible.
        </p>
      </div>

      <RoleToggle role={role} setRole={setRole} />

      <div className="flex items-center gap-4">
        <div className="grid size-20 shrink-0 place-items-center overflow-hidden rounded-2xl border bg-secondary">
          {photoPreview ? (
            <img src={photoPreview} alt="Selected profile" className="size-full object-cover" />
          ) : (
            <Upload className="size-6 text-muted-foreground" />
          )}
        </div>
        <div className="flex-1 space-y-2">
          <Label htmlFor="photo">Face photo</Label>
          <Input
            id="photo"
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={(e) => setPhoto(e.target.files?.[0] ?? null)}
            required
          />
          <p className="text-xs text-muted-foreground">JPG, PNG or WEBP up to 5 MB.</p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Full name" id="fullName">
          <Input
            id="fullName"
            value={form.fullName}
            onChange={(e) => set("fullName", e.target.value)}
            required
          />
        </Field>
        <Field label={role === "student" ? "Student ID" : "Teacher ID"} id="idNumber">
          <Input
            id="idNumber"
            value={form.idNumber}
            onChange={(e) => set("idNumber", e.target.value)}
            required
          />
        </Field>
        <Field label="Email" id="email">
          <Input
            id="email"
            type="email"
            value={form.email}
            onChange={(e) => set("email", e.target.value)}
            required
            autoComplete="email"
          />
        </Field>
        <Field label="Phone" id="phone">
          <Input
            id="phone"
            value={form.phone}
            onChange={(e) => set("phone", e.target.value)}
            placeholder="Optional"
          />
        </Field>
        <Field label="Date of birth" id="dateOfBirth">
          <Input
            id="dateOfBirth"
            type="date"
            value={form.dateOfBirth}
            onChange={(e) => set("dateOfBirth", e.target.value)}
          />
        </Field>

        <Field label="Department" id="department">
          <Picker
            value={form.department}
            onChange={(v) => set("department", v)}
            options={DEPARTMENTS}
          />
        </Field>

        {role === "student" ? (
          <>
            <Field label="Course" id="course">
              <Picker value={form.course} onChange={(v) => set("course", v)} options={COURSES} />
            </Field>
            <Field label="Semester" id="semester">
              <Picker
                value={form.semester}
                onChange={(v) => set("semester", v)}
                options={SEMESTERS}
              />
            </Field>
            <Field label="Section" id="section">
              <Picker value={form.section} onChange={(v) => set("section", v)} options={SECTIONS} />
            </Field>
          </>
        ) : (
          <>
            <Field label="Designation" id="designation">
              <Picker
                value={form.designation}
                onChange={(v) => set("designation", v)}
                options={DESIGNATIONS}
              />
            </Field>
            <Field label="Subjects (comma separated)" id="subjects" full>
              <Input
                id="subjects"
                value={form.subjects}
                onChange={(e) => set("subjects", e.target.value)}
                placeholder="Data Structures, Operating Systems"
              />
            </Field>
          </>
        )}

        <Field label="Password" id="password">
          <PasswordInput
            id="password"
            value={form.password}
            onChange={(e) => set("password", e.target.value)}
            required
            autoComplete="new-password"
          />
        </Field>
        <Field label="Confirm password" id="confirm">
          <PasswordInput
            id="confirm"
            value={form.confirm}
            onChange={(e) => set("confirm", e.target.value)}
            required
            autoComplete="new-password"
          />
        </Field>
      </div>


      <Button type="submit" className="w-full" disabled={busy}>
        {busy ? <Loader2 className="size-4 animate-spin" /> : null}
        {busy ? step || "Working…" : "Create account"}
      </Button>
    </form>
  );
}

function Field({
  label,
  id,
  full,
  children,
}: {
  label: string;
  id: string;
  full?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className={cn("space-y-2", full && "sm:col-span-2")}>
      <Label htmlFor={id}>{label}</Label>
      {children}
    </div>
  );
}

function Picker({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (value: string) => void;
  options: string[];
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {options.map((option) => (
          <SelectItem key={option} value={option}>
            {option}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
