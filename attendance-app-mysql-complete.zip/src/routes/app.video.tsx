import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { FileVideo, Loader2, Upload, Video } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { EmptyState } from "@/components/EmptyState";
import { PersonAvatar } from "@/components/PersonAvatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { logTracking, markAttendance } from "@/lib/attendance";
import { useAuth } from "@/lib/auth";
import { detectFaces, isUsableFace, loadModels, matchFace, type KnownFace } from "@/lib/face";
import {
  attendanceQuery,
  faceEnrollmentsQuery,
  formatDate,
  formatTime,
  knownFacesFrom,
  lecturesQuery,
  profilesQuery,
} from "@/lib/queries";
import type { Profile } from "@/lib/types";

export const Route = createFileRoute("/app/video")({
  head: () => ({
    meta: [
      { title: "Video Attendance — AI Attendance System" },
      { name: "description", content: "Upload a classroom recording and mark attendance from the footage." },
      { property: "og:title", content: "Video Attendance — AI Attendance System" },
      { property: "og:description", content: "Attendance from recorded classroom video." },
    ],
  }),
  component: VideoPage,
});

function VideoPage() {
  const { profile } = useAuth();
  return profile?.role === "teacher" ? <TeacherVideo /> : <StudentVideo />;
}

function TeacherVideo() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const { data: lectures = [] } = useQuery(lecturesQuery());
  const { data: students = [] } = useQuery(profilesQuery("student"));
  const [lectureId, setLectureId] = useState("");
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [processing, setProcessing] = useState(false);
  const [found, setFound] = useState<{ profile: Profile; confidence: number }[]>([]);

  const { data: enrollments = [] } = useQuery(faceEnrollmentsQuery());
  const known: KnownFace<Profile>[] = knownFacesFrom(students, enrollments);

  const process = async () => {
    const video = videoRef.current;
    if (!video || !fileUrl) {
      toast.error("Choose a video file first");
      return;
    }
    if (!lectureId) {
      toast.error("Select a lecture first");
      return;
    }
    setProcessing(true);
    setProgress(0);
    setFound([]);
    const matches = new Map<string, { profile: Profile; confidence: number }>();
    try {
      await loadModels();
      const duration = Number.isFinite(video.duration) ? video.duration : 0;
      if (duration === 0) throw new Error("Could not read the video length.");
      const step = Math.max(1, duration / 20);
      for (let t = 0; t < duration; t += step) {
        await new Promise<void>((resolve) => {
          const onSeek = () => {
            video.removeEventListener("seeked", onSeek);
            resolve();
          };
          video.addEventListener("seeked", onSeek);
          video.currentTime = t;
        });
        const canvas = document.createElement("canvas");
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext("2d")?.drawImage(video, 0, 0);
        const faces = await detectFaces(canvas);
        for (const face of faces) {
          if (!isUsableFace(face)) continue;
          const match = matchFace(face.descriptor, known);

          if (!match) continue;
          const prev = matches.get(match.person.id);
          if (!prev || match.confidence > prev.confidence) {
            matches.set(match.person.id, { profile: match.person, confidence: match.confidence });
          }
        }
        setProgress(Math.min(100, Math.round(((t + step) / duration) * 100)));
      }

      let created = 0;
      for (const entry of matches.values()) {
        const result = await markAttendance({
          lectureId,
          studentProfileId: entry.profile.id,
          confidence: entry.confidence,
          method: "video",
          markedBy: profile?.id ?? null,
        });
        await logTracking({
          profileId: entry.profile.id,
          source: "video-upload",
          confidence: entry.confidence,
          observedBy: profile?.id ?? null,
        });
        if (result === "created") created += 1;
      }
      setFound([...matches.values()]);
      setProgress(100);
      await queryClient.invalidateQueries({ queryKey: ["attendance"] });
      await queryClient.invalidateQueries({ queryKey: ["tracking"] });
      toast.success(`${matches.size} students recognised · ${created} newly marked`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Video processing failed");
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Video attendance</h1>
        <p className="text-sm text-muted-foreground">
          Upload a classroom recording — every recognised student is marked present for the chosen lecture.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recording</CardTitle>
            <CardDescription>Frames are sampled across the clip and matched against enrolled faces.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Select value={lectureId} onValueChange={setLectureId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a lecture" />
              </SelectTrigger>
              <SelectContent>
                {lectures.map((lecture) => (
                  <SelectItem key={lecture.id} value={lecture.id}>
                    {lecture.subject} · {formatDate(lecture.lecture_date)} · {formatTime(lecture.start_time)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <input
              type="file"
              accept="video/*"
              className="block w-full text-sm file:mr-3 file:rounded-lg file:border file:bg-secondary file:px-3 file:py-2 file:text-sm"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                setFileUrl(URL.createObjectURL(file));
                setFound([]);
                setProgress(0);
              }}
            />

            {fileUrl ? (
              <video ref={videoRef} src={fileUrl} muted playsInline className="w-full rounded-xl bg-black" />
            ) : (
              <div className="grid aspect-video place-items-center rounded-xl border border-dashed text-sm text-muted-foreground">
                <span className="flex items-center gap-2">
                  <FileVideo className="size-4" /> No video selected
                </span>
              </div>
            )}

            {processing || progress > 0 ? <Progress value={progress} /> : null}

            <Button onClick={() => void process()} disabled={processing}>
              {processing ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
              Process recording
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recognised students</CardTitle>
            <CardDescription>Best match confidence per student across the clip.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {found.length === 0 ? (
              <p className="text-sm text-muted-foreground">No results yet.</p>
            ) : (
              found.map((entry) => (
                <div key={entry.profile.id} className="flex items-center gap-3 rounded-xl border p-3">
                  <PersonAvatar name={entry.profile.full_name} photoPath={entry.profile.photo_url} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{entry.profile.full_name}</p>
                    <p className="text-xs text-muted-foreground">{entry.profile.student_id ?? "—"}</p>
                  </div>
                  <Badge>{Math.round(entry.confidence * 100)}%</Badge>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StudentVideo() {
  const { profile } = useAuth();
  const { data: attendance = [] } = useQuery({
    ...attendanceQuery({ studentProfileId: profile?.id ?? "" }),
    enabled: Boolean(profile?.id),
  });
  const fromVideo = attendance.filter((row) => row.method === "video");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Video attendance</h1>
        <p className="text-sm text-muted-foreground">
          Classes where you were marked present from a recorded session.
        </p>
      </div>
      {fromVideo.length === 0 ? (
        <EmptyState
          icon={Video}
          title="Nothing from recordings yet"
          description="Only teachers can upload recordings. Anything matched to you shows up here."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {fromVideo.map((row) => (
            <Card key={row.id}>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">{row.lectures?.subject ?? "Lecture"}</CardTitle>
                <CardDescription>
                  {row.lectures ? formatDate(row.lectures.lecture_date) : "—"} ·{" "}
                  {row.confidence ? `${Math.round(row.confidence * 100)}% match` : "manual"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Badge className="capitalize">{row.status}</Badge>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
