import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { FileText, Loader2, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/EmptyState";
import { RoleGate } from "@/components/RoleGate";
import { useAuth } from "@/lib/auth";
import { matchesClass } from "@/lib/classScope";
import { localDb } from "@/integrations/local/client";
import { formatDate } from "@/lib/queries";
import {
  answerMap,
  canHavePaper,
  examMarksQuery,
  examQuestionsQuery,
  examSubmissionsQuery,
  examTypeLabel,
  examsQuery,
  type Exam,
} from "@/lib/exams";

export const Route = createFileRoute("/app/my-exams")({
  head: () => ({
    meta: [
      { title: "My Exams — AI Attendance System" },
      {
        name: "description",
        content: "Open shared question papers, write your answers and check the marks you scored.",
      },
      { property: "og:title", content: "My Exams — AI Attendance System" },
      { property: "og:description", content: "Your question papers, answers and scores." },
    ],
  }),
  component: () => (
    <RoleGate allow={["student"]}>
      <MyExamsPage />
    </RoleGate>
  ),
});

function MyExamsPage() {
  const { profile } = useAuth();
  const { data: exams = [] } = useQuery(examsQuery());
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const shared = exams.filter(
    (exam) =>
      exam.status === "published" &&
      matchesClass(profile, exam),
  );

  const selected = shared.find((exam) => exam.id === selectedId) ?? null;

  return (
    <div className="space-y-8">
      <header>
        <h1 className="font-display text-3xl font-semibold tracking-tight">My exams</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Question papers shared by your teachers, your answers and your scores.
        </p>
      </header>

      <section className="surface-panel rounded-2xl border p-6">
        <h2 className="text-base font-semibold">Shared exams</h2>
        <div className="mt-4 grid gap-3 lg:grid-cols-2">
          {shared.length === 0 ? (
            <EmptyState
              icon={FileText}
              title="No exams shared yet"
              description="When your teacher shares a question paper it will appear here."
            />
          ) : (
            shared.map((exam) => (
              <button
                key={exam.id}
                type="button"
                onClick={() => setSelectedId(exam.id === selectedId ? null : exam.id)}
                className={`rounded-xl border p-4 text-left transition-colors ${
                  exam.id === selectedId ? "border-primary bg-primary/5" : "hover:bg-secondary/50"
                }`}
              >
                <p className="truncate font-medium">{exam.title}</p>
                <p className="text-xs text-muted-foreground">
                  {examTypeLabel(exam.exam_type)} · {exam.subject}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {formatDate(exam.exam_date)} · {exam.total_marks} marks
                  {exam.duration_minutes ? ` · ${exam.duration_minutes} min` : ""}
                </p>
              </button>
            ))
          )}
        </div>
      </section>

      {selected && profile ? (
        <ExamPaper exam={selected} studentProfileId={profile.id} />
      ) : null}
    </div>
  );
}

function ExamPaper({ exam, studentProfileId }: { exam: Exam; studentProfileId: string }) {
  const queryClient = useQueryClient();
  const { data: questions = [] } = useQuery(examQuestionsQuery(exam.id));
  const { data: submissions = [] } = useQuery(examSubmissionsQuery(exam.id));
  const { data: marks = [] } = useQuery(examMarksQuery(exam.id));
  const [answers, setAnswers] = useState<Record<string, string>>({});

  const mySubmission = submissions.find((row) => row.student_profile_id === studentProfileId);
  const myMark = marks.find((row) => row.student_profile_id === studentProfileId);
  const submitted = Boolean(mySubmission?.submitted_at);

  useEffect(() => {
    setAnswers(answerMap(mySubmission));
  }, [mySubmission]);

  const submit = useMutation({
    mutationFn: async (finalise: boolean) => {
      const { error } = await localDb.from("exam_submissions").upsert(
        {
          exam_id: exam.id,
          student_profile_id: studentProfileId,
          answers,
          submitted_at: finalise ? new Date().toISOString() : null,
        },
        { onConflict: "exam_id,student_profile_id" },
      );
      if (error) throw new Error(error.message);
    },
    onSuccess: (_data, finalise) => {
      toast.success(finalise ? "Answers submitted" : "Draft saved");
      void queryClient.invalidateQueries({ queryKey: ["exam-submissions", exam.id] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <section className="surface-panel space-y-4 rounded-2xl border p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold">{exam.title}</h2>
          <p className="text-xs text-muted-foreground">
            {examTypeLabel(exam.exam_type)} · {exam.subject} · {formatDate(exam.exam_date)}
          </p>
        </div>
        {myMark?.marks_obtained != null ? (
          <span className="rounded-full bg-success/15 px-3 py-1.5 text-sm font-medium text-success">
            Score: {myMark.marks_obtained} / {exam.total_marks}
          </span>
        ) : (
          <span className="rounded-full bg-secondary px-3 py-1.5 text-xs text-muted-foreground">
            {submitted ? "Awaiting result" : "Not submitted"}
          </span>
        )}
      </div>

      {myMark?.remarks ? (
        <p className="rounded-xl border p-3 text-sm">
          <span className="font-medium">Teacher's remark: </span>
          {myMark.remarks}
        </p>
      ) : null}

      {exam.instructions ? (
        <p className="rounded-xl border p-3 text-sm text-muted-foreground">{exam.instructions}</p>
      ) : null}

      {!canHavePaper(exam.exam_type) ? (
        <p className="text-sm text-muted-foreground">
          This exam has no online question paper. Your score appears here once your teacher records
          it.
        </p>
      ) : questions.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          Your teacher has not added questions to this paper yet.
        </p>
      ) : (
        <>
          <div className="space-y-4">
            {questions.map((question) => (
              <div key={question.id} className="rounded-xl border p-4">
                <div className="flex items-start justify-between gap-3">
                  <p className="text-sm font-medium">
                    Q{question.question_no}. {question.question_text}
                  </p>
                  <span className="shrink-0 text-xs text-muted-foreground">
                    {question.marks} marks
                  </span>
                </div>
                <Textarea
                  className="mt-3"
                  rows={4}
                  placeholder="Write your answer"
                  disabled={submitted}
                  value={answers[question.id] ?? ""}
                  onChange={(e) => setAnswers({ ...answers, [question.id]: e.target.value })}
                />
              </div>
            ))}
          </div>

          {submitted ? (
            <p className="text-sm text-muted-foreground">
              You submitted this paper on{" "}
              {new Date(mySubmission?.submitted_at ?? "").toLocaleString()}.
            </p>
          ) : (
            <div className="flex gap-2">
              <Button onClick={() => submit.mutate(true)} disabled={submit.isPending}>
                {submit.isPending ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Send className="size-4" />
                )}
                Submit answers
              </Button>
              <Button variant="outline" onClick={() => submit.mutate(false)}>
                Save draft
              </Button>
            </div>
          )}
        </>
      )}
    </section>
  );
}
