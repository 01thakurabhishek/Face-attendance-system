import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, FileText, Loader2, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/EmptyState";
import { useAuth } from "@/lib/auth";
import { localDb } from "@/integrations/local/client";
import { formatDate } from "@/lib/queries";
import { formatFileSize, noteFileUrl, notesQuery, type Note } from "@/lib/notes";
import { COURSES, DEPARTMENTS, SECTIONS, SEMESTERS } from "@/lib/types";

export const Route = createFileRoute("/app/notes")({
  head: () => ({
    meta: [
      { title: "Class Notes — AI Attendance System" },
      {
        name: "description",
        content: "Teachers share PDFs and study material; students download notes for their class.",
      },
      { property: "og:title", content: "Class Notes — AI Attendance System" },
      { property: "og:description", content: "Share and download class study material." },
    ],
  }),
  component: NotesPage,
});

const emptyDraft = {
  title: "",
  subject: "",
  description: "",
  course: "",
  department: "",
  semester: "",
  section: "",
};

function NotesPage() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const isTeacher = profile?.role === "teacher";
  const { data: notes = [], isLoading } = useQuery(notesQuery());

  const [draft, setDraft] = useState(emptyDraft);
  const [file, setFile] = useState<File | null>(null);

  const visible = isTeacher
    ? notes
    : notes.filter(
        (note) =>
          (!note.semester || note.semester === profile?.semester) &&
          (!note.section || note.section === profile?.section) &&
          (!note.course || note.course === profile?.course),
      );

  const upload = useMutation({
    mutationFn: async () => {
      if (!profile) throw new Error("Not signed in");
      if (!file) throw new Error("Choose a file first");
      if (!draft.title.trim() || !draft.subject.trim()) throw new Error("Title and subject are required");
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const path = `${profile.institute_id}/${crypto.randomUUID()}-${safeName}`;
      const { error: uploadError } = await localDb.storage.from("notes").upload(path, file, {
        contentType: file.type || "application/octet-stream",
        upsert: false,
      });
      if (uploadError) throw new Error(uploadError.message);
      const { error } = await localDb.from("notes").insert({
        teacher_profile_id: profile.id,
        institute_id: profile.institute_id,
        title: draft.title.trim(),
        subject: draft.subject.trim(),
        description: draft.description.trim() || null,
        course: draft.course || null,
        department: draft.department || null,
        semester: draft.semester || null,
        section: draft.section || null,
        file_path: path,
        file_name: file.name,
        file_size: file.size,
        mime_type: file.type || null,
      });
      if (error) {
        await localDb.storage.from("notes").remove([path]);
        throw new Error(error.message);
      }
    },
    onSuccess: () => {
      toast.success("Notes shared with students");
      setDraft(emptyDraft);
      setFile(null);
      void queryClient.invalidateQueries({ queryKey: ["notes"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const remove = useMutation({
    mutationFn: async (note: Note) => {
      const { error } = await localDb.from("notes").delete().eq("id", note.id);
      if (error) throw new Error(error.message);
      await localDb.storage.from("notes").remove([note.file_path]);
    },
    onSuccess: () => {
      toast.success("Note removed");
      void queryClient.invalidateQueries({ queryKey: ["notes"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  async function openFile(note: Note) {
    try {
      const url = await noteFileUrl(note.file_path);
      window.open(url, "_blank", "noopener");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not open the file");
    }
  }

  return (
    <div className="space-y-8">
      <header>
        <h1 className="font-display text-3xl font-semibold tracking-tight">Class notes</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {isTeacher
            ? "Share PDFs, slides and study material with your students."
            : "Study material shared by your teachers."}
        </p>
      </header>

      {isTeacher ? (
        <section className="surface-panel rounded-2xl border p-6">
          <h2 className="text-base font-semibold">Share new notes</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="note-title">Title</Label>
              <Input
                id="note-title"
                value={draft.title}
                onChange={(e) => setDraft({ ...draft, title: e.target.value })}
                placeholder="Unit 3 — Trees & Graphs"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="note-subject">Subject</Label>
              <Input
                id="note-subject"
                value={draft.subject}
                onChange={(e) => setDraft({ ...draft, subject: e.target.value })}
                placeholder="Data Structures"
              />
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label htmlFor="note-desc">Description (optional)</Label>
              <Textarea
                id="note-desc"
                value={draft.description}
                onChange={(e) => setDraft({ ...draft, description: e.target.value })}
                placeholder="What this file covers"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="note-course">Course</Label>
              <select
                id="note-course"
                className="h-10 w-full rounded-md border bg-background px-3 text-sm"
                value={draft.course}
                onChange={(e) => setDraft({ ...draft, course: e.target.value })}
              >
                <option value="">All courses</option>
                {COURSES.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="note-dept">Department</Label>
              <select
                id="note-dept"
                className="h-10 w-full rounded-md border bg-background px-3 text-sm"
                value={draft.department}
                onChange={(e) => setDraft({ ...draft, department: e.target.value })}
              >
                <option value="">All departments</option>
                {DEPARTMENTS.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="note-sem">Semester</Label>
              <select
                id="note-sem"
                className="h-10 w-full rounded-md border bg-background px-3 text-sm"
                value={draft.semester}
                onChange={(e) => setDraft({ ...draft, semester: e.target.value })}
              >
                <option value="">All semesters</option>
                {SEMESTERS.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="note-section">Section</Label>
              <select
                id="note-section"
                className="h-10 w-full rounded-md border bg-background px-3 text-sm"
                value={draft.section}
                onChange={(e) => setDraft({ ...draft, section: e.target.value })}
              >
                <option value="">All sections</option>
                {SECTIONS.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label htmlFor="note-file">File (PDF, Word, PowerPoint, images — up to 25 MB)</Label>
              <Input
                id="note-file"
                type="file"
                accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.png,.jpg,.jpeg,.zip"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              />
            </div>
          </div>
          <Button
            className="mt-4"
            disabled={upload.isPending}
            onClick={() => upload.mutate()}
          >
            {upload.isPending ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
            Share notes
          </Button>
        </section>
      ) : null}

      <section className="surface-panel rounded-2xl border p-6">
        <h2 className="text-base font-semibold">
          {isTeacher ? "Shared notes" : "Notes for your class"}
        </h2>
        <div className="mt-4 space-y-3">
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : visible.length === 0 ? (
            <EmptyState
              icon={FileText}
              title="No notes yet"
              description={
                isTeacher
                  ? "Upload a PDF or slides above to share them with your students."
                  : "Notes shared by your teachers will appear here."
              }
            />
          ) : (
            visible.map((note) => (
              <div
                key={note.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border p-4"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{note.title}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {note.subject}
                    {note.semester ? ` · Sem ${note.semester}` : ""}
                    {note.section ? ` · Section ${note.section}` : ""} · {formatDate(note.created_at.slice(0, 10))}
                    {note.file_size ? ` · ${formatFileSize(note.file_size)}` : ""}
                  </p>
                  {note.description ? (
                    <p className="mt-1 text-xs text-muted-foreground">{note.description}</p>
                  ) : null}
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => void openFile(note)}>
                    <Download className="size-4" /> Open
                  </Button>
                  {isTeacher ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive"
                      onClick={() => remove.mutate(note)}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  ) : null}
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
}
