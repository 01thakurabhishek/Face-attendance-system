import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  CalendarDays,
  ClipboardList,
  GraduationCap,
  Plus,
  Radar,
  ScanFace,
  Users,
} from "lucide-react";
import { AttendancePieChart } from "@/components/AttendancePieChart";
import { Button } from "@/components/ui/button";
import { StatCard } from "@/components/StatCard";
import { EmptyState } from "@/components/EmptyState";
import { PersonAvatar } from "@/components/PersonAvatar";
import { useAuth } from "@/lib/auth";
import {
  attendanceQuery,
  attendanceRate,
  formatDate,
  formatTime,
  lecturesQuery,
  profilesQuery,
} from "@/lib/queries";

export const Route = createFileRoute("/app/teacher")({
  head: () => ({
    meta: [
      { title: "Teacher Dashboard — AI Attendance System" },
      {
        name: "description",
        content:
          "Track today's lectures, class attendance rates and recent face-recognition check-ins.",
      },
      { property: "og:title", content: "Teacher Dashboard — AI Attendance System" },
      { property: "og:description", content: "Your teaching day at a glance." },
    ],
  }),
  component: TeacherDashboard,
});

function TeacherDashboard() {
  const { profile } = useAuth();
  const { data: students = [] } = useQuery(profilesQuery("student"));
  const { data: teachers = [] } = useQuery(profilesQuery("teacher"));
  const { data: lectures = [] } = useQuery(lecturesQuery(profile?.id));
  const { data: attendance = [] } = useQuery(attendanceQuery());

  const today = new Date().toISOString().slice(0, 10);
  const todays = lectures.filter((lecture) => lecture.lecture_date === today);
  const live = lectures.filter((lecture) => lecture.status === "live");
  const present = attendance.filter((row) => row.status === "present").length;
  const late = attendance.filter((row) => row.status === "late").length;
  const absent = attendance.filter((row) => row.status === "absent").length;

  return (
    <div className="space-y-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">
            Hello, {profile?.full_name?.split(" ")[0]}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {todays.length > 0
              ? `You have ${todays.length} lecture${todays.length > 1 ? "s" : ""} scheduled today.`
              : "No lectures scheduled for today."}
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline">
            <Link to="/app/lectures">
              <Plus className="size-4" /> New lecture
            </Link>
          </Button>
          <Button asChild>
            <Link to="/app/live">
              <ScanFace className="size-4" /> Start attendance
            </Link>
          </Button>
        </div>
      </header>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Students" value={students.length} icon={Users} delay={0} />
        <StatCard label="Teachers" value={teachers.length} icon={GraduationCap} tone="accent" delay={60} />
        <StatCard label="My lectures" value={lectures.length} icon={CalendarDays} tone="primary" delay={120} />
        <StatCard
          label="Attendance rate"
          value={`${attendanceRate(present, attendance.length)}%`}
          hint={`${present} of ${attendance.length} marks present`}
          icon={ClipboardList}
          tone="success"
          delay={180}
        />
      </section>

      <section>
        <AttendancePieChart
          title="Attendance breakdown"
          description={`${present} present · ${late} late · ${absent} absent across your institute`}
          counts={{ present, late, absent }}
        />
      </section>

      {live.length > 0 ? (
        <section className="surface-panel rounded-2xl border p-6">
          <div className="flex items-center gap-2">
            <span className="size-2 animate-pulse rounded-full bg-success" />
            <h2 className="text-base font-semibold">Live now</h2>
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {live.map((lecture) => (
              <div
                key={lecture.id}
                className="flex items-center justify-between rounded-xl border bg-background/60 p-4"
              >
                <div>
                  <p className="font-medium">{lecture.subject}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatTime(lecture.start_time)} – {formatTime(lecture.end_time)} ·{" "}
                    {lecture.room ?? "No room"}
                  </p>
                </div>
                <Button asChild size="sm">
                  <Link to="/app/live">Open</Link>
                </Button>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <section className="grid gap-6 lg:grid-cols-2">
        <div className="surface-panel rounded-2xl border p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold">Today's schedule</h2>
            <Link to="/app/lectures" className="text-sm text-primary hover:underline">
              All lectures
            </Link>
          </div>
          <div className="mt-4 space-y-3">
            {todays.length === 0 ? (
              <EmptyState
                icon={CalendarDays}
                title="Nothing scheduled"
                description="Create a lecture to start taking attendance for your class."
                action={
                  <Button asChild size="sm">
                    <Link to="/app/lectures">Schedule a lecture</Link>
                  </Button>
                }
              />
            ) : (
              todays.map((lecture) => (
                <div
                  key={lecture.id}
                  className="flex items-center justify-between rounded-xl border p-4"
                >
                  <div>
                    <p className="font-medium">{lecture.subject}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatTime(lecture.start_time)} · Sem {lecture.semester ?? "-"} ·{" "}
                      {lecture.section ? `Section ${lecture.section}` : "All sections"}
                    </p>
                  </div>
                  <span className="rounded-full bg-secondary px-2.5 py-1 text-xs capitalize">
                    {lecture.status}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="surface-panel rounded-2xl border p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold">Recent check-ins</h2>
            <Link to="/app/tracking" className="text-sm text-primary hover:underline">
              Live tracking
            </Link>
          </div>
          <div className="mt-4 space-y-3">
            {attendance.length === 0 ? (
              <EmptyState
                icon={Radar}
                title="No attendance yet"
                description="Once you run a face-recognition session, check-ins appear here in real time."
              />
            ) : (
              attendance.slice(0, 6).map((row) => (
                <div key={row.id} className="flex items-center gap-3 rounded-xl border p-3">
                  <PersonAvatar
                    name={row.profiles?.full_name ?? "Student"}
                    photoPath={row.profiles?.photo_url}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{row.profiles?.full_name}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {row.lectures?.subject} ·{" "}
                      {row.lectures ? formatDate(row.lectures.lecture_date) : ""}
                    </p>
                  </div>
                  <span
                    className={
                      row.status === "present"
                        ? "rounded-full bg-success/15 px-2.5 py-1 text-xs font-medium text-success"
                        : row.status === "late"
                          ? "rounded-full bg-warning/20 px-2.5 py-1 text-xs font-medium text-warning"
                          : "rounded-full bg-destructive/10 px-2.5 py-1 text-xs font-medium text-destructive"
                    }
                  >
                    {row.status}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
