import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CalendarDays, Search, Users } from "lucide-react";
import { toast } from "sonner";
import { EmptyState } from "@/components/EmptyState";
import { PersonAvatar } from "@/components/PersonAvatar";
import { RoleGate } from "@/components/RoleGate";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { localDb } from "@/integrations/local/client";
import { lecturesQuery, profilesQuery } from "@/lib/queries";
import { useAuth } from "@/lib/auth";
import { matchesClass } from "@/lib/classScope";
import { COURSES, DEPARTMENTS, SECTIONS, SEMESTERS, type Profile } from "@/lib/types";

export const Route = createFileRoute("/app/students")({
  head: () => ({
    meta: [
      { title: "Students Directory — AI Attendance System" },
      {
        name: "description",
        content:
          "Browse every enrolled student with photo, name, date of birth, course, branch and section.",
      },
      { property: "og:title", content: "Students Directory — AI Attendance System" },
      { property: "og:description", content: "Full student records grouped section-wise." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: StudentsPage,
});

const ALL = "all";

function StudentsPage() {
  return (
    <RoleGate allow={["teacher"]}>
      <StudentsDirectory />
    </RoleGate>
  );
}

function StudentsDirectory() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const { data: allStudents = [], isLoading } = useQuery(profilesQuery("student"));
  const { data: lectures = [] } = useQuery(lecturesQuery(profile?.id));
  const students = useMemo(() => allStudents.filter((student) => {
    if (!profile || student.institute_id !== profile.institute_id) return false;
    if (profile.department && student.department !== profile.department) return false;
    if (profile.course || profile.semester || profile.section) return matchesClass(student, profile);
    return lectures.some((lecture) => matchesClass(student, lecture));
  }), [allStudents, profile, lectures]);
  const [search, setSearch] = useState("");
  const [branch, setBranch] = useState(ALL);
  const [course, setCourse] = useState(ALL);
  const [semester, setSemester] = useState(ALL);
  const [section, setSection] = useState(ALL);

  const saveDob = useMutation({
    mutationFn: async ({ id, value }: { id: string; value: string }) => {
      const { error } = await localDb
        .from("profiles")
        .update({ date_of_birth: value || null })
        .eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("Date of birth updated");
      void queryClient.invalidateQueries({ queryKey: ["profiles"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  // Cascading options: each level only offers values that exist for the
  // levels selected above it, so a branch shows only its own courses etc.
  const branchOptions = useMemo(() => unique(students.map((s) => s.department)), [students]);

  const courseOptions = useMemo(
    () =>
      unique(
        students.filter((s) => branch === ALL || s.department === branch).map((s) => s.course),
      ),
    [students, branch],
  );

  const semesterOptions = useMemo(
    () =>
      unique(
        students
          .filter((s) => branch === ALL || s.department === branch)
          .filter((s) => course === ALL || s.course === course)
          .map((s) => s.semester),
      ).sort((a, b) => Number(a) - Number(b) || a.localeCompare(b)),
    [students, branch, course],
  );

  const sectionOptions = useMemo(
    () =>
      unique(
        students
          .filter((s) => branch === ALL || s.department === branch)
          .filter((s) => course === ALL || s.course === course)
          .filter((s) => semester === ALL || s.semester === semester)
          .map((s) => s.section),
      ),
    [students, branch, course, semester],
  );

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return students.filter((student) => {
      if (branch !== ALL && student.department !== branch) return false;
      if (course !== ALL && student.course !== course) return false;
      if (semester !== ALL && student.semester !== semester) return false;
      if (section !== ALL && student.section !== section) return false;
      if (!term) return true;
      return [student.full_name, student.student_id, student.email, student.roll_number]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(term));
    });
  }, [students, search, branch, course, semester, section]);

  // Branch → Course → Semester → Section
  const groups = useMemo(() => {
    const map = new Map<string, Profile[]>();
    for (const student of filtered) {
      const key = [
        student.department ?? "No branch",
        student.course ?? "No course",
        student.semester ? `Semester ${student.semester}` : "No semester",
        student.section ? `Section ${student.section}` : "No section",
      ].join(" | ");
      map.set(key, [...(map.get(key) ?? []), student]);
    }
    return [...map.entries()]
      .map(([key, rows]) => {
        const [dept, crs, sem, sec] = key.split(" | ");
        return {
          key,
          dept: dept ?? "No branch",
          course: crs ?? "No course",
          semester: sem ?? "No semester",
          section: sec ?? "No section",
          rows: rows.sort((a, b) =>
            (a.roll_number ?? a.full_name).localeCompare(b.roll_number ?? b.full_name, undefined, {
              numeric: true,
            }),
          ),
        };
      })
      .sort(
        (a, b) =>
          a.dept.localeCompare(b.dept) ||
          a.course.localeCompare(b.course) ||
          a.semester.localeCompare(b.semester, undefined, { numeric: true }) ||
          a.section.localeCompare(b.section),
      );
  }, [filtered]);

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Students</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {filtered.length} of {students.length} students · grouped by branch, course, semester
            and section
          </p>
        </div>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Filters</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-3 xl:grid-cols-5">
          <div className="space-y-2">
            <Label htmlFor="student-search">Search</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="student-search"
                className="pl-9"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Name, ID or email"
              />
            </div>
          </div>
          <FilterSelect
            label="Branch"
            value={branch}
            onChange={(value) => {
              setBranch(value);
              setCourse(ALL);
              setSemester(ALL);
              setSection(ALL);
            }}
            options={branchOptions.length ? branchOptions : DEPARTMENTS}
          />
          <FilterSelect
            label="Course"
            value={course}
            onChange={(value) => {
              setCourse(value);
              setSemester(ALL);
              setSection(ALL);
            }}
            options={courseOptions.length ? courseOptions : COURSES}
          />
          <FilterSelect
            label="Semester"
            value={semester}
            onChange={(value) => {
              setSemester(value);
              setSection(ALL);
            }}
            options={semesterOptions.length ? semesterOptions : SEMESTERS}
          />
          <FilterSelect
            label="Section"
            value={section}
            onChange={setSection}
            options={sectionOptions.length ? sectionOptions : SECTIONS}
          />
        </CardContent>
      </Card>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading students…</p>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No students found"
          description="Adjust the filters, or ask students to register with their college details."
        />
      ) : (
        groups.map((group) => (
          <section key={group.key} className="space-y-3">
            <div className="flex flex-wrap items-center gap-2 border-b pb-2">
              <h2 className="text-sm font-semibold uppercase tracking-wide">{group.dept}</h2>
              <span className="text-sm text-muted-foreground">
                {group.course} · {group.semester} · {group.section}
              </span>
              <span className="rounded-full bg-secondary px-2 py-0.5 text-xs">
                {group.rows.length}
              </span>
            </div>
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {group.rows.map((student) => (
                <StudentCard
                  key={student.id}
                  student={student}
                  onSaveDob={(value) => saveDob.mutate({ id: student.id, value })}
                  saving={saveDob.isPending}
                />
              ))}
            </div>
          </section>
        ))
      )}
    </div>
  );
}

function unique(values: (string | null)[]) {
  return [...new Set(values.filter((v): v is string => Boolean(v)))].sort((a, b) =>
    a.localeCompare(b),
  );
}

function FilterSelect({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
}) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger>
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL}>All</SelectItem>
          {options.map((option) => (
            <SelectItem key={option} value={option}>
              {option}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}


function StudentCard({
  student,
  onSaveDob,
  saving,
}: {
  student: Profile;
  onSaveDob: (value: string) => void;
  saving: boolean;
}) {
  const [dob, setDob] = useState(student.date_of_birth ?? "");
  const dirty = (student.date_of_birth ?? "") !== dob;

  return (
    <Card className="overflow-hidden">
      <CardContent className="space-y-4 p-5">
        <div className="flex items-center gap-3">
          <PersonAvatar
            name={student.full_name}
            photoPath={student.photo_url}
            className="size-14 text-base"
          />
          <div className="min-w-0">
            <p className="truncate font-medium">{student.full_name}</p>
            <p className="truncate text-xs text-muted-foreground">
              {student.student_id ?? "No ID"} · {student.email}
            </p>
          </div>
        </div>

        <dl className="grid grid-cols-2 gap-3 text-sm">
          <Detail label="Course" value={student.course} />
          <Detail label="Branch" value={student.department} />
          <Detail label="Semester" value={student.semester} />
          <Detail label="Section" value={student.section} />
          <Detail label="Roll number" value={student.roll_number} />
          <Detail label="Phone" value={student.phone} />
        </dl>

        <div className="space-y-2 rounded-xl border p-3">
          <Label
            htmlFor={`dob-${student.id}`}
            className="flex items-center gap-2 text-xs text-muted-foreground"
          >
            <CalendarDays className="size-3.5" /> Date of birth
          </Label>
          <div className="flex gap-2">
            <Input
              id={`dob-${student.id}`}
              type="date"
              value={dob}
              onChange={(e) => setDob(e.target.value)}
            />
            <Button
              size="sm"
              variant={dirty ? "default" : "outline"}
              disabled={!dirty || saving}
              onClick={() => onSaveDob(dob)}
            >
              Save
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function Detail({ label, value }: { label: string; value: string | null }) {
  return (
    <div>
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="truncate font-medium">{value || "—"}</dd>
    </div>
  );
}
