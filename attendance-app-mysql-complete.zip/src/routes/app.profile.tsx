import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Building2, Loader2, Upload } from "lucide-react";
import { toast } from "sonner";
import { PersonAvatar } from "@/components/PersonAvatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { localDb } from "@/integrations/local/client";
import { useAuth } from "@/lib/auth";
import { uploadProfilePhoto, validateImage } from "@/lib/photos";
import {
  COURSES,
  DEPARTMENTS,
  DESIGNATIONS,
  SECTIONS,
  SEMESTERS,
} from "@/lib/types";

export const Route = createFileRoute("/app/profile")({
  head: () => ({
    meta: [
      { title: "My Profile — AI Attendance System" },
      {
        name: "description",
        content:
          "View and edit your personal details, photo, department and class information as a teacher or student.",
      },
      { property: "og:title", content: "My Profile — AI Attendance System" },
      { property: "og:description", content: "Manage your account details and profile photo." },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { profile, refreshProfile } = useAuth();
  const isTeacher = profile?.role === "teacher";
  const [busy, setBusy] = useState(false);
  const [photo, setPhoto] = useState<File | null>(null);

  const [form, setForm] = useState({
    full_name: "",
    phone: "",
    date_of_birth: "",
    department: "",
    course: "",
    semester: "",
    section: "",
    roll_number: "",
    designation: "",
    subjects: "",
  });

  useEffect(() => {
    if (!profile) return;
    setForm({
      full_name: profile.full_name ?? "",
      phone: profile.phone ?? "",
      date_of_birth: profile.date_of_birth ?? "",
      department: profile.department ?? DEPARTMENTS[0]!,
      course: profile.course ?? COURSES[0]!,
      semester: profile.semester ?? SEMESTERS[0]!,
      section: profile.section ?? SECTIONS[0]!,
      roll_number: profile.roll_number ?? "",
      designation: profile.designation ?? DESIGNATIONS[0]!,
      subjects: profile.subjects?.join(", ") ?? "",
    });
  }, [profile]);

  const { data: institute } = useQuery({
    queryKey: ["institute", profile?.institute_id],
    enabled: Boolean(profile?.institute_id),
    queryFn: async () => {
      const { data, error } = await localDb
        .from("institutes")
        .select("id, code, name, email, phone, address")
        .eq("id", profile!.institute_id!)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data;
    },
  });

  const photoPreview = useMemo(() => (photo ? URL.createObjectURL(photo) : null), [photo]);
  useEffect(
    () => () => {
      if (photoPreview) URL.revokeObjectURL(photoPreview);
    },
    [photoPreview],
  );

  const set = (key: keyof typeof form, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!profile) return;
    setBusy(true);
    try {
      let photoPath = profile.photo_url;
      if (photo) {
        const invalid = validateImage(photo);
        if (invalid) {
          toast.error(invalid);
          return;
        }
        photoPath = await uploadProfilePhoto(profile.user_id, photo);
      }

      const payload = {
        full_name: form.full_name.trim(),
        phone: form.phone.trim() || null,
        date_of_birth: form.date_of_birth || null,
        department: form.department,
        photo_url: photoPath,
        ...(isTeacher
          ? {
              designation: form.designation,
              subjects: form.subjects
                .split(",")
                .map((s) => s.trim())
                .filter(Boolean),
            }
          : {
              course: form.course,
              semester: form.semester,
              section: form.section,
              roll_number: form.roll_number.trim() || null,
            }),
      };

      const { error } = await localDb.from("profiles").update(payload).eq("id", profile.id);
      if (error) throw new Error(error.message);
      setPhoto(null);
      await refreshProfile();
      toast.success("Profile updated");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not update your profile");
    } finally {
      setBusy(false);
    }
  };

  if (!profile) return null;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-2xl font-semibold">My Profile</h1>
        <p className="text-sm text-muted-foreground">
          Keep your details up to date — they appear across attendance records and reports.
        </p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <Card>
          <CardHeader>
            <CardTitle>Edit details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={save} className="space-y-5">
              <div className="flex items-center gap-4">
                <div className="grid size-20 shrink-0 place-items-center overflow-hidden rounded-2xl border bg-secondary">
                  {photoPreview ? (
                    <img src={photoPreview} alt="New profile" className="size-full object-cover" />
                  ) : (
                    <PersonAvatar
                      name={profile.full_name}
                      photoPath={profile.photo_url}
                      className="size-20 rounded-2xl"
                    />
                  )}
                </div>
                <div className="flex-1 space-y-2">
                  <Label htmlFor="photo">
                    <span className="inline-flex items-center gap-2">
                      <Upload className="size-3.5" /> Change photo
                    </span>
                  </Label>
                  <Input
                    id="photo"
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    onChange={(e) => setPhoto(e.target.files?.[0] ?? null)}
                  />
                  <p className="text-xs text-muted-foreground">JPG, PNG or WEBP up to 5 MB.</p>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="full_name">Full name</Label>
                  <Input
                    id="full_name"
                    value={form.full_name}
                    onChange={(e) => set("full_name", e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" value={profile.email} disabled />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="idNumber">
                    {isTeacher ? "Teacher ID" : "Student ID"}
                  </Label>
                  <Input
                    id="idNumber"
                    value={(isTeacher ? profile.teacher_id : profile.student_id) ?? "—"}
                    disabled
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={form.phone}
                    onChange={(e) => set("phone", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dob">Date of birth</Label>
                  <Input
                    id="dob"
                    type="date"
                    value={form.date_of_birth}
                    onChange={(e) => set("date_of_birth", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Department</Label>
                  <Picker
                    value={form.department}
                    onChange={(v) => set("department", v)}
                    options={DEPARTMENTS}
                  />
                </div>

                {isTeacher ? (
                  <>
                    <div className="space-y-2">
                      <Label>Designation</Label>
                      <Picker
                        value={form.designation}
                        onChange={(v) => set("designation", v)}
                        options={DESIGNATIONS}
                      />
                    </div>
                    <div className="space-y-2 sm:col-span-2">
                      <Label htmlFor="subjects">Subjects (comma separated)</Label>
                      <Input
                        id="subjects"
                        value={form.subjects}
                        onChange={(e) => set("subjects", e.target.value)}
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label>Course</Label>
                      <Picker
                        value={form.course}
                        onChange={(v) => set("course", v)}
                        options={COURSES}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Semester</Label>
                      <Picker
                        value={form.semester}
                        onChange={(v) => set("semester", v)}
                        options={SEMESTERS}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Section</Label>
                      <Picker
                        value={form.section}
                        onChange={(v) => set("section", v)}
                        options={SECTIONS}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="roll">Roll number</Label>
                      <Input
                        id="roll"
                        value={form.roll_number}
                        onChange={(e) => set("roll_number", e.target.value)}
                      />
                    </div>
                  </>
                )}
              </div>

              <Button type="submit" disabled={busy}>
                {busy ? <Loader2 className="size-4 animate-spin" /> : null}
                Save changes
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="h-fit">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Building2 className="size-4" /> Institute
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p className="font-medium">{institute?.name ?? "Not linked"}</p>
            {institute ? (
              <>
                <p className="text-muted-foreground">
                  Code · <span className="font-mono tracking-widest">{institute.code}</span>
                </p>
                {institute.email ? <p className="text-muted-foreground">{institute.email}</p> : null}
                {institute.phone ? <p className="text-muted-foreground">{institute.phone}</p> : null}
                {institute.address ? (
                  <p className="text-muted-foreground">{institute.address}</p>
                ) : null}
                <p className="pt-2 text-xs text-muted-foreground">
                  Share this code so new teachers and students can join your institute panel.
                </p>
              </>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Picker({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (value: string) => void;
  options: string[];
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {options.map((option) => (
          <SelectItem key={option} value={option}>
            {option}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
