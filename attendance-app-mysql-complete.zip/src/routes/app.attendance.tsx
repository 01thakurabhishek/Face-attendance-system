import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { CheckSquare, ClipboardList, Download, ScanFace } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { AttendanceHistory } from "@/components/AttendanceHistory";
import { ClassScopeFilter } from "@/components/ClassScopeFilter";
import { AttendancePieChart } from "@/components/AttendancePieChart";
import { EmptyState } from "@/components/EmptyState";
import { FaceEnroll } from "@/components/FaceEnroll";
import { PersonAvatar } from "@/components/PersonAvatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { markAttendance, upsertAttendance } from "@/lib/attendance";
import {
  emptyScope,
  matchesScope,
  matchesClass,
  scopeLabel,
  type ClassScope,
} from "@/lib/classScope";
import { useAuth } from "@/lib/auth";
import { downloadCsv } from "@/lib/export";
import { attendanceQuery, formatDate, formatTime, lecturesQuery, profilesQuery } from "@/lib/queries";

export const Route = createFileRoute("/app/attendance")({
  head: () => ({
    meta: [
      { title: "Attendance — AI Attendance System" },
      { name: "description", content: "Review attendance records, enroll faces and mark students manually." },
      { property: "og:title", content: "Attendance — AI Attendance System" },
      { property: "og:description", content: "Attendance records and face enrollment." },
    ],
  }),
  component: AttendancePage,
});

function AttendancePage() {
  const { profile } = useAuth();
  if (!profile) return null;
  return profile.role === "teacher" ? <TeacherAttendance /> : <StudentAttendance />;
}

function TeacherAttendance() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const { data: rows = [] } = useQuery(attendanceQuery());
  const { data: allLectures = [] } = useQuery(lecturesQuery());
  const { data: allStudents = [] } = useQuery(profilesQuery("student"));
  const [scope, setScope] = useState<ClassScope>(emptyScope);
  const [lectureFilter, setLectureFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [enrollId, setEnrollId] = useState("");

  // Everything below works on one branch/course/semester/section at a time.
  const lectures = allLectures.filter((lecture) => matchesScope(lecture, scope));
  const students = allStudents.filter((student) => matchesScope(student, scope));
  const lectureIds = new Set(lectures.map((lecture) => lecture.id));

  const filtered = rows.filter((row) => {
    if (!lectureIds.has(row.lecture_id)) return false;
    const byLecture = lectureFilter === "all" || row.lecture_id === lectureFilter;
    const term = search.trim().toLowerCase();
    const bySearch =
      !term ||
      row.profiles?.full_name.toLowerCase().includes(term) ||
      (row.profiles?.student_id ?? "").toLowerCase().includes(term) ||
      (row.lectures?.subject ?? "").toLowerCase().includes(term);
    return byLecture && bySearch;
  });

  const manual = useMutation({
    mutationFn: async ({
      lectureId,
      studentId,
      status,
    }: {
      lectureId: string;
      studentId: string;
      status: "present" | "late" | "absent";
    }) => {
      const lecture = lectures.find((item) => item.id === lectureId);
      const student = students.find((item) => item.id === studentId);
      if (!lecture || !matchesClass(student, lecture)) {
        throw new Error("Choose a student from the lecture's branch, course, semester and section.");
      }
      const result = await markAttendance({
        lectureId,
        studentProfileId: studentId,
        status,
        method: "manual",
        markedBy: profile?.id ?? null,
      });
      if (result === "duplicate") throw new Error("That student is already marked for this lecture.");
    },
    onSuccess: async (_data, vars) => {
      await queryClient.invalidateQueries({ queryKey: ["attendance"] });
      toast.success(`Marked ${vars.status}`);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const [manualLecture, setManualLecture] = useState("");
  const [manualStudent, setManualStudent] = useState("");
  const [manualStatus, setManualStatus] = useState<"present" | "late" | "absent">("present");
  const enrollTarget = students.find((s) => s.id === enrollId);

  const [bulkLecture, setBulkLecture] = useState("");
  const [bulkStatus, setBulkStatus] = useState<"present" | "late" | "absent">("present");
  const [bulkSelected, setBulkSelected] = useState<Set<string>>(new Set());

  const bulk = useMutation({
    mutationFn: async () => {
      if (!bulkLecture) throw new Error("Choose a lecture first");
      if (bulkSelected.size === 0) throw new Error("Select at least one student");
      const lecture = lectures.find((item) => item.id === bulkLecture);
      if (!lecture || [...bulkSelected].some((id) =>
        !matchesClass(students.find((student) => student.id === id), lecture))) {
        throw new Error("Selected students must belong to the lecture's class.");
      }
      let created = 0;
      let updated = 0;
      for (const studentId of bulkSelected) {
        const result = await upsertAttendance({
          lectureId: bulkLecture,
          studentProfileId: studentId,
          status: bulkStatus,
          method: "manual",
          markedBy: profile?.id ?? null,
        });
        if (result === "created") created += 1;
        else updated += 1;
      }
      return { created, updated };
    },
    onSuccess: async ({ created, updated }) => {
      await queryClient.invalidateQueries({ queryKey: ["attendance"] });
      toast.success(`Marked ${bulkStatus}: ${created} new, ${updated} updated`);
      setBulkSelected(new Set());
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const toggleBulk = (id: string) =>
    setBulkSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const presentCount = filtered.filter((r) => r.status === "present").length;
  const lateCount = filtered.filter((r) => r.status === "late").length;
  const absentCount = filtered.filter((r) => r.status === "absent").length;

  const selectedLecture = lectures.find((l) => l.id === lectureFilter);
  const studentStats = students.map((student) => {
    const mine = filtered.filter((r) => r.student_profile_id === student.id);
    const inLecture = lectureFilter !== "all"
      ? rows.find((r) => r.student_profile_id === student.id && r.lecture_id === lectureFilter)
      : undefined;
    return {
      student,
      inLecture,
      present: mine.filter((r) => r.status === "present").length,
      late: mine.filter((r) => r.status === "late").length,
      absent: mine.filter((r) => r.status === "absent").length,
    };
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold">Attendance</h1>
          <p className="text-sm text-muted-foreground">
            Every record across your lectures, plus face enrollment and manual marking.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() =>
            downloadCsv(
              "attendance-records",
              filtered.map((row) => ({
                date: row.lectures?.lecture_date ?? "",
                subject: row.lectures?.subject ?? "",
                student: row.profiles?.full_name ?? "",
                student_id: row.profiles?.student_id ?? "",
                status: row.status,
                method: row.method,
                confidence: row.confidence ? Math.round(row.confidence * 100) : "",
              })),
            )
          }
        >
          <Download className="size-4" /> Export CSV
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Class scope</CardTitle>
          <CardDescription>
            Showing {scopeLabel(scope)} — {students.length} students · {lectures.length} lectures
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ClassScopeFilter scope={scope} onChange={(next) => {
            setScope(next);
            setLectureFilter("all");
            setEnrollId("");
            setManualLecture("");
            setManualStudent("");
            setBulkLecture("");
            setBulkSelected(new Set());
          }} items={[...allStudents, ...allLectures]} />
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2 xl:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <ScanFace className="size-4" /> Enroll a student's face
            </CardTitle>
            <CardDescription>Pick a student, then capture their face from the camera.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Select value={enrollId} onValueChange={setEnrollId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a student" />
              </SelectTrigger>
              <SelectContent>
                {students.map((student) => (
                  <SelectItem key={student.id} value={student.id}>
                    {student.full_name} · {student.student_id ?? "—"}
                    {student.face_enrolled ? " ✓" : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {enrollTarget ? (
              <FaceEnroll
                profileId={enrollTarget.id}
                storageUserId={enrollTarget.user_id}
                personName={enrollTarget.full_name}
                enrolled={enrollTarget.face_enrolled}
              />
            ) : (
              <p className="text-sm text-muted-foreground">No student selected.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Mark manually</CardTitle>
            <CardDescription>For students the camera could not recognise.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Select value={manualLecture} onValueChange={setManualLecture}>
              <SelectTrigger>
                <SelectValue placeholder="Lecture" />
              </SelectTrigger>
              <SelectContent>
                {lectures.map((lecture) => (
                  <SelectItem key={lecture.id} value={lecture.id}>
                    {lecture.subject} · {formatDate(lecture.lecture_date)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={manualStudent} onValueChange={setManualStudent}>
              <SelectTrigger>
                <SelectValue placeholder="Student" />
              </SelectTrigger>
              <SelectContent>
                {students.map((student) => (
                  <SelectItem key={student.id} value={student.id}>
                    {student.full_name} · {student.student_id ?? "—"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={manualStatus}
              onValueChange={(v) => setManualStatus(v as "present" | "late" | "absent")}
            >
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="present">Present</SelectItem>
                <SelectItem value="late">Late</SelectItem>
                <SelectItem value="absent">Absent</SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={() => {
                if (!manualLecture || !manualStudent) {
                  toast.error("Choose a lecture and a student");
                  return;
                }
                manual.mutate({ lectureId: manualLecture, studentId: manualStudent, status: manualStatus });
              }}
              disabled={manual.isPending}
              variant={manualStatus === "absent" ? "destructive" : "default"}
            >
              Mark {manualStatus}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <CheckSquare className="size-4" /> Bulk marking
            </CardTitle>
            <CardDescription>Set Present, Late or Absent for several students at once.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Select value={bulkLecture} onValueChange={setBulkLecture}>
              <SelectTrigger>
                <SelectValue placeholder="Lecture" />
              </SelectTrigger>
              <SelectContent>
                {lectures.map((lecture) => (
                  <SelectItem key={lecture.id} value={lecture.id}>
                    {lecture.subject} · {formatDate(lecture.lecture_date)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex items-center gap-2">
              <Select
                value={bulkStatus}
                onValueChange={(v) => setBulkStatus(v as "present" | "late" | "absent")}
              >
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="present">Present</SelectItem>
                  <SelectItem value="late">Late</SelectItem>
                  <SelectItem value="absent">Absent</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setBulkSelected(
                    bulkSelected.size === students.length
                      ? new Set()
                      : new Set(students.map((s) => s.id)),
                  )
                }
              >
                {bulkSelected.size === students.length ? "Clear" : "All"}
              </Button>
            </div>
            <div className="max-h-44 space-y-1 overflow-y-auto rounded-lg border p-2">
              {students.map((student) => (
                <label
                  key={student.id}
                  className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 hover:bg-accent/50"
                >
                  <input
                    type="checkbox"
                    className="size-4 accent-primary"
                    checked={bulkSelected.has(student.id)}
                    onChange={() => toggleBulk(student.id)}
                  />
                  <span className="text-sm">{student.full_name}</span>
                  <span className="ml-auto text-xs text-muted-foreground">
                    {student.student_id ?? ""}
                  </span>
                </label>
              ))}
            </div>
            <Button
              onClick={() => bulk.mutate()}
              disabled={bulk.isPending || !bulkLecture || bulkSelected.size === 0}
              variant={bulkStatus === "absent" ? "destructive" : "default"}
              className="w-full"
            >
              Mark {bulkSelected.size} student{bulkSelected.size === 1 ? "" : "s"} {bulkStatus}
            </Button>
          </CardContent>
        </Card>

        <AttendancePieChart
          title="Present vs absent"
          description={`${presentCount} present · ${lateCount} late · ${absentCount} absent${
            lectureFilter !== "all" ? " (filtered lecture)" : ""
          }`}
          counts={{ present: presentCount, late: lateCount, absent: absentCount }}
        />
      </div>

      <Card>
        <CardHeader className="gap-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Records</CardTitle>
              <CardDescription>{filtered.length} entries</CardDescription>
            </div>
            <div className="flex flex-wrap gap-2">
              <Input
                placeholder="Search student or subject"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-56"
              />
              <Select value={lectureFilter} onValueChange={setLectureFilter}>
                <SelectTrigger className="w-56">
                  <SelectValue placeholder="All lectures" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All lectures</SelectItem>
                  {lectures.map((lecture) => (
                    <SelectItem key={lecture.id} value={lecture.id}>
                      {lecture.subject} · {formatDate(lecture.lecture_date)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          {filtered.length === 0 ? (
            <EmptyState
              icon={ClipboardList}
              title="No attendance records"
              description="Run a live or video session, or mark students manually."
            />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((row) => (
                  <TableRow key={row.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <PersonAvatar
                          name={row.profiles?.full_name ?? "?"}
                          photoPath={row.profiles?.photo_url}
                          className="size-8"
                        />
                        <div>
                          <p className="text-sm font-medium">{row.profiles?.full_name ?? "—"}</p>
                          <p className="text-xs text-muted-foreground">{row.profiles?.student_id ?? "—"}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{row.lectures?.subject ?? "—"}</TableCell>
                    <TableCell>{row.lectures ? formatDate(row.lectures.lecture_date) : "—"}</TableCell>
                    <TableCell>{row.lectures ? formatTime(row.lectures.start_time) : "—"}</TableCell>
                    <TableCell className="capitalize">{row.method}</TableCell>
                    <TableCell>
                      <Badge className="capitalize">{row.status}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Student-wise history</CardTitle>
          <CardDescription>
            {selectedLecture
              ? `${selectedLecture.subject} · ${formatDate(selectedLecture.lecture_date)} — status in this lecture plus all-time totals.`
              : "All-time totals per student. Pick a lecture above to also see each student's status in it."}
          </CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                {lectureFilter !== "all" ? <TableHead>This lecture</TableHead> : null}
                <TableHead className="text-center">Present</TableHead>
                <TableHead className="text-center">Late</TableHead>
                <TableHead className="text-center">Absent</TableHead>
                <TableHead className="text-center">Attendance %</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {studentStats.map(({ student, inLecture, present, late, absent }) => {
                const total = present + late + absent;
                const pct = total === 0 ? "—" : `${Math.round(((present + late) / total) * 100)}%`;
                return (
                  <TableRow key={student.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <PersonAvatar
                          name={student.full_name}
                          photoPath={student.photo_url}
                          className="size-8"
                        />
                        <div>
                          <p className="text-sm font-medium">{student.full_name}</p>
                          <p className="text-xs text-muted-foreground">{student.student_id ?? "—"}</p>
                        </div>
                      </div>
                    </TableCell>
                    {lectureFilter !== "all" ? (
                      <TableCell>
                        {inLecture ? (
                          <Badge className="capitalize">{inLecture.status}</Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">Not marked</span>
                        )}
                      </TableCell>
                    ) : null}
                    <TableCell className="text-center text-success">{present}</TableCell>
                    <TableCell className="text-center text-warning">{late}</TableCell>
                    <TableCell className="text-center text-destructive">{absent}</TableCell>
                    <TableCell className="text-center font-medium">{pct}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function StudentAttendance() {
  const { profile, refreshProfile } = useAuth();
  if (!profile) return null;
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">My attendance</h1>
        <p className="text-sm text-muted-foreground">
          Your records, subject by subject — plus your face enrollment.
        </p>
      </div>
      <FaceEnroll
        profileId={profile.id}
        storageUserId={profile.user_id}
        personName={profile.full_name}
        enrolled={profile.face_enrolled}
        onEnrolled={() => void refreshProfile()}
      />
      <AttendanceHistory studentProfileId={profile.id} />
    </div>
  );
}
