import { createFileRoute, Link } from "@tanstack/react-router";
import { KeyRound, Loader2, MailCheck, ScanFace } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ThemeToggle } from "@/components/ThemeToggle";
import { localDb } from "@/integrations/local/client";
import { verifyPasswordResetIdentity } from "@/lib/password.functions";
import type { AppRole } from "@/lib/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Reset your password — AI Attendance System" },
      {
        name: "description",
        content:
          "Verify your student or teacher ID, name and email to receive a secure password reset link.",
      },
      { property: "og:title", content: "Reset your password — AI Attendance System" },
      { property: "og:description", content: "Recover access to your attendance account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ForgotPasswordPage,
});

function ForgotPasswordPage() {
  const [role, setRole] = useState<AppRole>("student");
  const [idNumber, setIdNumber] = useState("");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      const result = await verifyPasswordResetIdentity({
        data: { role, idNumber, fullName, email },
      });
      if (!result.ok) {
        toast.error(result.message);
        return;
      }
      const { error } = await localDb.auth.resetPasswordForEmail(result.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw new Error(error.message);
      setSent(true);
      toast.success("Reset link sent to your email.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not start the password reset.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex items-center justify-between p-4">
        <Link to="/auth" search={{ mode: "login" }} className="flex items-center gap-2 text-sm">
          <ScanFace className="size-4" /> Back to login
        </Link>
        <ThemeToggle />
      </div>
      <main className="flex flex-1 items-center justify-center px-4 pb-16">
        <Card className="w-full max-w-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-display text-xl">
              <KeyRound className="size-5" /> Forgot your password?
            </CardTitle>
            <CardDescription>
              Confirm your ID, full name and registered email. If they match your account we email
              you a secure link to set a new password.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {sent ? (
              <div className="space-y-4 text-sm">
                <p className="flex items-center gap-2 text-primary">
                  <MailCheck className="size-4" /> Check {email} for the reset link.
                </p>
                <p className="text-muted-foreground">
                  The link opens the page where you choose a new password. It expires after a short
                  while — request another one if it does.
                </p>
                <Button variant="outline" onClick={() => setSent(false)}>
                  Send again
                </Button>
              </div>
            ) : (
              <form onSubmit={(e) => void submit(e)} className="space-y-4">
                <div className="flex rounded-xl border p-1">
                  {(["student", "teacher"] as const).map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => setRole(option)}
                      className={cn(
                        "flex-1 rounded-lg px-4 py-2 text-sm font-medium capitalize transition-colors",
                        role === option
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground",
                      )}
                    >
                      {option}
                    </button>
                  ))}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="idNumber">{role === "student" ? "Student ID" : "Teacher ID"}</Label>
                  <Input
                    id="idNumber"
                    value={idNumber}
                    onChange={(e) => setIdNumber(e.target.value)}
                    placeholder={role === "student" ? "e.g. 21CS045" : "e.g. TCH1042"}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full name</Label>
                  <Input
                    id="fullName"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="As registered"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Registered email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    autoComplete="email"
                  />
                </div>
                <Button type="submit" className="w-full" disabled={busy}>
                  {busy ? <Loader2 className="size-4 animate-spin" /> : null}
                  Send reset link
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
