import { queryOptions } from "@tanstack/react-query";
import { localDb } from "@/integrations/local/client";
import type { Database } from "@/integrations/local/types";

export type Exam = Database["public"]["Tables"]["exams"]["Row"];
export type ExamQuestion = Database["public"]["Tables"]["exam_questions"]["Row"];
export type ExamMark = Database["public"]["Tables"]["exam_marks"]["Row"];
export type ExamSubmission = Database["public"]["Tables"]["exam_submissions"]["Row"];
export type ExamType = Database["public"]["Enums"]["exam_type"];

export const EXAM_TYPES: { value: ExamType; label: string; paper: boolean }[] = [
  { value: "ct1", label: "Class Test 1", paper: true },
  { value: "ct2", label: "Class Test 2", paper: true },
  { value: "sessional", label: "Sessional Exam", paper: false },
  { value: "put", label: "PUT Exam", paper: false },
];

export const examTypeLabel = (type: ExamType) =>
  EXAM_TYPES.find((entry) => entry.value === type)?.label ?? type;

export const canHavePaper = (type: ExamType) =>
  EXAM_TYPES.find((entry) => entry.value === type)?.paper ?? false;

export const examsQuery = () =>
  queryOptions({
    queryKey: ["exams"],
    queryFn: async () => {
      const { data, error } = await localDb
        .from("exams")
        .select("*")
        .order("exam_date", { ascending: false });
      if (error) throw new Error(error.message);
      return (data ?? []) as Exam[];
    },
  });

export const examQuestionsQuery = (examId: string) =>
  queryOptions({
    queryKey: ["exam-questions", examId],
    queryFn: async () => {
      const { data, error } = await localDb
        .from("exam_questions")
        .select("*")
        .eq("exam_id", examId)
        .order("question_no");
      if (error) throw new Error(error.message);
      return (data ?? []) as ExamQuestion[];
    },
  });

export const examMarksQuery = (examId: string) =>
  queryOptions({
    queryKey: ["exam-marks", examId],
    queryFn: async () => {
      const { data, error } = await localDb.from("exam_marks").select("*").eq("exam_id", examId);
      if (error) throw new Error(error.message);
      return (data ?? []) as ExamMark[];
    },
  });

export const examSubmissionsQuery = (examId: string) =>
  queryOptions({
    queryKey: ["exam-submissions", examId],
    queryFn: async () => {
      const { data, error } = await localDb
        .from("exam_submissions")
        .select("*")
        .eq("exam_id", examId);
      if (error) throw new Error(error.message);
      return (data ?? []) as ExamSubmission[];
    },
  });

/** Answers are stored as a map of question id -> written answer. */
export function answerMap(submission: ExamSubmission | undefined) {
  const raw = (submission?.answers ?? {}) as Record<string, unknown>;
  const out: Record<string, string> = {};
  for (const [key, value] of Object.entries(raw)) out[key] = typeof value === "string" ? value : "";
  return out;
}
