import type { InstituteSummary } from "@/lib/institute.functions";

const KEY = "attendance.institute";

export function loadStoredInstitute(): InstituteSummary | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as InstituteSummary;
    return parsed?.id && parsed?.code ? parsed : null;
  } catch {
    return null;
  }
}

export function storeInstitute(institute: InstituteSummary) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(institute));
}

export function clearStoredInstitute() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(KEY);
}
