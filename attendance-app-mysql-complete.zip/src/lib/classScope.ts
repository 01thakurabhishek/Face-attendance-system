/**
 * Shared "class scope" — branch (department) → course → semester → section.
 * Every branch keeps its own courses, semesters and sections, so lists across
 * the app filter with the same cascading rules.
 */
export const ALL_SCOPE = "all";

export type ClassScope = {
  department: string;
  course: string;
  semester: string;
  section: string;
};

export type Scoped = {
  department?: string | null;
  course?: string | null;
  semester?: string | null;
  section?: string | null;
};

export const emptyScope: ClassScope = {
  department: ALL_SCOPE,
  course: ALL_SCOPE,
  semester: ALL_SCOPE,
  section: ALL_SCOPE,
};

/** Unspecified class fields apply to every cohort; specified fields must match. */
export function matchesClass(person: Scoped | null | undefined, target: Scoped) {
  if (!person) return false;
  return (["department", "course", "semester", "section"] as const).every(
    (key) => !target[key] || person[key] === target[key],
  );
}

export function isScoped(scope: ClassScope) {
  return (Object.values(scope) as string[]).some((value) => value !== ALL_SCOPE);
}

export function matchesScope(item: Scoped | null | undefined, scope: ClassScope) {
  if (!item) return !isScoped(scope);
  if (scope.department !== ALL_SCOPE && item.department !== scope.department) return false;
  if (scope.course !== ALL_SCOPE && item.course !== scope.course) return false;
  if (scope.semester !== ALL_SCOPE && item.semester !== scope.semester) return false;
  if (scope.section !== ALL_SCOPE && item.section !== scope.section) return false;
  return true;
}

function unique(values: (string | null | undefined)[]) {
  return [...new Set(values.filter((v): v is string => Boolean(v)))];
}

/** Cascading option lists: each level only offers values valid for the levels above it. */
export function scopeOptions(items: Scoped[], scope: ClassScope) {
  const byDepartment = items.filter(
    (i) => scope.department === ALL_SCOPE || i.department === scope.department,
  );
  const byCourse = byDepartment.filter(
    (i) => scope.course === ALL_SCOPE || i.course === scope.course,
  );
  const bySemester = byCourse.filter(
    (i) => scope.semester === ALL_SCOPE || i.semester === scope.semester,
  );
  const alpha = (a: string, b: string) => a.localeCompare(b, undefined, { numeric: true });
  return {
    departments: unique(items.map((i) => i.department)).sort(alpha),
    courses: unique(byDepartment.map((i) => i.course)).sort(alpha),
    semesters: unique(byCourse.map((i) => i.semester)).sort(alpha),
    sections: unique(bySemester.map((i) => i.section)).sort(alpha),
  };
}

export function scopeLabel(scope: ClassScope) {
  const parts = [
    scope.department,
    scope.course,
    scope.semester === ALL_SCOPE ? ALL_SCOPE : `Sem ${scope.semester}`,
    scope.section === ALL_SCOPE ? ALL_SCOPE : `Section ${scope.section}`,
  ].filter((part) => part !== ALL_SCOPE);
  return parts.length ? parts.join(" · ") : "All branches";
}
