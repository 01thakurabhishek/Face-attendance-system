import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
export const verifyPasswordResetIdentity = createServerFn({method:"POST"}).inputValidator(data=>z.object({role:z.enum(["student","teacher"]),idNumber:z.string().min(1).max(120),fullName:z.string().min(1).max(160),email:z.string().email().max(200)}).parse(data)).handler(async ({data})=>{const {localApi}=await import("@/integrations/local/client.server"); return localApi("/api/auth/verify-reset-identity",data);});
