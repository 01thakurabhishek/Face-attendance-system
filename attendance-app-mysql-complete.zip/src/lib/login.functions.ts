import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
export const resolveLoginEmail = createServerFn({ method: "POST" }).inputValidator((data) => z.object({ identifier:z.string().min(1).max(120), role:z.enum(["student","teacher"]), instituteId:z.string().uuid() }).parse(data)).handler(async ({data}) => { const { localApi } = await import("@/integrations/local/client.server"); return localApi("/api/auth/resolve-login-email", data); });
