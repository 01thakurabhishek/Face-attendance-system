import { localDb } from "@/integrations/local/client";

export const MAX_PHOTO_BYTES = 5 * 1024 * 1024;
export const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];

export function validateImage(file: File): string | null {
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    return "Profile photo must be a JPG, PNG or WEBP image.";
  }
  if (file.size > MAX_PHOTO_BYTES) {
    return "Profile photo must be smaller than 5 MB.";
  }
  return null;
}

/** Uploads the photo to the private avatars bucket and returns the stored object path. */
export async function uploadProfilePhoto(userId: string, file: File): Promise<string> {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "jpg";
  const path = `${userId}/${Date.now()}.${ext}`;
  const { error } = await localDb.storage.from("avatars").upload(path, file, {
    cacheControl: "3600",
    upsert: true,
    contentType: file.type,
  });
  if (error) throw new Error(error.message);
  return path;
}

const signedCache = new Map<string, { url: string; expires: number }>();

/** Signed URLs for the private bucket, cached in-memory for the session. */
export async function getPhotoUrl(path: string | null | undefined): Promise<string | null> {
  if (!path) return null;
  if (path.startsWith("http")) return path;
  const cached = signedCache.get(path);
  if (cached && cached.expires > Date.now()) return cached.url;
  const { data, error } = await localDb.storage.from("avatars").createSignedUrl(path, 3600);
  if (error || !data?.signedUrl) return null;
  signedCache.set(path, { url: data.signedUrl, expires: Date.now() + 3_000_000 });
  return data.signedUrl;
}

export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}
