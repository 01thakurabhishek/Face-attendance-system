import { localDb } from "@/integrations/local/client";
import type { AttendanceMode, AttendanceStatus } from "@/lib/types";

export type MarkArgs = {
  lectureId: string;
  studentProfileId: string;
  status?: AttendanceStatus;
  method?: AttendanceMode;
  confidence?: number | null;
  markedBy?: string | null;
};

/** Inserts an attendance row unless the student is already marked for that lecture. */
export async function markAttendance(args: MarkArgs): Promise<"created" | "duplicate"> {
  const { data: existing, error: readError } = await localDb
    .from("attendance")
    .select("id")
    .eq("lecture_id", args.lectureId)
    .eq("student_profile_id", args.studentProfileId)
    .maybeSingle();
  if (readError) throw new Error(readError.message);
  if (existing) return "duplicate";

  const { error } = await localDb.from("attendance").insert({
    lecture_id: args.lectureId,
    student_profile_id: args.studentProfileId,
    status: args.status ?? "present",
    method: args.method ?? "face",
    confidence: args.confidence ?? null,
    marked_by: args.markedBy ?? null,
  });
  if (error) throw new Error(error.message);
  return "created";
}

/** Inserts or updates a student's status for a lecture. Returns "created" | "updated". */
export async function upsertAttendance(args: MarkArgs): Promise<"created" | "updated"> {
  const { data: existing, error: readError } = await localDb
    .from("attendance")
    .select("id")
    .eq("lecture_id", args.lectureId)
    .eq("student_profile_id", args.studentProfileId)
    .maybeSingle();
  if (readError) throw new Error(readError.message);

  if (existing) {
    const { error } = await localDb
      .from("attendance")
      .update({
        status: args.status ?? "present",
        method: args.method ?? "manual",
        marked_by: args.markedBy ?? null,
      })
      .eq("id", existing.id);
    if (error) throw new Error(error.message);
    return "updated";
  }

  const { error } = await localDb.from("attendance").insert({
    lecture_id: args.lectureId,
    student_profile_id: args.studentProfileId,
    status: args.status ?? "present",
    method: args.method ?? "manual",
    confidence: args.confidence ?? null,
    marked_by: args.markedBy ?? null,
  });
  if (error) throw new Error(error.message);
  return "created";
}

export async function logTracking(args: {
  profileId: string | null;
  source: string;
  confidence?: number | null;
  observedBy?: string | null;
}) {
  const { error } = await localDb.from("tracking_logs").insert({
    profile_id: args.profileId,
    source: args.source,
    confidence: args.confidence ?? null,
    observed_by: args.observedBy ?? null,
  });
  if (error) throw new Error(error.message);
}

/** Saves a 128-d descriptor onto a profile (face enrollment). */
export async function saveFaceDescriptor(profileId: string, descriptor: number[], photoPath?: string) {
  const { error } = await localDb
    .from("face_enrollments")
    .upsert({ profile_id: profileId, descriptor }, { onConflict: "profile_id" });
  if (error) throw new Error(error.message);
  if (photoPath) {
    const { error: photoError } = await localDb
      .from("profiles")
      .update({ photo_url: photoPath })
      .eq("id", profileId);
    if (photoError) throw new Error(photoError.message);
  }
}
