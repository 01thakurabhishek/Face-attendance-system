import { queryOptions } from "@tanstack/react-query";
import { localDb } from "@/integrations/local/client";
import type { Attendance, Lecture, Profile, TrackingLog } from "@/lib/types";

export const profilesQuery = (role?: "student" | "teacher") =>
  queryOptions({
    queryKey: ["profiles", role ?? "all"],
    queryFn: async () => {
      let query = localDb.from("profiles").select("*").order("full_name");
      if (role) query = query.eq("role", role);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return (data ?? []) as Profile[];
    },
  });

export type FaceEnrollment = { profile_id: string; descriptor: number[] };

/** Biometric descriptors live in their own restricted table (owner + same-institute teachers). */
export const faceEnrollmentsQuery = () =>
  queryOptions({
    queryKey: ["face-enrollments"],
    queryFn: async () => {
      const { data, error } = await localDb.from("face_enrollments").select("profile_id, descriptor");
      if (error) throw new Error(error.message);
      return (data ?? []) as FaceEnrollment[];
    },
  });

/** Joins profiles with their descriptors, skipping anyone not enrolled. */
export function knownFacesFrom<T extends { id: string }>(people: T[], enrollments: FaceEnrollment[]) {
  const byProfile = new Map(enrollments.map((e) => [e.profile_id, e.descriptor]));
  return people
    .map((person) => ({ person, descriptor: byProfile.get(person.id) }))
    .filter((entry): entry is { person: T; descriptor: number[] } =>
      Array.isArray(entry.descriptor) && entry.descriptor.length >= 128,
    );
}

export const lecturesQuery = (teacherProfileId?: string) =>
  queryOptions({
    queryKey: ["lectures", teacherProfileId ?? "all"],
    queryFn: async () => {
      let query = localDb
        .from("lectures")
        .select("*")
        .order("lecture_date", { ascending: false })
        .order("start_time", { ascending: false });
      if (teacherProfileId) query = query.eq("teacher_profile_id", teacherProfileId);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return (data ?? []) as Lecture[];
    },
  });

export type AttendanceRow = Attendance & {
  profiles: Pick<Profile, "id" | "full_name" | "student_id" | "photo_url" | "section" | "semester"> | null;
  lectures: Pick<Lecture, "id" | "subject" | "lecture_date" | "start_time" | "section" | "semester"> | null;
};

export const attendanceQuery = (filters?: { lectureId?: string; studentProfileId?: string }) =>
  queryOptions({
    queryKey: ["attendance", filters?.lectureId ?? "all", filters?.studentProfileId ?? "all"],
    queryFn: async () => {
      let query = localDb
        .from("attendance")
        .select(
          "*, profiles:student_profile_id(id, full_name, student_id, photo_url, section, semester), lectures:lecture_id(id, subject, lecture_date, start_time, section, semester)",
        )
        .order("marked_at", { ascending: false });
      if (filters?.lectureId) query = query.eq("lecture_id", filters.lectureId);
      if (filters?.studentProfileId) query = query.eq("student_profile_id", filters.studentProfileId);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return (data ?? []) as unknown as AttendanceRow[];
    },
  });

export type TrackingRow = TrackingLog & {
  profiles: Pick<Profile, "id" | "full_name" | "student_id" | "photo_url" | "role"> | null;
};

export const trackingQuery = () =>
  queryOptions({
    queryKey: ["tracking"],
    queryFn: async () => {
      const { data, error } = await localDb
        .from("tracking_logs")
        .select("*, profiles:profile_id(id, full_name, student_id, photo_url, role)")
        .order("detected_at", { ascending: false })
        .limit(200);
      if (error) throw new Error(error.message);
      return (data ?? []) as unknown as TrackingRow[];
    },
  });

export function attendanceRate(present: number, total: number) {
  if (total === 0) return 0;
  return Math.round((present / total) * 100);
}

export function formatTime(value: string) {
  const [h, m] = value.split(":");
  const hour = Number(h);
  const suffix = hour >= 12 ? "PM" : "AM";
  const display = hour % 12 === 0 ? 12 : hour % 12;
  return `${display}:${m} ${suffix}`;
}

export function formatDate(value: string) {
  return new Date(`${value}T00:00:00`).toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}
