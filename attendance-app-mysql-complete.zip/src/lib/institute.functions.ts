import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
export type InstituteSummary = { id:string; code:string; name:string };
export const lookupInstitute = createServerFn({method:"POST"}).inputValidator(data=>z.object({code:z.string().trim().length(6)}).parse(data)).handler(async ({data}):Promise<InstituteSummary|null>=>{ const {localApi}=await import("@/integrations/local/client.server"); return localApi("/api/institutes/lookup",data); });
export const registerInstitute = createServerFn({method:"POST"}).inputValidator(data=>z.object({name:z.string().trim().min(2).max(160),email:z.string().trim().email().optional().or(z.literal("")),phone:z.string().trim().max(40).optional().or(z.literal("")),address:z.string().trim().max(400).optional().or(z.literal(""))}).parse(data)).handler(async ({data}):Promise<InstituteSummary>=>{const {localApi}=await import("@/integrations/local/client.server"); return localApi("/api/institutes/register",data);});
