import { queryOptions } from "@tanstack/react-query";
import { localDb } from "@/integrations/local/client";
import type { Database } from "@/integrations/local/types";

export type Note = Database["public"]["Tables"]["notes"]["Row"];

export const notesQuery = () =>
  queryOptions({
    queryKey: ["notes"],
    queryFn: async () => {
      const { data, error } = await localDb
        .from("notes")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return (data ?? []) as Note[];
    },
  });

/** Creates a short-lived signed URL so students can open a private note file. */
export async function noteFileUrl(path: string) {
  const { data, error } = await localDb.storage.from("notes").createSignedUrl(path, 60 * 10);
  if (error) throw new Error(error.message);
  return data.signedUrl;
}

export function formatFileSize(bytes: number | null) {
  if (!bytes) return "";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
