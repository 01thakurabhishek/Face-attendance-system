import type { Database } from "@/integrations/local/types";

export type Profile = Database["public"]["Tables"]["profiles"]["Row"];
export type Lecture = Database["public"]["Tables"]["lectures"]["Row"];
export type Attendance = Database["public"]["Tables"]["attendance"]["Row"];
export type TrackingLog = Database["public"]["Tables"]["tracking_logs"]["Row"];
export type AppRole = Database["public"]["Enums"]["app_role"];
export type AttendanceMode = Database["public"]["Enums"]["attendance_mode"];
export type LectureStatus = Database["public"]["Enums"]["lecture_status"];
export type AttendanceStatus = Database["public"]["Enums"]["attendance_status"];

export const DEPARTMENTS = [
  "Computer Science & Engineering",
  "Information Technology",
  "Electronics & Communication",
  "Electrical Engineering",
  "Mechanical Engineering",
  "Civil Engineering",
  "Other",
];

export const COURSES = ["B.Tech", "M.Tech", "BCA", "MCA", "B.Sc", "M.Sc", "MBA", "Other"];
export const SEMESTERS = ["1", "2", "3", "4", "5", "6", "7", "8"];
export const SECTIONS = ["A", "B", "C", "D", "E"];
export const DESIGNATIONS = [
  "Professor",
  "Associate Professor",
  "Assistant Professor",
  "Lecturer",
  "Lab Instructor",
  "Head of Department",
];
