/**
 * Real face recognition helpers backed by face-api.js (@vladmandic/face-api).
 * Models are served locally from /public/models — no external calls at runtime.
 * All imports are dynamic so nothing touches the SSR bundle.
 */

export const MODEL_URL = "/models";
/**
 * Max euclidean distance between two 128-d descriptors to count as the same person.
 * Deliberately strict: a loose threshold lets an unknown face borrow the closest
 * enrolled identity, which is the classic "anyone gets marked present" bug.
 */
export const MATCH_THRESHOLD = 0.42;
/** The runner-up must be at least this much further away, otherwise the match is ambiguous. */
export const MATCH_MARGIN = 0.06;
/** Detected face boxes smaller than this (in px) are too low-res to identify reliably. */
export const MIN_FACE_SIZE = 90;
/** Minimum detector confidence for a box to be considered at all. */
export const MIN_DETECTION_SCORE = 0.6;


type FaceApi = typeof import("@vladmandic/face-api");

let apiPromise: Promise<FaceApi> | null = null;
let modelsReady = false;

export async function loadFaceApi(): Promise<FaceApi> {
  if (!apiPromise) {
    apiPromise = import("@vladmandic/face-api").then(async (mod) => {
      const api = mod as unknown as FaceApi;
      const tf = (api as unknown as { tf: { setBackend: (b: string) => Promise<boolean>; ready: () => Promise<void> } }).tf;
      await tf.setBackend("webgl").catch(() => tf.setBackend("cpu"));
      await tf.ready();
      return api;
    });
  }
  return apiPromise;
}

export async function loadModels(): Promise<FaceApi> {
  const api = await loadFaceApi();
  if (!modelsReady) {
    await Promise.all([
      api.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
      api.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      api.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      api.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
    ]);
    modelsReady = true;
  }
  return api;
}

export function isModelsReady() {
  return modelsReady;
}

export async function fileToImageElement(file: File | Blob): Promise<HTMLImageElement> {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.crossOrigin = "anonymous";
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error("Could not read the selected image."));
      img.src = url;
    });
    // Keep the object URL alive for the lifetime of the element consumers.
    return img;
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
  }
}

/** Generate a single 128-d face descriptor from a photo. Returns null when no face is found. */
export async function descriptorFromImageFile(file: File | Blob): Promise<number[] | null> {
  const api = await loadModels();
  const img = await fileToImageElement(file);
  const detection = await api
    .detectSingleFace(img, new api.SsdMobilenetv1Options({ minConfidence: 0.4 }))
    .withFaceLandmarks()
    .withFaceDescriptor();
  if (!detection) return null;
  return Array.from(detection.descriptor);
}

export type DetectedFace = {
  descriptor: Float32Array;
  box: { x: number; y: number; width: number; height: number };
  /** Detector confidence that this box actually is a face. */
  score: number;
};

/** Detect every face in a video/image/canvas element with descriptors. */
export async function detectFaces(
  input: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement,
): Promise<DetectedFace[]> {
  const api = await loadModels();
  const results = await api
    .detectAllFaces(
      input,
      new api.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: MIN_DETECTION_SCORE }),
    )
    .withFaceLandmarks()
    .withFaceDescriptors();
  return results.map((r) => ({
    descriptor: r.descriptor,
    score: r.detection.score,
    box: {
      x: r.detection.box.x,
      y: r.detection.box.y,
      width: r.detection.box.width,
      height: r.detection.box.height,
    },
  }));
}

/** A face is only identifiable when it is close enough and confidently detected. */
export function isUsableFace(face: DetectedFace): boolean {
  return (
    face.score >= MIN_DETECTION_SCORE &&
    Math.min(face.box.width, face.box.height) >= MIN_FACE_SIZE &&
    face.descriptor.length >= 128
  );
}

export function euclideanDistance(a: ArrayLike<number>, b: ArrayLike<number>): number {
  let sum = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i += 1) {
    const d = (a[i] ?? 0) - (b[i] ?? 0);
    sum += d * d;
  }
  return Math.sqrt(sum);
}

export type KnownFace<T> = { person: T; descriptor: number[] };

export type MatchResult<T> = {
  person: T;
  distance: number;
  /** 0..1 similarity score shown to users as confidence. */
  confidence: number;
};

/**
 * Match a detected descriptor against registered people.
 * Returns null when nobody is close enough OR when two enrolled people are
 * almost equally close (ambiguous), so unknown faces are never mapped onto
 * whichever student happens to be nearest.
 */
export function matchFace<T>(
  descriptor: ArrayLike<number>,
  known: KnownFace<T>[],
  threshold = MATCH_THRESHOLD,
  margin = MATCH_MARGIN,
): MatchResult<T> | null {
  const verdict = evaluateFaceDescriptor(descriptor, known, threshold, margin);
  return verdict.ok ? verdict.match : null;
}

export type RejectReason =
  | "no-enrollments"
  | "too-small"
  | "low-detection"
  | "not-enrolled"
  | "ambiguous";

export type FaceVerdict<T> =
  | { ok: true; match: MatchResult<T> }
  | { ok: false; reason: RejectReason; title: string; detail: string };

const REJECTION_COPY: Record<RejectReason, { title: string; detail: string }> = {
  "no-enrollments": {
    title: "No enrolled faces",
    detail: "Nobody has registered a face yet, so no one can be matched.",
  },
  "too-small": {
    title: "Face too small",
    detail: "Ask the person to move closer to the camera before marking.",
  },
  "low-detection": {
    title: "Low detection quality",
    detail: "The camera isn't confident this is a clear face — improve lighting or angle.",
  },
  "not-enrolled": {
    title: "Not enrolled",
    detail: "This face doesn't match any registered student. Attendance was not submitted.",
  },
  ambiguous: {
    title: "Too ambiguous",
    detail: "Two enrolled students look almost equally close — refused to guess.",
  },
};

function reject<T>(reason: RejectReason): FaceVerdict<T> {
  const copy = REJECTION_COPY[reason];
  return { ok: false, reason, title: copy.title, detail: copy.detail };
}

/** Match a raw descriptor and explain the outcome when it is rejected. */
export function evaluateFaceDescriptor<T>(
  descriptor: ArrayLike<number>,
  known: KnownFace<T>[],
  threshold = MATCH_THRESHOLD,
  margin = MATCH_MARGIN,
): FaceVerdict<T> {
  const usable = known.filter((k) => k.descriptor && k.descriptor.length >= 128);
  if (usable.length === 0) return reject("no-enrollments");

  let best: MatchResult<T> | null = null;
  let runnerUp = Number.POSITIVE_INFINITY;
  for (const entry of usable) {
    const distance = euclideanDistance(descriptor, entry.descriptor);
    if (!best || distance < best.distance) {
      if (best) runnerUp = Math.min(runnerUp, best.distance);
      best = { person: entry.person, distance, confidence: 0 };
    } else if (distance < runnerUp) {
      runnerUp = distance;
    }
  }
  if (!best || best.distance > threshold) return reject("not-enrolled");
  if (Number.isFinite(runnerUp) && runnerUp - best.distance < margin) return reject("ambiguous");
  best.confidence = Math.max(0, Math.min(1, 1 - best.distance / threshold));
  return { ok: true, match: best };
}

/** Full gate for a detected face: quality checks first, then identity matching. */
export function evaluateFace<T>(face: DetectedFace, known: KnownFace<T>[]): FaceVerdict<T> {
  if (face.score < MIN_DETECTION_SCORE) return reject("low-detection");
  if (Math.min(face.box.width, face.box.height) < MIN_FACE_SIZE) return reject("too-small");
  if (face.descriptor.length < 128) return reject("low-detection");
  return evaluateFaceDescriptor(face.descriptor, known);
}

