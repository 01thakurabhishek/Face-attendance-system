import { ShieldAlert } from "lucide-react";
import type { ReactNode } from "react";
import { EmptyState } from "@/components/EmptyState";
import { useAuth } from "@/lib/auth";
import type { AppRole } from "@/lib/types";

/** Renders children only for the allowed roles; otherwise shows a clear notice. */
export function RoleGate({ allow, children }: { allow: AppRole[]; children: ReactNode }) {
  const { profile } = useAuth();
  if (!profile) return null;
  if (!allow.includes(profile.role)) {
    return (
      <EmptyState
        icon={ShieldAlert}
        title="You don't have access to this page"
        description={
          allow.includes("teacher")
            ? "This area is for teachers only. Use your dashboard to see your own attendance."
            : "This area is for students only."
        }
      />
    );
  }
  return <>{children}</>;
}
