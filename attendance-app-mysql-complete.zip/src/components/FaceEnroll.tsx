import { useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Loader2, ScanFace } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { saveFaceDescriptor } from "@/lib/attendance";
import { detectFaces, isUsableFace, loadModels } from "@/lib/face";

type Props = {
  profileId: string;
  /** Kept for call-site compatibility; the profile photo is never overwritten by enrollment. */
  storageUserId?: string;
  personName: string;
  enrolled: boolean;
  onEnrolled?: () => void;
};

/** Live webcam face enrollment: captures a frame, extracts a descriptor and stores it. */
export function FaceEnroll({ profileId, personName, enrolled, onEnrolled }: Props) {

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [camOn, setCamOn] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!camOn) return;
    let stream: MediaStream | null = null;
    let cancelled = false;
    setError(null);
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        await loadModels();
      } catch {
        if (!cancelled) setError("Camera unavailable. Allow camera access and try again.");
      }
    })();
    return () => {
      cancelled = true;
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [camOn]);

  const capture = async () => {
    const video = videoRef.current;
    if (!video || video.videoWidth === 0) {
      setError("Camera is still starting. Try again in a moment.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d")?.drawImage(video, 0, 0);
      const faces = await detectFaces(canvas);
      if (faces.length === 0) {
        setError("No face detected. Look straight at the camera in good light.");
        return;
      }
      if (faces.length > 1) {
        setError("More than one face in frame. Only the person enrolling should be visible.");
        return;
      }
      const face = faces[0]!;
      if (!isUsableFace(face)) {
        setError("Face is too small or unclear. Move closer to the camera and try again.");
        return;
      }
      const descriptor = Array.from(face.descriptor);
      // Enrollment only stores the face signature — the profile photo is never replaced.
      await saveFaceDescriptor(profileId, descriptor);
      await queryClient.invalidateQueries({ queryKey: ["profiles"] });

      toast.success(`Face enrolled for ${personName}`);
      setCamOn(false);
      onEnrolled?.();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Enrollment failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <ScanFace className="size-4" /> Face enrollment
        </CardTitle>
        <CardDescription>
          {enrolled
            ? `${personName} already has a registered face. Re-enroll to replace it.`
            : `Register ${personName}'s face so attendance can be marked automatically.`}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {camOn ? (
          <video ref={videoRef} muted playsInline className="aspect-video w-full rounded-xl bg-black object-cover" />
        ) : (
          <div className="grid aspect-video w-full place-items-center rounded-xl border border-dashed text-sm text-muted-foreground">
            {enrolled ? (
              <span className="flex items-center gap-2">
                <CheckCircle2 className="size-4 text-primary" /> Face registered
              </span>
            ) : (
              "Camera is off"
            )}
          </div>
        )}
        {error ? <p className="text-sm text-destructive">{error}</p> : null}
        <div className="flex flex-wrap gap-2">
          {camOn ? (
            <>
              <Button onClick={() => void capture()} disabled={busy}>
                {busy ? <Loader2 className="size-4 animate-spin" /> : <ScanFace className="size-4" />}
                Capture &amp; save
              </Button>
              <Button variant="outline" onClick={() => setCamOn(false)} disabled={busy}>
                Cancel
              </Button>
            </>
          ) : (
            <Button onClick={() => setCamOn(true)}>
              <ScanFace className="size-4" /> {enrolled ? "Re-enroll face" : "Start enrollment"}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
