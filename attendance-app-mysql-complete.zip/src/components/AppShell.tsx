import { Link, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  CalendarDays,
  ClipboardList,
  FileSpreadsheet,
  FileText,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Menu,
  Radar,
  ScanFace,
  UserCog,
  Users,
  Video,
  X,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { PersonAvatar } from "@/components/PersonAvatar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

type NavItem = { to: string; label: string; icon: typeof LayoutDashboard };

const teacherNav: NavItem[] = [
  { to: "/app/teacher", label: "Dashboard", icon: LayoutDashboard },
  { to: "/app/lectures", label: "Lectures", icon: CalendarDays },
  { to: "/app/live", label: "Live Attendance", icon: ScanFace },
  { to: "/app/video", label: "Video Attendance", icon: Video },
  { to: "/app/tracking", label: "Live Tracking", icon: Radar },
  { to: "/app/students", label: "Students", icon: Users },
  { to: "/app/teachers", label: "Teachers", icon: GraduationCap },
  { to: "/app/attendance", label: "Attendance", icon: ClipboardList },
  { to: "/app/exams", label: "Exams & Marks", icon: FileSpreadsheet },
  { to: "/app/notes", label: "Notes", icon: FileText },
  { to: "/app/reports", label: "Reports", icon: BarChart3 },
  { to: "/app/profile", label: "My Profile", icon: UserCog },
];

const studentNav: NavItem[] = [
  { to: "/app/student", label: "Dashboard", icon: LayoutDashboard },
  { to: "/app/my-attendance", label: "My Attendance", icon: ClipboardList },
  { to: "/app/my-exams", label: "My Exams", icon: FileSpreadsheet },
  { to: "/app/notes", label: "Notes", icon: FileText },
  { to: "/app/schedule", label: "Class Schedule", icon: CalendarDays },
  { to: "/app/profile", label: "My Profile", icon: UserCog },
];


export function AppShell({ children }: { children: ReactNode }) {
  const { profile, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const nav = profile?.role === "teacher" ? teacherNav : studentNav;

  return (
    <div className="min-h-screen bg-background">
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-72 border-r bg-sidebar transition-transform lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex h-16 items-center justify-between border-b px-5">
          <Link to="/" className="flex items-center gap-2">
            <span className="gradient-hero grid size-9 place-items-center rounded-xl">
              <ScanFace className="size-5 text-white" />
            </span>
            <span className="font-display text-sm font-semibold leading-tight">
              AI Attendance
              <span className="block text-xs font-normal text-muted-foreground">System</span>
            </span>
          </Link>
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen(false)}>
            <X className="size-5" />
          </Button>
        </div>

        <nav className="flex flex-col gap-1 p-3">
          {nav.map((item) => {
            const active = pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all",
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
                    : "text-sidebar-foreground hover:bg-sidebar-accent",
                )}
              >
                <item.icon className="size-4.5" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="absolute inset-x-0 bottom-0 border-t p-3">
          <div className="flex items-center gap-3 rounded-xl px-2 py-2">
            <PersonAvatar name={profile?.full_name ?? "User"} photoPath={profile?.photo_url} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{profile?.full_name}</p>
              <p className="truncate text-xs capitalize text-muted-foreground">
                {profile?.role} · {profile?.student_id ?? profile?.teacher_id ?? ""}
              </p>
            </div>
          </div>
          <Button variant="outline" className="mt-2 w-full" onClick={() => void signOut()}>
            <LogOut className="size-4" /> Logout
          </Button>
        </div>
      </aside>

      {open ? (
        <div
          className="fixed inset-0 z-40 bg-black/40 lg:hidden"
          onClick={() => setOpen(false)}
          aria-hidden
        />
      ) : null}

      <div className="lg:pl-72">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b bg-background/85 px-4 backdrop-blur md:px-8">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen(true)}>
            <Menu className="size-5" />
          </Button>
          <p className="hidden text-sm text-muted-foreground sm:block">
            {profile?.role === "teacher" ? "Teacher workspace" : "Student workspace"}
          </p>
          <div className="ml-auto flex items-center gap-2">
            <ThemeToggle />
          </div>
        </header>
        <main className="animate-fade-in p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}
