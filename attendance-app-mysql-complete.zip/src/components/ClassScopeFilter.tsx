import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ALL_SCOPE,
  emptyScope,
  scopeOptions,
  type ClassScope,
  type Scoped,
} from "@/lib/classScope";

/**
 * Branch → course → semester → section picker.
 * Choosing a higher level resets the lower ones so a branch never shows
 * another branch's courses or sections.
 */
export function ClassScopeFilter({
  scope,
  onChange,
  items,
  className,
}: {
  scope: ClassScope;
  onChange: (scope: ClassScope) => void;
  items: Scoped[];
  className?: string;
}) {
  const options = scopeOptions(items, scope);

  return (
    <div className={className ?? "grid gap-3 sm:grid-cols-2 lg:grid-cols-4"}>
      <ScopeSelect
        label="Branch"
        value={scope.department}
        options={options.departments}
        onChange={(department) => onChange({ ...emptyScope, department })}
      />
      <ScopeSelect
        label="Course"
        value={scope.course}
        options={options.courses}
        onChange={(course) =>
          onChange({ ...scope, course, semester: ALL_SCOPE, section: ALL_SCOPE })
        }
      />
      <ScopeSelect
        label="Semester"
        value={scope.semester}
        options={options.semesters}
        onChange={(semester) => onChange({ ...scope, semester, section: ALL_SCOPE })}
      />
      <ScopeSelect
        label="Section"
        value={scope.section}
        options={options.sections}
        onChange={(section) => onChange({ ...scope, section })}
      />
    </div>
  );
}

function ScopeSelect({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (value: string) => void;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger>
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL_SCOPE}>All</SelectItem>
          {options.map((option) => (
            <SelectItem key={option} value={option}>
              {option}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
