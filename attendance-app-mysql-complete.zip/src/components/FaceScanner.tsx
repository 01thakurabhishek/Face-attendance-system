import { useEffect, useRef, useState } from "react";
import { Loader2, VideoOff } from "lucide-react";
import { detectFaces, isUsableFace, loadModels, type DetectedFace } from "@/lib/face";
import { cn } from "@/lib/utils";

export type FaceLabel = { text: string; tone: "match" | "unknown" | "hint" };

type Props = {
  active: boolean;
  intervalMs?: number;
  onDetections: (faces: DetectedFace[]) => void | Promise<void>;
  /** Used to label each detected box in the live overlay. */
  labelFor?: (face: DetectedFace) => FaceLabel;
};

type Tracked = { face: DetectedFace; label: FaceLabel };

const toneClass: Record<FaceLabel["tone"], string> = {
  match: "border-primary text-primary-foreground bg-primary",
  unknown: "border-destructive text-destructive-foreground bg-destructive",
  hint: "border-muted-foreground text-foreground bg-secondary",
};

/** Webcam preview that runs face detection on an interval and draws boxes over detected faces. */
export function FaceScanner({ active, intervalMs = 1200, onDetections, labelFor }: Props) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const callbackRef = useRef(onDetections);
  callbackRef.current = onDetections;
  const labelRef = useRef(labelFor);
  labelRef.current = labelFor;
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [tracked, setTracked] = useState<Tracked[]>([]);
  const [dims, setDims] = useState({ width: 640, height: 480 });

  useEffect(() => {
    if (!active) {
      setTracked([]);
      return;
    }
    let cancelled = false;
    let stream: MediaStream | null = null;
    let timer: number | undefined;
    setError(null);

    const run = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480, facingMode: "user" },
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        await loadModels();
        if (cancelled) return;
        setReady(true);

        const tick = async () => {
          if (cancelled || !videoRef.current) return;
          try {
            const video = videoRef.current;
            const faces = await detectFaces(video);
            if (!cancelled) {
              if (video.videoWidth) setDims({ width: video.videoWidth, height: video.videoHeight });
              setTracked(
                faces.map((face) => ({
                  face,
                  label: !isUsableFace(face)
                    ? { text: "Move closer", tone: "hint" as const }
                    : (labelRef.current?.(face) ?? { text: "Face", tone: "hint" as const }),
                })),
              );
              await callbackRef.current(faces);
            }
          } catch {
            /* keep scanning on transient frame errors */
          }
          if (!cancelled) timer = window.setTimeout(tick, intervalMs);
        };
        timer = window.setTimeout(tick, 400);
      } catch {
        if (!cancelled) setError("Camera unavailable. Allow camera access in your browser and retry.");
      }
    };

    void run();
    return () => {
      cancelled = true;
      if (timer) window.clearTimeout(timer);
      stream?.getTracks().forEach((t) => t.stop());
      setReady(false);
      setTracked([]);
    };
  }, [active, intervalMs]);

  return (
    <div className="relative overflow-hidden rounded-2xl border bg-secondary">
      <video ref={videoRef} muted playsInline className="aspect-video w-full bg-black object-cover" />

      {active && ready && !error ? (
        <div
          className="pointer-events-none absolute inset-0"
          style={{ containerType: "size" }}
          aria-hidden="true"
        >
          <svg viewBox={`0 0 ${dims.width} ${dims.height}`} className="absolute inset-0 size-full">
            {tracked.map((t, i) => (
              <rect
                key={i}
                x={t.face.box.x}
                y={t.face.box.y}
                width={t.face.box.width}
                height={t.face.box.height}
                rx={12}
                fill="none"
                strokeWidth={4}
                className={
                  t.label.tone === "match"
                    ? "stroke-primary"
                    : t.label.tone === "unknown"
                      ? "stroke-destructive"
                      : "stroke-muted-foreground"
                }
              />
            ))}
          </svg>
          {tracked.map((t, i) => (
            <span
              key={i}
              className={cn(
                "absolute -translate-y-full whitespace-nowrap rounded-md border px-2 py-0.5 text-[11px] font-medium shadow",
                toneClass[t.label.tone],
              )}
              style={{
                left: `${(t.face.box.x / dims.width) * 100}%`,
                top: `${(t.face.box.y / dims.height) * 100}%`,
              }}
            >
              {t.label.text}
            </span>
          ))}
        </div>
      ) : null}

      {active && ready && !error ? (
        <span className="absolute bottom-2 right-2 rounded-md bg-background/80 px-2 py-1 text-xs text-muted-foreground">
          {tracked.length} face{tracked.length === 1 ? "" : "s"} in frame
        </span>
      ) : null}

      {!active ? (
        <div className="absolute inset-0 grid place-items-center bg-background/85 text-sm text-muted-foreground">
          <span className="flex items-center gap-2">
            <VideoOff className="size-4" /> Camera is off
          </span>
        </div>
      ) : null}
      {active && !ready && !error ? (
        <div className="absolute inset-0 grid place-items-center bg-background/85 text-sm text-muted-foreground">
          <span className="flex items-center gap-2">
            <Loader2 className="size-4 animate-spin" /> Loading recognition models…
          </span>
        </div>
      ) : null}
      {error ? (
        <div className="absolute inset-0 grid place-items-center bg-background/90 p-6 text-center text-sm text-destructive">
          {error}
        </div>
      ) : null}
    </div>
  );
}
