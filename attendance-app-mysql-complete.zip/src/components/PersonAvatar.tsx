import { useEffect, useState } from "react";
import { getPhotoUrl, initials } from "@/lib/photos";
import { cn } from "@/lib/utils";

export function PersonAvatar({
  name,
  photoPath,
  className,
}: {
  name: string;
  photoPath?: string | null | undefined;
  className?: string;
}) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    void getPhotoUrl(photoPath).then((next) => {
      if (active) setUrl(next);
    });
    return () => {
      active = false;
    };
  }, [photoPath]);

  return (
    <div
      className={cn(
        "relative flex size-10 shrink-0 items-center justify-center overflow-hidden rounded-full bg-secondary text-sm font-semibold text-secondary-foreground ring-1 ring-border",
        className,
      )}
    >
      {url ? (
        <img src={url} alt={name} className="size-full object-cover" loading="lazy" />
      ) : (
        <span>{initials(name) || "?"}</span>
      )}
    </div>
  );
}
