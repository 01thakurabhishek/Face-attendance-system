import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { attendanceRate } from "@/lib/queries";

type StatusCount = {
  present: number;
  late: number;
  absent: number;
};

const STATUS_META = [
  { key: "present" as const, label: "Present", color: "var(--success)", className: "border-success text-success" },
  { key: "late" as const, label: "Late", color: "var(--warning)", className: "border-warning text-warning" },
  { key: "absent" as const, label: "Absent", color: "var(--destructive)", className: "border-destructive text-destructive" },
];

export function AttendancePieChart({
  counts,
  title = "Attendance overview",
  description,
  showRate = true,
  donut = false,
}: {
  counts: StatusCount;
  title?: string;
  description?: string;
  showRate?: boolean;
  donut?: boolean;
}) {
  const total = counts.present + counts.late + counts.absent;
  const rate = attendanceRate(counts.present + counts.late, total);

  const data = STATUS_META.map((s) => ({
    name: s.label,
    value: counts[s.key],
    color: s.color,
  })).filter((d) => d.value > 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
        {description ? (
          <CardDescription>{description}</CardDescription>
        ) : (
          <CardDescription>
            {counts.present} present · {counts.late} late · {counts.absent} absent
            {total > 0 ? ` · ${rate}% effective` : ""}
          </CardDescription>
        )}
      </CardHeader>
      <CardContent>
        {total === 0 ? (
          <p className="py-10 text-center text-sm text-muted-foreground">
            No attendance records yet — the chart appears once students are marked.
          </p>
        ) : (
          <div className="space-y-4">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data}
                    dataKey="value"
                    nameKey="name"
                    outerRadius="65%"
                    innerRadius={donut ? "55%" : "0%"}
                    paddingAngle={2}
                    label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
                  >
                    {data.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number, name: string) => [
                      `${value} record${value === 1 ? "" : "s"}`,
                      name,
                    ]}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {showRate ? (
              <div className="grid grid-cols-3 gap-3">
                {STATUS_META.map((s) => (
                  <div
                    key={s.key}
                    className={`rounded-lg border p-3 text-center ${s.className}`}
                  >
                    <p className="text-2xl font-semibold">
                      {counts[s.key]}
                    </p>
                    <p className="text-xs text-muted-foreground">{s.label}</p>
                  </div>
                ))}
              </div>
            ) : null}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
