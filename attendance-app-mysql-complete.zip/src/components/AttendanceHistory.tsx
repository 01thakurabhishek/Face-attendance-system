import { useQuery } from "@tanstack/react-query";
import { ClipboardList } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { attendanceQuery, attendanceRate, formatDate, formatTime } from "@/lib/queries";

const statusVariant = (status: string) =>
  status === "present" ? "default" : status === "late" ? "secondary" : "destructive";

/** Attendance history for one student, grouped stats + full log. */
export function AttendanceHistory({ studentProfileId }: { studentProfileId: string }) {
  const { data: rows = [], isLoading } = useQuery({
    ...attendanceQuery({ studentProfileId }),
    enabled: Boolean(studentProfileId),
  });

  const bySubject = new Map<string, { total: number; attended: number }>();
  for (const row of rows) {
    const subject = row.lectures?.subject ?? "Unknown subject";
    const entry = bySubject.get(subject) ?? { total: 0, attended: 0 };
    entry.total += 1;
    if (row.status !== "absent") entry.attended += 1;
    bySubject.set(subject, entry);
  }

  if (!isLoading && rows.length === 0) {
    return (
      <EmptyState
        icon={ClipboardList}
        title="No attendance records yet"
        description="Records appear here once your teacher runs a session for your class."
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[...bySubject.entries()].map(([subject, stat]) => {
          const rate = attendanceRate(stat.attended, stat.total);
          return (
            <Card key={subject}>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">{subject}</CardTitle>
                <CardDescription>
                  {stat.attended} of {stat.total} classes attended
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className={rate >= 75 ? "text-2xl font-semibold" : "text-2xl font-semibold text-destructive"}>
                  {rate}%
                </p>
                <p className="text-xs text-muted-foreground">
                  {rate >= 75 ? "Meets the 75% requirement" : "Below the 75% requirement"}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Full record</CardTitle>
          <CardDescription>Every class marked for you, most recent first.</CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Method</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>{row.lectures ? formatDate(row.lectures.lecture_date) : "—"}</TableCell>
                  <TableCell className="font-medium">{row.lectures?.subject ?? "—"}</TableCell>
                  <TableCell>{row.lectures ? formatTime(row.lectures.start_time) : "—"}</TableCell>
                  <TableCell className="capitalize">{row.method}</TableCell>
                  <TableCell>
                    <Badge variant={statusVariant(row.status)} className="capitalize">
                      {row.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
