export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalDatabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      attendance: {
        Row: {
          confidence: number | null
          id: string
          lecture_id: string
          marked_at: string
          marked_by: string | null
          method: Database["public"]["Enums"]["attendance_mode"]
          status: Database["public"]["Enums"]["attendance_status"]
          student_profile_id: string
        }
        Insert: {
          confidence?: number | null
          id?: string
          lecture_id: string
          marked_at?: string
          marked_by?: string | null
          method?: Database["public"]["Enums"]["attendance_mode"]
          status?: Database["public"]["Enums"]["attendance_status"]
          student_profile_id: string
        }
        Update: {
          confidence?: number | null
          id?: string
          lecture_id?: string
          marked_at?: string
          marked_by?: string | null
          method?: Database["public"]["Enums"]["attendance_mode"]
          status?: Database["public"]["Enums"]["attendance_status"]
          student_profile_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "attendance_lecture_id_fkey"
            columns: ["lecture_id"]
            isOneToOne: false
            referencedRelation: "lectures"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_marked_by_fkey"
            columns: ["marked_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_student_profile_id_fkey"
            columns: ["student_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      exam_marks: {
        Row: {
          created_at: string
          exam_id: string
          graded_by: string | null
          id: string
          marks_obtained: number | null
          remarks: string | null
          student_profile_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          exam_id: string
          graded_by?: string | null
          id?: string
          marks_obtained?: number | null
          remarks?: string | null
          student_profile_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          exam_id?: string
          graded_by?: string | null
          id?: string
          marks_obtained?: number | null
          remarks?: string | null
          student_profile_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "exam_marks_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_marks_graded_by_fkey"
            columns: ["graded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_marks_student_profile_id_fkey"
            columns: ["student_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      exam_questions: {
        Row: {
          created_at: string
          exam_id: string
          id: string
          marks: number
          question_no: number
          question_text: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          exam_id: string
          id?: string
          marks?: number
          question_no: number
          question_text: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          exam_id?: string
          id?: string
          marks?: number
          question_no?: number
          question_text?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "exam_questions_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
        ]
      }
      exam_submissions: {
        Row: {
          answers: Json
          created_at: string
          exam_id: string
          id: string
          student_profile_id: string
          submitted_at: string | null
          updated_at: string
        }
        Insert: {
          answers?: Json
          created_at?: string
          exam_id: string
          id?: string
          student_profile_id: string
          submitted_at?: string | null
          updated_at?: string
        }
        Update: {
          answers?: Json
          created_at?: string
          exam_id?: string
          id?: string
          student_profile_id?: string
          submitted_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "exam_submissions_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_submissions_student_profile_id_fkey"
            columns: ["student_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      exams: {
        Row: {
          course: string | null
          created_at: string
          department: string | null
          duration_minutes: number | null
          exam_date: string
          exam_type: Database["public"]["Enums"]["exam_type"]
          id: string
          institute_id: string | null
          instructions: string | null
          section: string | null
          semester: string | null
          status: Database["public"]["Enums"]["exam_status"]
          subject: string
          teacher_profile_id: string
          title: string
          total_marks: number
          updated_at: string
        }
        Insert: {
          course?: string | null
          created_at?: string
          department?: string | null
          duration_minutes?: number | null
          exam_date?: string
          exam_type: Database["public"]["Enums"]["exam_type"]
          id?: string
          institute_id?: string | null
          instructions?: string | null
          section?: string | null
          semester?: string | null
          status?: Database["public"]["Enums"]["exam_status"]
          subject: string
          teacher_profile_id: string
          title: string
          total_marks?: number
          updated_at?: string
        }
        Update: {
          course?: string | null
          created_at?: string
          department?: string | null
          duration_minutes?: number | null
          exam_date?: string
          exam_type?: Database["public"]["Enums"]["exam_type"]
          id?: string
          institute_id?: string | null
          instructions?: string | null
          section?: string | null
          semester?: string | null
          status?: Database["public"]["Enums"]["exam_status"]
          subject?: string
          teacher_profile_id?: string
          title?: string
          total_marks?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "exams_institute_id_fkey"
            columns: ["institute_id"]
            isOneToOne: false
            referencedRelation: "institutes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exams_teacher_profile_id_fkey"
            columns: ["teacher_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      face_enrollments: {
        Row: {
          descriptor: number[]
          institute_id: string | null
          profile_id: string
          updated_at: string
        }
        Insert: {
          descriptor: number[]
          institute_id?: string | null
          profile_id: string
          updated_at?: string
        }
        Update: {
          descriptor?: number[]
          institute_id?: string | null
          profile_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "face_enrollments_institute_id_fkey"
            columns: ["institute_id"]
            isOneToOne: false
            referencedRelation: "institutes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "face_enrollments_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      institutes: {
        Row: {
          address: string | null
          code: string
          created_at: string
          email: string | null
          id: string
          name: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          code: string
          created_at?: string
          email?: string | null
          id?: string
          name: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          code?: string
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      lectures: {
        Row: {
          course: string | null
          created_at: string
          department: string | null
          end_time: string
          id: string
          institute_id: string | null
          lecture_date: string
          mode: Database["public"]["Enums"]["attendance_mode"]
          room: string | null
          section: string | null
          semester: string | null
          start_time: string
          status: Database["public"]["Enums"]["lecture_status"]
          subject: string
          teacher_profile_id: string
          updated_at: string
        }
        Insert: {
          course?: string | null
          created_at?: string
          department?: string | null
          end_time: string
          id?: string
          institute_id?: string | null
          lecture_date: string
          mode?: Database["public"]["Enums"]["attendance_mode"]
          room?: string | null
          section?: string | null
          semester?: string | null
          start_time: string
          status?: Database["public"]["Enums"]["lecture_status"]
          subject: string
          teacher_profile_id: string
          updated_at?: string
        }
        Update: {
          course?: string | null
          created_at?: string
          department?: string | null
          end_time?: string
          id?: string
          institute_id?: string | null
          lecture_date?: string
          mode?: Database["public"]["Enums"]["attendance_mode"]
          room?: string | null
          section?: string | null
          semester?: string | null
          start_time?: string
          status?: Database["public"]["Enums"]["lecture_status"]
          subject?: string
          teacher_profile_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lectures_institute_id_fkey"
            columns: ["institute_id"]
            isOneToOne: false
            referencedRelation: "institutes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lectures_teacher_profile_id_fkey"
            columns: ["teacher_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notes: {
        Row: {
          course: string | null
          created_at: string
          department: string | null
          description: string | null
          file_name: string
          file_path: string
          file_size: number | null
          id: string
          institute_id: string | null
          mime_type: string | null
          section: string | null
          semester: string | null
          subject: string
          teacher_profile_id: string
          title: string
          updated_at: string
        }
        Insert: {
          course?: string | null
          created_at?: string
          department?: string | null
          description?: string | null
          file_name: string
          file_path: string
          file_size?: number | null
          id?: string
          institute_id?: string | null
          mime_type?: string | null
          section?: string | null
          semester?: string | null
          subject: string
          teacher_profile_id: string
          title: string
          updated_at?: string
        }
        Update: {
          course?: string | null
          created_at?: string
          department?: string | null
          description?: string | null
          file_name?: string
          file_path?: string
          file_size?: number | null
          id?: string
          institute_id?: string | null
          mime_type?: string | null
          section?: string | null
          semester?: string | null
          subject?: string
          teacher_profile_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "notes_institute_id_fkey"
            columns: ["institute_id"]
            isOneToOne: false
            referencedRelation: "institutes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notes_teacher_profile_id_fkey"
            columns: ["teacher_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          course: string | null
          created_at: string
          date_of_birth: string | null
          department: string | null
          designation: string | null
          email: string
          face_enrolled: boolean
          full_name: string
          id: string
          institute_id: string | null
          is_active: boolean
          phone: string | null
          photo_url: string | null
          role: Database["public"]["Enums"]["app_role"]
          roll_number: string | null
          section: string | null
          semester: string | null
          student_id: string | null
          subjects: string[] | null
          teacher_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          course?: string | null
          created_at?: string
          date_of_birth?: string | null
          department?: string | null
          designation?: string | null
          email: string
          face_enrolled?: boolean
          full_name: string
          id?: string
          institute_id?: string | null
          is_active?: boolean
          phone?: string | null
          photo_url?: string | null
          role: Database["public"]["Enums"]["app_role"]
          roll_number?: string | null
          section?: string | null
          semester?: string | null
          student_id?: string | null
          subjects?: string[] | null
          teacher_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          course?: string | null
          created_at?: string
          date_of_birth?: string | null
          department?: string | null
          designation?: string | null
          email?: string
          face_enrolled?: boolean
          full_name?: string
          id?: string
          institute_id?: string | null
          is_active?: boolean
          phone?: string | null
          photo_url?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          roll_number?: string | null
          section?: string | null
          semester?: string | null
          student_id?: string | null
          subjects?: string[] | null
          teacher_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_institute_id_fkey"
            columns: ["institute_id"]
            isOneToOne: false
            referencedRelation: "institutes"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_logs: {
        Row: {
          confidence: number | null
          detected_at: string
          id: string
          observed_by: string | null
          profile_id: string | null
          source: string
        }
        Insert: {
          confidence?: number | null
          detected_at?: string
          id?: string
          observed_by?: string | null
          profile_id?: string | null
          source?: string
        }
        Update: {
          confidence?: number | null
          detected_at?: string
          id?: string
          observed_by?: string | null
          profile_id?: string | null
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "tracking_logs_observed_by_fkey"
            columns: ["observed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tracking_logs_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      app_role: "student" | "teacher"
      attendance_mode: "face" | "manual" | "video"
      attendance_status: "present" | "absent" | "late"
      exam_status: "draft" | "published"
      exam_type: "ct1" | "ct2" | "sessional" | "put"
      lecture_status: "scheduled" | "live" | "ended"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalDatabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["student", "teacher"],
      attendance_mode: ["face", "manual", "video"],
      attendance_status: ["present", "absent", "late"],
      exam_status: ["draft", "published"],
      exam_type: ["ct1", "ct2", "sessional", "put"],
      lecture_status: ["scheduled", "live", "ended"],
    },
  },
} as const
