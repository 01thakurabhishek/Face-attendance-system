import type { Database } from './types';

const API = (import.meta as any).env?.VITE_LOCAL_API_URL || 'http://localhost:4000';
const TOKEN_KEY = 'attendance_local_access_token';
export type LocalSession = { access_token: string; token_type?: string; user: { id: string; email?: string } };
type AuthEvent = 'SIGNED_IN' | 'SIGNED_OUT' | 'PASSWORD_RECOVERY' | 'INITIAL_SESSION' | 'USER_UPDATED';
const listeners = new Set<(event: AuthEvent, session: LocalSession | null) => void>();
function token() { try { return typeof localStorage !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null; } catch { return null; } }
function saveSession(session: LocalSession | null) { try { if (typeof localStorage !== 'undefined') { if (session?.access_token) localStorage.setItem(TOKEN_KEY, session.access_token); else localStorage.removeItem(TOKEN_KEY); } } catch {} listeners.forEach(fn => fn(session ? 'SIGNED_IN' : 'SIGNED_OUT', session)); }
async function request(path: string, init: RequestInit = {}) {
  const headers = new Headers(init.headers || {}); if (!(init.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type','application/json');
  const t=token(); if(t) headers.set('Authorization',`Bearer ${t}`);
  let response: Response; try { response=await fetch(`${API}${path}`,{...init,headers}); } catch { return {data:null,error:{message:`Cannot connect to local API at ${API}. Start mysql-local/server first.`}}; }
  const payload=await response.json().catch(()=>({})); if(!response.ok) return {data:null,error:payload.error||{message:payload.message||`Request failed (${response.status})`}}; return payload;
}
class QueryBuilder implements PromiseLike<any> {
  private action='select'; private columns='*'; private filters:any[]=[]; private orders:any[]=[]; private maxRows?:number; private values:any; private conflict?:string; private returning=false; private singleMode:'single'|'maybeSingle'|null=null;
  constructor(private table:string) {}
  select(columns='*') { this.columns=columns; if(this.action!=='select') this.returning=true; return this; }
  insert(values:any) {this.action='insert';this.values=values;return this;}
  upsert(values:any,opts?:{onConflict?:string}) {this.action='upsert';this.values=values;this.conflict=opts?.onConflict;return this;}
  update(values:any) {this.action='update';this.values=values;return this;}
  delete() {this.action='delete';return this;}
  eq(column:string,value:any){this.filters.push({column,op:'eq',value});return this;}
  neq(column:string,value:any){this.filters.push({column,op:'neq',value});return this;}
  gt(column:string,value:any){this.filters.push({column,op:'gt',value});return this;}
  gte(column:string,value:any){this.filters.push({column,op:'gte',value});return this;}
  lt(column:string,value:any){this.filters.push({column,op:'lt',value});return this;}
  lte(column:string,value:any){this.filters.push({column,op:'lte',value});return this;}
  in(column:string,value:any[]){this.filters.push({column,op:'in',value});return this;}
  is(column:string,value:any){this.filters.push({column,op:'is',value});return this;}
  order(column:string,opts?:{ascending?:boolean}){this.orders.push({column,ascending:opts?.ascending!==false});return this;}
  limit(count:number){this.maxRows=count;return this;}
  single(){this.singleMode='single';return this;}
  maybeSingle(){this.singleMode='maybeSingle';return this;}
  then<TResult1 = any, TResult2 = never>(onfulfilled?: ((value:any)=>TResult1|PromiseLike<TResult1>) | null,onrejected?:((reason:any)=>TResult2|PromiseLike<TResult2>)|null):Promise<TResult1|TResult2>{return this.execute().then(onfulfilled,onrejected);}
  private async execute(){const r=await request('/api/query',{method:'POST',body:JSON.stringify({table:this.table,action:this.action,columns:this.columns,filters:this.filters,orders:this.orders,limit:this.maxRows,values:this.values,onConflict:this.conflict,returning:this.returning})}); if(r.error) return r; let data=r.data??null; if(this.singleMode){if(Array.isArray(data)){if(data.length===0&&this.singleMode==='maybeSingle') data=null; else if(data.length===0)return {data:null,error:{message:'No rows found'}};else if(data.length>1)return {data:null,error:{message:'Multiple rows found'}};else data=data[0];}} return {data,error:null,count:r.count};}
}
function storage(bucket:string){return {upload:async(path:string,file:File,_opts?:any)=>{const form=new FormData();form.append('file',file,file.name);const r=await request(`/api/storage/${encodeURIComponent(bucket)}/upload?path=${encodeURIComponent(path)}`,{method:'POST',body:form});return r.error?r:{data:{path:r.path},error:null};},remove:async(paths:string[])=>request(`/api/storage/${encodeURIComponent(bucket)}`,{method:'DELETE',body:JSON.stringify({paths})}),createSignedUrl:async(path:string,_expires:number)=>({data:{signedUrl:`${API}/uploads/${encodeURIComponent(bucket)}/${path.split('/').map(encodeURIComponent).join('/')}`},error:null})};}
const auth={
  signUp:async({email,password}:any)=>{const r=await request('/api/auth/signup',{method:'POST',body:JSON.stringify({email,password})});if(r.error)return r;saveSession(r.session);return {data:{user:r.user,session:r.session},error:null};},
  signInWithPassword:async({email,password}:any)=>{const r=await request('/api/auth/login',{method:'POST',body:JSON.stringify({email,password})});if(r.error)return r;saveSession(r.session);return {data:{user:r.user,session:r.session},error:null};},
  signOut:async()=>{const r=await request('/api/auth/logout',{method:'POST',body:'{}'});saveSession(null);return {error:r.error||null};},
  getSession:async()=>{const t=token();if(!t)return {data:{session:null},error:null};const r=await request('/api/auth/session');if(r.error||!r.session){saveSession(null);return {data:{session:null},error:null};}return {data:{session:r.session},error:null};},
  onAuthStateChange:(callback:(event:AuthEvent,session:LocalSession|null)=>void)=>{listeners.add(callback);void (async()=>callback('INITIAL_SESSION',(await auth.getSession()).data.session))();return {data:{subscription:{unsubscribe:()=>listeners.delete(callback)}}};},
  updateUser:async({password}:any)=>{const r=await request('/api/auth/password',{method:'PUT',body:JSON.stringify({password})});return {data:{user:null},error:r.error||null};},
  resetPasswordForEmail:async(email:string)=>{const r=await request('/api/auth/reset-request',{method:'POST',body:JSON.stringify({email})});return {data:r,error:r.error||null};},
  getClaims:async()=>({data:{claims:null},error:{message:'Local auth uses opaque bearer tokens.'}}),
  admin:{listUsers:async()=>({data:{users:[]},error:null}),updateUserById:async()=>({data:{user:null},error:null}),createUser:async()=>({data:{user:null},error:null})}
};
export const localDb = { from:(table:string)=>new QueryBuilder(table), auth, storage:{from:storage}, removeChannel:async()=>({}) } as any as { from:(table:string)=>QueryBuilder; auth:any; storage:any; removeChannel:(channel:any)=>Promise<any> };
export type { Database };
