const API = process.env.LOCAL_API_URL || "http://127.0.0.1:4000";
export async function localApi(path: string, body: unknown) { const r = await fetch(`${API}${path}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const data = await r.json(); if (!r.ok) throw new Error(data?.error?.message || "Local API request failed"); return data; }
