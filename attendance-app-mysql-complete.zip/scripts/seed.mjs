// Local MySQL seeding is intentionally handled through mysql-local/schema.sql.
// Import this script only after configuring MySQL; it checks that the local API is reachable.
const url = process.env.LOCAL_API_URL || "http://127.0.0.1:4000";
const response = await fetch(`${url}/api/health`);
const result = await response.json();
if (!response.ok || !result.ok) { console.error("Local MySQL API is not ready:", result); process.exit(1); }
console.log("Local MySQL API is ready:", result);
