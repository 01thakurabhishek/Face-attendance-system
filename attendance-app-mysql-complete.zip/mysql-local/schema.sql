-- MySQL 8.0+ schema for the VISIOROLL / AI Attendance System data model.
-- Run in MySQL Workbench or: mysql -u root -p < schema.sql
CREATE DATABASE IF NOT EXISTS visioroll CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE visioroll;

CREATE TABLE IF NOT EXISTS institutes (
 id CHAR(36) PRIMARY KEY, code CHAR(6) NOT NULL UNIQUE, name VARCHAR(255) NOT NULL,
 email VARCHAR(255), phone VARCHAR(40), address TEXT,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CHECK (code REGEXP '^[0-9]{6}$')
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS app_users (
 id CHAR(36) PRIMARY KEY, email VARCHAR(255) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 reset_token_hash VARCHAR(255), reset_token_expires_at DATETIME,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profiles (
 id CHAR(36) PRIMARY KEY, user_id CHAR(36) NOT NULL UNIQUE,
 institute_id CHAR(36), role ENUM('student','teacher') NOT NULL,
 full_name VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL,
 phone VARCHAR(40), department VARCHAR(255), photo_url TEXT, date_of_birth DATE, subjects JSON,
 is_active BOOLEAN NOT NULL DEFAULT TRUE, face_enrolled BOOLEAN NOT NULL DEFAULT FALSE,
 student_id VARCHAR(100) UNIQUE, roll_number VARCHAR(100), course VARCHAR(255), semester VARCHAR(50), section VARCHAR(50),
 teacher_id VARCHAR(100) UNIQUE, designation VARCHAR(255),
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_profiles_user FOREIGN KEY(user_id) REFERENCES app_users(id) ON DELETE CASCADE,
 CONSTRAINT fk_profiles_institute FOREIGN KEY(institute_id) REFERENCES institutes(id) ON DELETE CASCADE,
 INDEX profiles_institute_idx(institute_id), INDEX profiles_role_idx(role)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS face_enrollments (
 profile_id CHAR(36) PRIMARY KEY, institute_id CHAR(36), descriptor JSON NOT NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
 FOREIGN KEY(institute_id) REFERENCES institutes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS lectures (
 id CHAR(36) PRIMARY KEY, institute_id CHAR(36), teacher_profile_id CHAR(36) NOT NULL,
 subject VARCHAR(255) NOT NULL, course VARCHAR(255), department VARCHAR(255), semester VARCHAR(50), section VARCHAR(50),
 lecture_date DATE NOT NULL, start_time TIME NOT NULL, end_time TIME NOT NULL, room VARCHAR(100),
 mode ENUM('face','manual','video') NOT NULL DEFAULT 'face',
 status ENUM('scheduled','live','ended') NOT NULL DEFAULT 'scheduled',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(teacher_profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
 FOREIGN KEY(institute_id) REFERENCES institutes(id) ON DELETE CASCADE,
 INDEX lectures_institute_idx(institute_id), INDEX lectures_date_idx(lecture_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS attendance (
 id CHAR(36) PRIMARY KEY, lecture_id CHAR(36) NOT NULL, student_profile_id CHAR(36) NOT NULL,
 status ENUM('present','absent','late') NOT NULL DEFAULT 'present',
 method ENUM('face','manual','video') NOT NULL DEFAULT 'face', confidence DOUBLE,
 marked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, marked_by CHAR(36),
 UNIQUE KEY uq_attendance_lecture_student(lecture_id,student_profile_id),
 FOREIGN KEY(lecture_id) REFERENCES lectures(id) ON DELETE CASCADE,
 FOREIGN KEY(student_profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
 FOREIGN KEY(marked_by) REFERENCES profiles(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tracking_logs (
 id CHAR(36) PRIMARY KEY, profile_id CHAR(36), source VARCHAR(100) NOT NULL DEFAULT 'live-camera',
 confidence DOUBLE, detected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, observed_by CHAR(36),
 FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
 FOREIGN KEY(observed_by) REFERENCES profiles(id) ON DELETE SET NULL,
 INDEX tracking_detected_idx(detected_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS exams (
 id CHAR(36) PRIMARY KEY, institute_id CHAR(36), teacher_profile_id CHAR(36) NOT NULL,
 title VARCHAR(255) NOT NULL, exam_type ENUM('ct1','ct2','sessional','put') NOT NULL,
 subject VARCHAR(255) NOT NULL, course VARCHAR(255), department VARCHAR(255), semester VARCHAR(50), section VARCHAR(50),
 exam_date DATE NOT NULL, duration_minutes INT, total_marks DECIMAL(8,2) NOT NULL DEFAULT 20,
 instructions TEXT, status ENUM('draft','published') NOT NULL DEFAULT 'draft',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(teacher_profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
 FOREIGN KEY(institute_id) REFERENCES institutes(id) ON DELETE CASCADE,
 INDEX exams_institute_idx(institute_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS exam_questions (
 id CHAR(36) PRIMARY KEY, exam_id CHAR(36) NOT NULL, question_no INT NOT NULL,
 question_text TEXT NOT NULL, marks DECIMAL(8,2) NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_exam_question(exam_id,question_no),
 FOREIGN KEY(exam_id) REFERENCES exams(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS exam_marks (
 id CHAR(36) PRIMARY KEY, exam_id CHAR(36) NOT NULL, student_profile_id CHAR(36) NOT NULL,
 marks_obtained DECIMAL(8,2), remarks TEXT, graded_by CHAR(36),
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_exam_student(exam_id,student_profile_id),
 FOREIGN KEY(exam_id) REFERENCES exams(id) ON DELETE CASCADE,
 FOREIGN KEY(student_profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
 FOREIGN KEY(graded_by) REFERENCES profiles(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS exam_submissions (
 id CHAR(36) PRIMARY KEY, exam_id CHAR(36) NOT NULL, student_profile_id CHAR(36) NOT NULL,
 answers JSON NOT NULL, submitted_at DATETIME,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_submission_exam_student(exam_id,student_profile_id),
 FOREIGN KEY(exam_id) REFERENCES exams(id) ON DELETE CASCADE,
 FOREIGN KEY(student_profile_id) REFERENCES profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notes (
 id CHAR(36) PRIMARY KEY, institute_id CHAR(36), teacher_profile_id CHAR(36) NOT NULL,
 title VARCHAR(255) NOT NULL, description TEXT, subject VARCHAR(255) NOT NULL,
 course VARCHAR(255), department VARCHAR(255), semester VARCHAR(50), section VARCHAR(50),
 file_path VARCHAR(1024) NOT NULL, file_name VARCHAR(255) NOT NULL, file_size BIGINT, mime_type VARCHAR(255),
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(institute_id) REFERENCES institutes(id) ON DELETE CASCADE,
 FOREIGN KEY(teacher_profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
 INDEX notes_institute_idx(institute_id,created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_sessions (
 id CHAR(36) PRIMARY KEY, user_id CHAR(36) NOT NULL, token_hash CHAR(64) NOT NULL UNIQUE, expires_at DATETIME NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES app_users(id) ON DELETE CASCADE, INDEX user_sessions_expiry_idx(expires_at)
) ENGINE=InnoDB;
