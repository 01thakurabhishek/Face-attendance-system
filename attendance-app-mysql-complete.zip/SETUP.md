# Quick Setup (Windows / VS Code)

1. Extract the ZIP. Open the extracted project root in VS Code. The root must contain `package.json`, `src`, `public`, and `mysql-local`.
2. In MySQL Workbench, execute `mysql-local/schema.sql`.
3. Copy `mysql-local/.env.example` to `mysql-local/server/.env`; edit `MYSQL_USER` and `MYSQL_PASSWORD`.
4. Terminal 1: `cd mysql-local/server`, then `npm install`, then `npm run dev`. Verify `http://localhost:4000/api/health`.
5. Terminal 2: from project root run `npm install`, then `npm run dev`. Open the Vite `Local:` URL.
6. Keep both terminals open. If `npm` says `package.json` is missing, use `cd ..` or reopen the correct root folder until `Get-ChildItem package.json` shows the root package file.
